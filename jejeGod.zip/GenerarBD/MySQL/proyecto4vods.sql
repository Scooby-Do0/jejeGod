-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-02-2025 a las 12:38:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

DROP DATABASE IF EXISTS proyecto4vods;

CREATE DATABASE proyecto4vods;
USE proyecto4vods;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto4vods`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciclos`
--

CREATE TABLE `ciclos` (
  `IdCiclo` smallint(6) NOT NULL,
  `NombreCiclo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `difusion_iniciativas`
--

CREATE TABLE `difusion_iniciativas` (
  `IDDifusion` int(11) NOT NULL,
  `IDIniciativa` smallint(6) NOT NULL,
  `Tipo` varchar(100) NOT NULL,
  `Enlace` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidades_externas`
--

CREATE TABLE `entidades_externas` (
  `IDEntidad` smallint(6) NOT NULL,
  `NOMBRE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciativas`
--

CREATE TABLE `iniciativas` (
  `IDIniciativa` smallint(6) NOT NULL,
  `NOMBRE` varchar(200) NOT NULL,
  `DESCRIPCION` varchar(2500) DEFAULT NULL,
  `CURSO ACADEMICO` varchar(100) DEFAULT NULL,
  `FECHA INICIO` datetime NOT NULL,
  `FECHA FIN` datetime DEFAULT NULL,
  `TIPO INICIATIVA` ENUM('Proyecto', 'Charla', 'Taller', 'Salida', 'Otro') DEFAULT 'Otro',
  `INNOVADORA` tinyint(1) DEFAULT NULL,
  `HORAS` smallint NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciativas_entidades_externas`
--

CREATE TABLE `iniciativas_entidades_externas` (
  `IDIniciativa` smallint(6) NOT NULL,
  `IDEntidad` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciativas_metas`
--

CREATE TABLE `iniciativas_metas` (
  `IdIniciativa` smallint(6) NOT NULL,
  `IdODS` smallint(6) NOT NULL,
  `IdMeta` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciativas_modulos`
--

CREATE TABLE `iniciativas_modulos` (
  `IdIniciativa` smallint(6) NOT NULL,
  `IdModulo` smallint(6) NOT NULL,
  `IdCiclo` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciativas_profesores`
--

CREATE TABLE `iniciativas_profesores` (
  `IdProfesor` smallint(6) NOT NULL,
  `IdIniciativa` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metas`
--

CREATE TABLE `metas` (
  `IdODS` smallint(6) NOT NULL,
  `IdMeta` varchar(4) NOT NULL,
  `DESCRIPCION` varchar(2500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `IdModulo` smallint(6) NOT NULL,
  `IdCiclo` smallint(6) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ods`
--

CREATE TABLE `ods` (
  `IdODS` smallint(6) NOT NULL,
  `NOMBRE` varchar(200) NOT NULL,
   `Dimension` ENUM('Social', 'Económica', 'Medioambiental') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores`
--

CREATE TABLE `profesores` (
  `IdProfesor` smallint(6) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL UNIQUE,
   `Rol` ENUM('Administrador', 'Usuario') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores_modulos`
--

CREATE TABLE `profesores_modulos` (
  `IdCiclo` smallint(6) NOT NULL,
  `IdModulo` smallint(6) NOT NULL,
  `IdProfesor` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `__efmigrationshistory`
--

CREATE TABLE `__efmigrationshistory` (
  `MigrationId` varchar(150) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `__efmigrationshistory`
--

INSERT INTO `__efmigrationshistory` (`MigrationId`, `ProductVersion`) VALUES
('20250227113710_InitialCreate', '8.0.4');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ciclos`
--
ALTER TABLE `ciclos`
  ADD PRIMARY KEY (`IdCiclo`);

--
-- Columna Eliminada de la tabla `ciclos`
--
ALTER TABLE `ciclos`
  ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;

--
-- Indices de la tabla `difusion_iniciativas`
--
ALTER TABLE `difusion_iniciativas`
  ADD PRIMARY KEY (`IDDifusion`),
  ADD KEY `IX_DIFUSION_INICIATIVAS_IDIniciativa` (`IDIniciativa`);

--
-- Indices de la tabla `entidades_externas`
--
ALTER TABLE `entidades_externas`
  ADD PRIMARY KEY (`IDEntidad`);

--
-- Columna Eliminada de la tabla `entidades_externas`
--
ALTER TABLE `entidades_externas`
	ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;
--
-- Indices de la tabla `iniciativas`
--
ALTER TABLE `iniciativas`
  ADD PRIMARY KEY (`IDIniciativa`);

--
-- Indices de la tabla `iniciativas_entidades_externas`
--
ALTER TABLE `iniciativas_entidades_externas`
  ADD PRIMARY KEY (`IDIniciativa`,`IDEntidad`),
  ADD KEY `IX_INICIATIVAS_ENTIDADES_EXTERNAS_IDEntidad` (`IDEntidad`);

--
-- Indices de la tabla `iniciativas_metas`
--
ALTER TABLE `iniciativas_metas`
  ADD PRIMARY KEY (`IdIniciativa`,`IdODS`,`IdMeta`),
  ADD KEY `IX_INICIATIVAS_METAS_IdODS_IdMeta` (`IdODS`,`IdMeta`);

--
-- Indices de la tabla `iniciativas_modulos`
--
ALTER TABLE `iniciativas_modulos`
  ADD PRIMARY KEY (`IdIniciativa`,`IdModulo`,`IdCiclo`),
  ADD KEY `IX_INICIATIVAS_MODULOS_IdCiclo_IdModulo` (`IdCiclo`,`IdModulo`);

--
-- Indices de la tabla `iniciativas_profesores`
--
ALTER TABLE `iniciativas_profesores`
  ADD PRIMARY KEY (`IdProfesor`,`IdIniciativa`),
  ADD KEY `IX_INICIATIVAS_PROFESORES_IdIniciativa` (`IdIniciativa`);

--
-- Indices de la tabla `metas`
--
ALTER TABLE `metas`
  ADD PRIMARY KEY (`IdODS`,`IdMeta`);

--
-- Columna Eliminada de la tabla `metas`
--
ALTER TABLE `metas`
	ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;
--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`IdCiclo`,`IdModulo`);

--
-- Columna Eliminada de la tabla `módulos`
--
ALTER TABLE `modulos`
	ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;
--
-- Indices de la tabla `ods`
--
ALTER TABLE `ods`
  ADD PRIMARY KEY (`IdODS`);

--
-- Columna Eliminada de la tabla `ods`
--
ALTER TABLE `ods`
	ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;
--
-- Indices de la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD PRIMARY KEY (`IdProfesor`);

--
-- Columna Eliminada de la tabla `profesores`
--
ALTER TABLE `profesores`
	ADD COLUMN Eliminada BOOLEAN NOT NULL DEFAULT FALSE;
--
-- Indices de la tabla `profesores_modulos`
--
ALTER TABLE `profesores_modulos`
  ADD PRIMARY KEY (`IdCiclo`,`IdModulo`,`IdProfesor`),
  ADD KEY `IX_PROFESORES_MODULOS_IdProfesor` (`IdProfesor`);

--
-- Indices de la tabla `__efmigrationshistory`
--
ALTER TABLE `__efmigrationshistory`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ciclos`
--
ALTER TABLE `ciclos`
  MODIFY `IdCiclo` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `difusion_iniciativas`
--
ALTER TABLE `difusion_iniciativas`
  MODIFY `IDDifusion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `entidades_externas`
--
ALTER TABLE `entidades_externas`
  MODIFY `IDEntidad` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `iniciativas`
--
ALTER TABLE `iniciativas`
  MODIFY `IDIniciativa` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `profesores`
--
ALTER TABLE `profesores`
  MODIFY `IdProfesor` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `difusion_iniciativas`
--
ALTER TABLE `difusion_iniciativas`
  ADD CONSTRAINT `FK_DIFUSION_INICIATIVAS` FOREIGN KEY (`IDIniciativa`) REFERENCES `iniciativas` (`IDIniciativa`) ON DELETE CASCADE;

--
-- Filtros para la tabla `iniciativas_entidades_externas`
--
ALTER TABLE `iniciativas_entidades_externas`
  ADD CONSTRAINT `FK__INICIATIV__IDEnt__3F466844` FOREIGN KEY (`IDEntidad`) REFERENCES `entidades_externas` (`IDEntidad`),
  ADD CONSTRAINT `FK__INICIATIV__IDIni__3E52440B` FOREIGN KEY (`IDIniciativa`) REFERENCES `iniciativas` (`IDIniciativa`);

--
-- Filtros para la tabla `iniciativas_metas`
--
ALTER TABLE `iniciativas_metas`
  ADD CONSTRAINT `FK_INICIATIVAS_METAS_INICIATIVAS` FOREIGN KEY (`IdIniciativa`) REFERENCES `iniciativas` (`IDIniciativa`),
  ADD CONSTRAINT `FK_INICIATIVAS_METAS_METAS` FOREIGN KEY (`IdODS`,`IdMeta`) REFERENCES `metas` (`IdODS`, `IdMeta`);

--
-- Filtros para la tabla `iniciativas_modulos`
--
ALTER TABLE `iniciativas_modulos`
  ADD CONSTRAINT `FK_INICIATIVAS_MODULOS_INICIATIVA` FOREIGN KEY (`IdIniciativa`) REFERENCES `iniciativas` (`IDIniciativa`),
  ADD CONSTRAINT `FK_INICIATIVAS_MODULOS_MODULO` FOREIGN KEY (`IdCiclo`,`IdModulo`) REFERENCES `modulos` (`IdCiclo`, `IdModulo`);

--
-- Filtros para la tabla `iniciativas_profesores`
--
ALTER TABLE `iniciativas_profesores`
  ADD CONSTRAINT `FK_INICIATIVAS_PROFESORES_INICIATIVAS` FOREIGN KEY (`IdIniciativa`) REFERENCES `iniciativas` (`IDIniciativa`),
  ADD CONSTRAINT `FK_INICIATIVAS_PROFESORES_PROFESORES` FOREIGN KEY (`IdProfesor`) REFERENCES `profesores` (`IdProfesor`);

--
-- Filtros para la tabla `metas`
--
ALTER TABLE `metas`
  ADD CONSTRAINT `FK_ID_ODS` FOREIGN KEY (`IdODS`) REFERENCES `ods` (`IdODS`);

--
-- Filtros para la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD CONSTRAINT `FK_MODULOS` FOREIGN KEY (`IdCiclo`) REFERENCES `ciclos` (`IdCiclo`);

--
-- Filtros para la tabla `profesores_modulos`
--
ALTER TABLE `profesores_modulos`
  ADD CONSTRAINT `FK_MODULOS_PROFESORES_MODULOS` FOREIGN KEY (`IdCiclo`,`IdModulo`) REFERENCES `modulos` (`IdCiclo`, `IdModulo`),
  ADD CONSTRAINT `FK__PROFESORE__IdPro__49C3F6B7` FOREIGN KEY (`IdProfesor`) REFERENCES `profesores` (`IdProfesor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
