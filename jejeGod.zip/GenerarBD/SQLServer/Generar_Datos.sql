go
Use PROYECTO4VODS
go

DELETE FROM DIFUSION_INICIATIVAS
DELETE FROM INICIATIVAS_ENTIDADES_EXTERNAS
DELETE FROM INICIATIVAS_METAS
DELETE FROM INICIATIVAS_PROFESORES
DELETE FROM INICIATIVAS_MODULOS
DELETE FROM PROFESORES_MODULOS
DELETE FROM MODULOS
DELETE FROM CICLOS
DELETE FROM PROFESORES
DELETE FROM ENTIDADES_EXTERNAS
DELETE FROM INICIATIVAS
DELETE FROM METAS
DELETE FROM ODS

DBCC CHECKIDENT ('INICIATIVAS', RESEED, 0)
DBCC CHECKIDENT ('ENTIDADES_EXTERNAS', RESEED, 0)
DBCC CHECKIDENT ('PROFESORES', RESEED, 0)
DBCC CHECKIDENT ('CICLOS', RESEED, 0)
DBCC CHECKIDENT ('DIFUSION_INICIATIVAS', RESEED, 0)

INSERT INTO INICIATIVAS (NOMBRE, DESCRIPCION, [CURSO ACADEMICO], [FECHA INICIO], [FECHA FIN], [TIPO INICIATIVA], ACCION, INNOVADORA)
VALUES ('Proyecto A', 'Descripci�n del Proyecto A', '23-24', '15/04/2024', '15/05/2024', 'Charla', 'visita', 1), 
	('Campa�a B', 'Descripci�n de la Campa�a B', '23-24','15/05/2024', '15/05/2025', 'Taller', 'charla', 0),
	('Campa�a C', 'Descripci�n de la Campa�a C', '23-24','15/05/2024', '15/05/2025', 'Taller', 'charla', 0)

INSERT INTO DIFUSION_INICIATIVAS (IDIniciativa,Tipo,Enlace)
VALUES (1,'instagram','enlace'), (2,'youtube','enlace')

INSERT INTO ODS (IdODS, NOMBRE) VALUES 
    (1, 'Fin de la pobreza'),
    (2, 'Hambre cero'),
    (3, 'Salud y bienestar'),
    (4, 'Educaci�n de calidad'),
    (5, 'Igualdad de g�nero'),
    (6, 'Agua limpia y saneamiento'),
    (7, 'Energ�a asequible y no contaminante'),
    (8, 'Trabajo decente y crecimiento econ�mico'),
    (9, 'Industria, innovaci�n e infraestructura'),
    (10, 'Reducci�n de las desigualdades'),
    (11, 'Ciudades y comunidades sostenibles'),
    (12, 'Producci�n y consumo responsables'),
    (13, 'Acci�n por el clima'),
    (14, 'Vida submarina'),
    (15, 'Vida de ecosistemas terrestres'),
    (16, 'Paz, justicia e instituciones s�lidas'),
    (17, 'Alianzas para lograr los objetivos');

INSERT INTO METAS (IdODS, IdMeta, DESCRIPCION) VALUES 
    (1, 1, 'Meta 1'),
    (1, 2, 'Meta 2'),
    (2, 1, 'Meta 3');

INSERT INTO ENTIDADES_EXTERNAS (NOMBRE) VALUES 
    ('Entidad 1'),
    ('Entidad 2');

INSERT INTO PROFESORES (Nombre) VALUES 
    ('Alberto Aginaga'),
    ('Maria Martin'),
    ('Luis Agero');

INSERT INTO CICLOS (NombreCiclo) VALUES 
    ('1�DAM'),
    ('2�DAM'),
    ('1�ASIR'),
    ('2�ASIR');

INSERT INTO MODULOS (IdModulo, IdCiclo, Nombre) VALUES 
    (1, 1, 'Bases de Datos'),
    (2, 1, 'Programaci�n'),
    (3, 2, 'Acceso Datos')

INSERT INTO PROFESORES_MODULOS (IdCiclo, IdModulo, IdProfesor) VALUES 
    (1, 1, 1),
    (1, 2, 2),  
    (2, 3, 1)

INSERT INTO INICIATIVAS_MODULOS (IdModulo, IdIniciativa, IdCiclo) VALUES 
     (1, 1, 1),
	 (3,1,2),
	 (2,2,1)

INSERT INTO INICIATIVAS_PROFESORES (IdProfesor, IdIniciativa) VALUES 
    (1, 1),  
    (2, 2); 

INSERT INTO INICIATIVAS_METAS (IdIniciativa, IdODS, IdMeta) VALUES 
    (1, 1, 1),  
    (2, 1, 2);

INSERT INTO INICIATIVAS_ENTIDADES_EXTERNAS (IDIniciativa, IDEntidad) VALUES 
    (1, 1), 
    (2, 2); 