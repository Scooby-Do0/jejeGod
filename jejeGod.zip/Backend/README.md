# API

## MATERIALES NECESARIOS PARA INICIAR LA APLICACIÓN

1. Visual Studio

2. Apache + MySql(XAMPP permite manejar ambos)

## CREACIÓN DE LA BASE DE DATOS

1. En MySql, crear una base de datos vacía de nombre "proyecto4vods"

2. En esa base de datos, ejecutar el archivo sql llamado "proyecto4vods.sql" que se encuentra en generarBD/MySql

3. Para tener datos, ejecutar el archivo sql "Datos4vOds" que se encuentra en generarBD/MySql

## INICIAR LA APP

1. Asegurarse de tener Visual Studio completamente actualizado

3. Encender Apache y MySql

2. Ejecutar el proyecto en https

## TECNOLOGÍAS USADAS PARA EL DESARROLLO DEL CÓDIGO

- .Net 9.0
- Entity Framework
- C#
