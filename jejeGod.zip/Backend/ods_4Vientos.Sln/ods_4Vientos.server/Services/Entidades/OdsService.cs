﻿using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Utilidades;
using System.Data;

namespace ods_4Vientos.server.Services.Entidades
{
    public class OdsService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        private readonly MetaService _metaService;
        public OdsService(Proyecto4vodsContext context, IMappingService mappingService, MetaService metaService)
        {
            _context = context;
            _mappingService = mappingService;
            _metaService = metaService;
        }
        public async Task<IEnumerable<OdsFront>> ObtenerOds()
        {
            List<Od> ods;
            try
            {
                ods = await _context.Ods.Include(o => o.Meta.Where(met => met.Eliminada == false)).Where(od => od.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los ods");
            }
            return ods.Select(o => _mappingService.MapOdFront(o)).ToList();
        }
        public async Task<OdsFront> CrearOds(OdsFront odsFront, string? dimension = "")
        {
            OdsFront? resultado = null;
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (await ExisteOds(odsFront.IdOds))
                    {
                        throw new DuplicateNameException("Ya existe un Ods con el mismo Id");
                    }

                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    Od? ods = _mappingService.InverseMapOd(odsFront, dimension: dimension) ?? null;

                    if (ods == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear el Ods en su Entidad");
                    }

                    _context.Ods.Add(ods);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar el Ods, ya existía un Ods con el mismo Id");
                    }
                    await CrearRelacionesODS(odsFront);
                    await transaction.CommitAsync();
                    resultado = odsFront;

                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el Ods.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task<OdsFront> EditarOds(OdsFront odsFront)
        {
            OdsFront resultado = null;
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (!await ExisteOds(odsFront.IdOds))
                    {
                        throw new KeyNotFoundException("No existe un Ods con el mismo Id introducido: No se puede editar.");
                    }

                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    Od ods = await _context.Ods.Include(o => o.Meta.Where(met => met.Eliminada == false)).FirstAsync(od => od.IdOds == (short)odsFront.IdOds);

                    if (ods == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear el Ods en su Entidad");
                    }
                    _mappingService.InverseMapOd(odsFront, ods);
                    _context.Ods.Update(ods);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("Error al actualizar el Ods. No se ha modificado ninguna fila.");
                    }
                    //await this.CrearRelacionesODS(odsFront);
                    await transaction.CommitAsync();
                    resultado = odsFront;
                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el Ods.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarOds(int idOds)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (!await ExisteOds(idOds))
                    {
                        throw new KeyNotFoundException("No existe un Ods con el mismo Id introducido: No se puede eliminar.");
                    }

                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    Od ods = await _context.Ods.Include(o => o.Meta.Where(met => met.Eliminada == false)).FirstAsync(od => od.IdOds == (short)idOds);

                    if (ods == null)
                    {
                        throw new ArgumentNullException($"Error al traer el Ods con ID {idOds} de la Base de Datos, a pesar de que SÍ existía");
                    }

                    ods.Eliminada = true;
                    await EliminarRelacionesOds(ods);
                    _context.Ods.Update(ods);
                    int nAfectados = _context.SaveChanges();

                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al eliminar el Ods. No se ha modificado ninguna fila.");
                    }

                    await transaction.CommitAsync();
                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar el Ods.", ex);
                }
            });
        }
        // MÉTODOS PRIVADOS
        private async Task CrearRelacionesODS(OdsFront odsFront)
        {
            try
            {
                if (odsFront == null)
                {
                    throw new ArgumentNullException("El Ods recibido ha sido null");
                }
                foreach (var metaFront in odsFront.Metas)
                {
                    await _metaService.CrearMeta(metaFront, odsFront.IdOds, commitTransaction: false);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new NotImplementedException("Error al tratar de crear las relaciones/metas del Ods");
            }
        }

        private async Task EliminarRelacionesOds(Od ods)
        {
            try
            {
                if (ods == null)
                {
                    throw new ArgumentNullException("El Ods recibido ha sido null");
                }
                if (ods.Meta == null || ods.Meta.Count == 0)
                {
                    Console.WriteLine("El Ods no tiene ninguna Meta: No es un error.");
                    return;
                }
                foreach (var meta in ods.Meta)
                {
                    meta.Eliminada = true;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        private async Task<bool> ExisteOds(int idOds, bool? odsEliminado = false)
        {
            var existeOds = await _context.Ods.AnyAsync(i => i.IdOds == (short)idOds && i.Eliminada == odsEliminado);
            return existeOds;
        }
    }
}
