﻿using ods_4Vientos.server.Models;
using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.ModelosFront;
using Microsoft.EntityFrameworkCore.Storage;
using System.Data;
using ods_4Vientos.server.Services.Utilidades;

namespace ods_4Vientos.server.Services.Entidades
{
    public class EntidadesExternasService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        public EntidadesExternasService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<IEnumerable<EntidadExternaFront>> ObtenerEntidadesExternas()
        {
            List<EntidadesExterna> entidadesExternas;
            try
            {
                entidadesExternas = await _context.EntidadesExternas.Where(entidad => entidad.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las entidades externas");
            }
            return entidadesExternas.Select(entidadExterna => _mappingService.MapEntidadExternaFront(entidadExterna)).ToList();
        }
        public async Task<EntidadExternaFront> CrearEntidadExterna(EntidadExternaFront entidadExternaFront, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            EntidadExternaFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (await ExisteEntidadExterna(entidadExternaFront.Identidad))
                    {
                        throw new DuplicateNameException($"Ya existe una Entidad Externa '{entidadExternaFront.Identidad}' con el mismo Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    EntidadesExterna? entidadExterna = _mappingService.InverseMapEntidadExterna(entidadExternaFront) ?? null;
                    if (entidadExterna == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear la EntidadExterna en su Entidad");
                    }

                    _context.EntidadesExternas.Add(entidadExterna);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar la Entidad Externa, ya existía una Entidad Externa con el mismo Id");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = entidadExternaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar la Entidad Externa: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear la entidad externa.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task<EntidadExternaFront> EditarEntidadExterna(EntidadExternaFront entidadExternaFront, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            EntidadExternaFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteEntidadExterna(entidadExternaFront.Identidad))
                    {
                        throw new KeyNotFoundException($"No existe una Entidad Externa '{entidadExternaFront.Identidad}' con este Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    EntidadesExterna entidadExterna = await _context.EntidadesExternas.FirstAsync(entidad => entidad.Identidad == (short)entidadExternaFront.Identidad);

                    if (entidadExterna == null)
                    {
                        throw new ArgumentNullException($"Error al tratar de traer la EntidadExterna '{entidadExternaFront.Nombre}' de la Base de Datos, aunque esta SÍ existe");
                    }
                    _mappingService.InverseMapEntidadExterna(entidadExternaFront, entidadExterna);

                    _context.EntidadesExternas.Update(entidadExterna);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar la Entidad Externa, ya existía una Entidad Externa con el mismo Id");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = entidadExternaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar la Entidad Externa: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el módulo.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarEntidadExterna(int idEntidadExterna, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteEntidadExterna(idEntidadExterna))
                    {
                        throw new KeyNotFoundException($"No existe una Entidad Externa '{idEntidadExterna}' con este Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    EntidadesExterna entidadExterna = await _context.EntidadesExternas.FirstAsync(entidad => entidad.Identidad == (short)idEntidadExterna);

                    if (entidadExterna == null)
                    {
                        throw new ArgumentNullException($"Error al tratar de traer la EntidadExterna por Id '{idEntidadExterna}' de la Base de Datos, aunque esta SÍ existe");
                    }

                    entidadExterna.Eliminada = true;
                    _context.EntidadesExternas.Update(entidadExterna);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al eliminar la Entidad Externa en la base de datos, ninguna fila afectada.");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al borrar la Entidad Externa: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar la Entidad Externa.", ex);
                }
            });
        }
        public async Task<IEnumerable<EntidadesExterna>> CrearRelacionesEntidadesExternas(List<EntidadExternaFront> entidadesExternasFront)
        {
            try
            {
                var entidadesExternas = new List<EntidadesExterna>();
                foreach (var entExtFront in entidadesExternasFront)
                {
                    var entidadExterna = await _context.EntidadesExternas
                        .FirstOrDefaultAsync(entExt => entExt.Identidad == entExtFront.Identidad);
                    if (entidadExterna != null)
                    {
                        entidadesExternas.Add(entidadExterna);
                    }
                }
                return entidadesExternas;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las entidades externas de Iniciativa");
            }
        }
        // MÉTODOS PRIVADOS
        private async Task<bool> ExisteEntidadExterna(int idEntidad, bool? EntidadExternaEliminada = false)
        {
            var existeEntidadExterna = await _context.EntidadesExternas.AnyAsync(i => i.Identidad == (short)idEntidad && i.Eliminada == EntidadExternaEliminada);
            return existeEntidadExterna;
        }
    }
}
