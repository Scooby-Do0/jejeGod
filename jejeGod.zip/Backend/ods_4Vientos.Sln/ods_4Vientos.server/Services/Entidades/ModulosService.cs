﻿using ods_4Vientos.server.Models;
using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.ModelosFront;
using System.Data;
using Microsoft.EntityFrameworkCore.Storage;
using System.Transactions;
using ods_4Vientos.server.Services.Utilidades;

namespace ods_4Vientos.server.Services.Entidades
{
    public class ModulosService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;

        public ModulosService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<IEnumerable<ModuloFront>> ObtenerModulos()
        {
            List<Modulo> modulos;
            try
            {
                modulos = await _context.Modulos.Where(modulo => modulo.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los modulos");
            }
            return modulos.Select(modulo => _mappingService.MapModuloFront(modulo)).ToList();
        }

        public async Task<IEnumerable<ModuloFront>> ObtenerModulosDeCiclo(short idCiclo)
        {
            List<Modulo> modulos;
            try
            {
                modulos = await _context.Modulos.Where(mod => mod.IdCiclo == idCiclo && mod.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los modulos");
            }
            return modulos.Select(modulo => _mappingService.MapModuloFront(modulo)).ToList();
        }

        public async Task<ModuloFront> CrearModulo(ModuloFront moduloFront, int idCiclo, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            ModuloFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (await ExisteModulo(moduloFront.IdModulo, idCiclo))
                    {
                        throw new DuplicateNameException($"Ya existe un módulo '{moduloFront.IdModulo}' con el mismo Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Modulo? modulo = _mappingService.InverseMapModulo(moduloFront, idCiclo) ?? null;
                    if (modulo == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear el módulo en su Entidad");
                    }

                    _context.Modulos.Add(modulo);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar el módulo, ya existía un módulo con el mismo Id");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = moduloFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar el módulo: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el módulo.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task<ModuloFront> EditarModulo(ModuloFront moduloFront, int idCiclo, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            ModuloFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteModulo(moduloFront.IdModulo, idCiclo))
                    {
                        throw new DuplicateNameException($"No existe un módulo con el id '{moduloFront.IdModulo}', en el ciclo con id '{idCiclo}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Modulo modulo = await _context.Modulos.FirstAsync(modul => modul.IdModulo == (short)moduloFront.IdModulo && modul.IdCiclo == (short)idCiclo);
                    if (modulo == null)
                    {
                        throw new ArgumentNullException("Error al traer el módulo de la base de datos, a pesar de que SÍ existía");
                    }

                    _mappingService.InverseMapModulo(moduloFront, idCiclo, modulo);
                    _context.Modulos.Update(modulo);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al editar el módulo, ya existía un módulo con el mismo Id.");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                    resultado = moduloFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al actualizar el módulo: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al actualizar el módulo.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarModulo(int idModulo, int idCiclo, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteModulo(idModulo, idCiclo))
                    {
                        throw new DuplicateNameException($"No existe un módulo con el ID '{idModulo}', en el ciclo con id '{idCiclo}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Modulo modulo = await _context.Modulos.FirstAsync(modul => modul.IdModulo == (short)idModulo && modul.IdCiclo == (short)idCiclo);
                    if (modulo == null)
                    {
                        throw new ArgumentNullException($"Error al traer el módulo de la base de datos con ID {idModulo}, a pesar de que este SÍ existía");
                    }

                    modulo.Eliminada = true;
                    _context.Modulos.Update(modulo);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException($"Error al borrar el módulo con id {modulo.IdModulo} en el ciclo {idCiclo}.");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al eliminar el módulo: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar el módulo.", ex);
                }
            });
        }
        public async Task<IEnumerable<Modulo>> CrearRelacionesModulos(List<CicloFront> ciclosFront)
        {
            Dictionary<ModuloFront, int> modulosDelFront = AplanarListaMetas(ciclosFront);
            var modulos = new List<Modulo>();
            try
            {
                foreach (var (mod, idCiclo) in modulosDelFront)
                {
                    var modulo = await _context.Modulos.FirstOrDefaultAsync(m => m.IdModulo == mod.IdModulo && m.IdCiclo == (short) idCiclo) as Modulo;
                    if (modulo != null)
                    {
                        modulos.Add(modulo);
                    }
                }
                return modulos;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los módulos de la iniciativa");
            }
        }

        private Dictionary<ModuloFront, int> AplanarListaMetas(List<CicloFront> ciclosFront)
        {
            Dictionary<ModuloFront, int> modulosDelFront = ciclosFront.SelectMany(ciclo => ciclo.Modulos.Select(modulo => new { Modulo = modulo, Ciclo = ciclo.IdCiclo }))
               .ToDictionary(entrada => entrada.Modulo, entrada => entrada.Ciclo);
            return modulosDelFront;
        }

        private async Task<bool> ExisteModulo(int idModulo, int idCiclo, bool? moduloEliminado = false)
        {
            var existeCiclo = await _context.Modulos.AnyAsync(i => i.IdModulo == (short)idModulo && i.IdCiclo == (short)idCiclo);
            return existeCiclo;
        }
    }
}
