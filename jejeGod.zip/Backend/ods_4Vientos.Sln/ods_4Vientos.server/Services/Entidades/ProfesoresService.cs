﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Utilidades;
using System.Data;

namespace ods_4Vientos.server.Services.Entidades
{
    public class ProfesoresService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        public ProfesoresService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<IEnumerable<ProfesorFront>> ObtenerProfesores()
        {
            List<Profesore> profesores;
            try
            {
                profesores = await _context.Profesores.Where(profe => profe.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los profesores");
            }
            return profesores.Select(profesor => _mappingService.MapProfesorFront(profesor)).ToList();
        }
        public async Task<ProfesorFront> CrearProfesor(ProfesorFront profesorFront, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            ProfesorFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (await ExisteProfesor(profesorFront.IdProfesor))
                    {
                        throw new DuplicateNameException($"Ya existe un Profesor '{profesorFront.IdProfesor}' con el mismo Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Profesore? profesor = _mappingService.InverseMapProfesor(profesorFront) ?? null;
                    if (profesor == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear el Profesor en su Entidad");
                    }

                    _context.Profesores.Add(profesor);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar el Profesor, ya existía un Profesor con el mismo Id");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = profesorFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar el Profesor: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el Profesor.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task<ProfesorFront> EditarProfesor(ProfesorFront profesorFront, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            ProfesorFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteProfesor(profesorFront.IdProfesor))
                    {
                        throw new KeyNotFoundException($"No existe un Profesor con el Id '{profesorFront.IdProfesor}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }
                    Profesore profesor = await _context.Profesores.FirstAsync(profe => profe.IdProfesor == (short)profesorFront.IdProfesor);

                    if (profesor == null)
                    {
                        throw new ArgumentNullException($"Error al traer el Profesor '{profesorFront.Nombre}' de la base de datos, aunque este SÍ existía");
                    }
                    _mappingService.InverseMapProfesor(profesorFront, profesor);
                    _context.Profesores.Update(profesor);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("Error al actualizar el Profesor en la base de datos.");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = profesorFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar el Profesor: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al actualizar el Profesor.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarProfesor(int idProfesor, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteProfesor(idProfesor))
                    {
                        throw new KeyNotFoundException($"No existe un Profesor con el Id '{idProfesor}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }
                    Profesore profesor = await _context.Profesores.FirstAsync(profe => profe.IdProfesor == (short)idProfesor);

                    if (profesor == null)
                    {
                        throw new ArgumentNullException($"Error al traer el Profesor con ID '{idProfesor}' de la base de datos, aunque este SÍ existía");
                    }
                    profesor.Eliminada = true;
                    _context.Profesores.Update(profesor);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("Error al borrar el Profesor en la base de datos.");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar el Profesor: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar el Profesor.", ex);
                }
            });
        }
        public async Task<IEnumerable<Profesore>> CrearRelacionProfesores(List<ProfesorFront> profesoresFront)
        {
            var profesores = new List<Profesore>();
            try
            {
                foreach(ProfesorFront profesorFront in profesoresFront)
                {
                    var profesor = await _context.Profesores.FirstOrDefaultAsync(prof => prof.IdProfesor == profesorFront.IdProfesor) as Profesore;
                    if (profesor != null)
                    {
                        profesores.Add(profesor);
                    }
                }
                return profesores.ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los profesores de la iniciativa");
            }
        }

        // MÉTODOS PRIVADOS
        private async Task<bool> ExisteProfesor(int idProfesor, bool? profesorEliminado = false)
        {
            var existeProfesor = await _context.Profesores.AnyAsync(i => i.IdProfesor == (short)idProfesor && i.Eliminada == profesorEliminado);
            return existeProfesor;
        }
    }
}

