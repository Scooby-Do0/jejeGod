﻿using ods_4Vientos.server.Models;
using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.ModelosFront;
using System.Data;
using ods_4Vientos.server.Services.Utilidades;


namespace ods_4Vientos.server.Services.Entidades
{
    public class DifusionIniciativaService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;

        public DifusionIniciativaService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<IEnumerable<DifusionFront>> ObtenerDifusionIniciativas()
        {
            List<DifusionIniciativa> difusionIniciativas;
            try
            {
                difusionIniciativas = await _context.DifusionIniciativas.ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new NotImplementedException("Error al recoger las difusiones de iniciativas");
            }
            return difusionIniciativas.Select(difusion => _mappingService.MapDifusionFront(difusion)).ToList();
        }

        public async Task<List<DifusionIniciativa>> CrearRelacionDifusionIniciativas(List<DifusionFront> difusionesFront, int idIniciativa = 0, List<DifusionIniciativa>? difusiones = null)
        {
            difusiones = difusiones ?? new List<DifusionIniciativa>();
            try
            {
                var difusionesFrontNuevas = difusionesFront.Where(difuFront => !difusiones.Any(difuIni => difuIni.Iddifusion == difuFront.Iddifusion)).ToList();
                if (difusiones.Count != 0)
                {
                    difusiones.RemoveAll(difusion => !difusionesFront.Any(difuFront => difuFront.Iddifusion == difusion.Iddifusion));
                }
                var difusionesFrontExisten = difusionesFront.Where(difuFront => difusiones.Any(difuIni => difuIni.Iddifusion == difuFront.Iddifusion)).ToList();

                foreach (DifusionFront difusionFront in difusionesFrontExisten)
                {
                    var difusionIniciativaFront = await EditarDifusionIniciativa(difusionFront, idIniciativa) as DifusionFront;
                }

                foreach (DifusionFront difusionFront in difusionesFrontNuevas)
                {
                    var difusionIniciativa = await CrearDifusionIniciativa(difusionFront, idIniciativa) as DifusionIniciativa;
                    if (difusionIniciativa != null)
                    {
                        difusiones.Add(difusionIniciativa);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new NotImplementedException("Error al crear las difusiones de la iniciativa nueva");
            }
            return difusiones;
        }
        public async Task<DifusionFront> EditarDifusionIniciativa(DifusionFront difusionFront, int idIniciativa)
        {
            DifusionFront? resultado = null;
            try
            {
                DifusionIniciativa? difusionIniciativa = await _context.DifusionIniciativas.FirstOrDefaultAsync(difusio => difusio.Iddifusion == difusionFront.Iddifusion && difusio.Idiniciativa == (short)idIniciativa);

                if (difusionIniciativa == null)
                {
                    throw new ArgumentNullException($"Error al tratar de obtener la Difusión {difusionFront.Iddifusion} de la BBDD, aunque SÍ existe.");
                }

                _mappingService.InverseMapDifusion(difusionFront, idIniciativa, difusionIniciativa);
                _context.DifusionIniciativas.Update(difusionIniciativa);
                int nAfectados = await _context.SaveChangesAsync();

                if (nAfectados == 0)
                {
                    throw new DuplicateNameException($"Error al editar la Difusión '{difusionFront.Iddifusion}'.");
                }
                resultado = difusionFront;
            }
            catch (DbUpdateException dbEx)
            {
                Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
            }
            catch (DuplicateNameException ex)
            {
                Console.WriteLine($"Error al actualizar la Difusión {difusionFront.Iddifusion}: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error general: {ex.Message}");
                throw new NotImplementedException("Ha ocurrido un error general al editar la Difusión.", ex);
            }
            return resultado;
        }

        public async Task<DifusionFront> BorrarDifusionIniciativa(DifusionFront difusionFront, int idIniciativa)
        {
            DifusionFront? resultado = null;
            try
            {
                DifusionIniciativa? difusionIniciativa = await _context.DifusionIniciativas.FirstOrDefaultAsync(difusio => difusio.Iddifusion == difusionFront.Iddifusion && difusio.Idiniciativa == (short)idIniciativa);

                if (difusionIniciativa == null)
                {
                    throw new ArgumentNullException($"Error al tratar de obtener la Difusión {difusionFront.Iddifusion} de la BBDD, aunque SÍ existe.");
                }
                _context.DifusionIniciativas.Remove(difusionIniciativa);
                int nAfectados = await _context.SaveChangesAsync();

                if (nAfectados == 0)
                {
                    throw new NotImplementedException($"Error al borrar la Difusión con id '{difusionFront.Iddifusion}'");
                }
                resultado = difusionFront;
            }
            catch (DbUpdateException dbEx)
            {
                Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
            }
            catch (DuplicateNameException ex)
            {
                Console.WriteLine($"Error al borrar la Difusión {difusionFront.Iddifusion}: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error general: {ex.Message}");
                throw new NotImplementedException("Ha ocurrido un error general al borrar la Difusión.", ex);
            }
            return resultado;
        }
        // MÉTODOS PRIVADOS
        private async Task<DifusionIniciativa> CrearDifusionIniciativa(DifusionFront difusionFront, int idIniciativa)
        {
            DifusionIniciativa? resultado = null;
            try
            {

                DifusionIniciativa? difusion = _mappingService.InverseMapDifusion(difusionFront, idIniciativa) ?? null;
                if (difusion == null)
                {
                    throw new ArgumentNullException("Error al tratar de mapear la Difusión en su Entidad");
                }

                _context.DifusionIniciativas.Add(difusion);
                int nAfectados = await _context.SaveChangesAsync();
                if (nAfectados == 0)
                {
                    throw new DuplicateNameException($"Error al guardar la Difusión '{difusionFront.Iddifusion}', ya existía un módulo con el mismo Id");
                }

                resultado = difusion;
            }
            catch (DbUpdateException dbEx)
            {
                Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
            }
            catch (DuplicateNameException ex)
            {
                Console.WriteLine($"Error al guardar la Difusión: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error general: {ex.Message}");
                throw new NotImplementedException("Ha ocurrido un error general al crear la Difusión.", ex);
            }
            return resultado;
        }

        private async Task<bool> ExisteDifusion(DifusionFront difusionFront, int idIniciativa)
        {
            var existeDifusion = await _context.DifusionIniciativas.AnyAsync(i => i.Iddifusion == difusionFront.Iddifusion && i.Idiniciativa == (short)idIniciativa);
            return existeDifusion;
        }
    }
}
