﻿using ods_4Vientos.server.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ods_4Vientos.server.ModelosFront;
using System.Data;
using ods_4Vientos.server.Services.Utilidades;

namespace ods_4Vientos.server.Services.Entidades
{
    public class CicloService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        private readonly ModulosService _moduloService;

        public CicloService(Proyecto4vodsContext context, IMappingService mappingService, ModulosService moduloService)
        {
            _context = context;
            _mappingService = mappingService;
            _moduloService = moduloService;
        }

        public async Task<IEnumerable<CicloFront>> ObtenerCiclos()
        {
            List<Ciclo> ciclos;
            try
            {
                ciclos = await _context.Ciclos.Include(c => c.Modulos.Where(modul => modul.Eliminada == false)).Where(cicl => cicl.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger los ciclos");
            }
            return ciclos.Select(ciclo => _mappingService.MapCicloFront(ciclo)).ToList();
        }

        public async Task<CicloFront> CrearCiclo(CicloFront cicloFront)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (await ExisteCiclo(cicloFront.IdCiclo))
                    {
                        throw new KeyNotFoundException("Ya existe un ciclo con el mismo Id");
                    }

                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    Ciclo? ciclo = _mappingService.InverseMapCiclo(cicloFront) ?? null;

                    if (ciclo == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear el CicloFront en su Entidad");
                    }

                    _context.Ciclos.Add(ciclo);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar la ciclo, ya existía una ciclo con el mismo Id");
                    }
                    await CrearRelacionesCiclo(cicloFront);
                    await transaction.CommitAsync();

                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear el ciclo.", ex);
                }
                return cicloFront;
            });
            return null;
        }

        public async Task<CicloFront> EditarCiclo(CicloFront cicloFront)
        {
            CicloFront? resultado = null;
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (!await ExisteCiclo(cicloFront.IdCiclo))
                    {
                        throw new KeyNotFoundException($"No existe un ciclo con el Id '{cicloFront.IdCiclo}'");
                    }

                    Ciclo ciclo = await _context.Ciclos.Include(cic => cic.Modulos.Where(modul => modul.Eliminada == false)).FirstAsync(cicl => cicl.IdCiclo == (short)cicloFront.IdCiclo);
                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    _mappingService.InverseMapCiclo(cicloFront, ciclo);

                    if (ciclo == null)
                    {
                        throw new ArgumentNullException($"Error al tratar de traer el Ciclo de nombre '{cicloFront.NombreCiclo}' de la base de datos, aunque este sí existe.");
                    }

                    _context.Ciclos.Update(ciclo);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("No se ha podido actualizar el ciclo en la base de datos.");
                    }
                    //await this.CrearRelacionesCiclo(cicloFront);
                    await transaction.CommitAsync();
                    resultado = cicloFront;
                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al actualizar el ciclo: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al actualizar el ciclo.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarCiclo(int idCiclo)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                try
                {
                    if (!await ExisteCiclo(idCiclo))
                    {
                        throw new KeyNotFoundException($"No existe un ciclo con el Id '{idCiclo}'");
                    }

                    Ciclo ciclo = await _context.Ciclos.Include(cic => cic.Modulos.Where(modul => modul.Eliminada == false)).FirstAsync(cicl => cicl.IdCiclo == (short)idCiclo);

                    if (ciclo == null)
                    {
                        throw new ArgumentNullException($"Error al tratar de traer el Ciclo con Id '{idCiclo}' de la base de datos, aunque este sí existe.");
                    }

                    await using var transaction = await _context.Database.BeginTransactionAsync();
                    ciclo.Eliminada = true;
                    await EliminarRelacionesCiclo(ciclo);
                    _context.Ciclos.Update(ciclo);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("No se ha podido borrar el ciclo en la base de datos.");
                    }
                    await transaction.CommitAsync();
                }
                catch (DbUpdateException dbEx)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    Console.WriteLine($"Error al borrar el ciclo: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await _context.Database.RollbackTransactionAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar el ciclo.", ex);
                }
            });
        }
        // MÉTODOS PRIVADOS
        private async Task CrearRelacionesCiclo(CicloFront cicloFront)
        {
            try
            {
                if (cicloFront == null) {
                    throw new ArgumentNullException("El ciclo recibido ha sido null");
                }
                foreach (var moduloFront in cicloFront.Modulos)
                {
                    await _moduloService.CrearModulo(moduloFront, cicloFront.IdCiclo, commitTransaction: false);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new NotImplementedException("Error al tratar de crear las relaciones/módulos del ciclo");
            }
        }

        private async Task EliminarRelacionesCiclo(Ciclo ciclo)
        {
            try
            {
                if (ciclo == null)
                {
                    throw new ArgumentNullException("El ciclo recibido ha sido null");
                }
                if (ciclo.Modulos == null || ciclo.Modulos.Count == 0)
                {
                    Console.WriteLine("El ciclo no tiene ningún módulo: No es un error.");
                    return;
                }

                foreach (var modulo in ciclo.Modulos)
                {
                    modulo.Eliminada = true;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
        
        private async Task<bool> ExisteCiclo(int idCiclo, bool? cicloEliminado = false)
        {
            var existeCiclo = await _context.Ciclos.AnyAsync(i => i.IdCiclo == (short)idCiclo && i.Eliminada == cicloEliminado);
            return existeCiclo;
        }
    }
}
