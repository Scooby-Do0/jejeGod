﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Utilidades;
using System.Data;

namespace ods_4Vientos.server.Services.Entidades
{
    public class MetaService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        public MetaService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<IEnumerable<MetaFront>> ObtenerMetas()
        {
            List<Meta> metas;
            try
            {
                metas = await _context.Metas.Where(meta => meta.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las metas");
            }
            return metas.Select(meta => _mappingService.MapMetaFront(meta)).ToList();
        }

        public async Task<IEnumerable<MetaFront>> ObtenerMetasDeOds(short idOds)
        {
            List<Meta> metas;
            try
            {
                metas = await _context.Metas.Where(m => m.IdOds == idOds && m.Eliminada == false).ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las metas");
            }
            return metas.Select(meta => _mappingService.MapMetaFront(meta)).ToList();
        }

        public async Task<MetaFront> CrearMeta(MetaFront metaFront, int idOds, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            MetaFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (await ExisteMeta(metaFront.IdMeta, idOds))
                    {
                        throw new DuplicateNameException("Ya existe un módulo con el mismo Id");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Meta? meta = _mappingService.InverseMapMeta(metaFront, idOds) ?? null;
                    if (meta == null)
                    {
                        throw new ArgumentNullException("Error al tratar de mapear la meta en su Entidad");
                    }

                    _context.Metas.Add(meta);
                    int nAfectados = await _context.SaveChangesAsync();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException($"Error al guardar la meta '{metaFront.IdMeta}', ya existía un módulo con el mismo Id");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = metaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar la meta: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear la meta.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task<MetaFront> EditarMeta(MetaFront metaFront, int idOds, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            MetaFront? resultado = null;
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteMeta(metaFront.IdMeta, idOds))
                    {
                        throw new KeyNotFoundException($"No existe una meta con el mismo Id introducido: '{metaFront.IdMeta}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Meta meta = await _context.Metas.FirstAsync(met => met.IdMeta == metaFront.IdMeta && met.IdOds == (short)idOds);

                    if (meta == null)
                    {
                        throw new ArgumentNullException("Error al tratar de traer la meta de la base de datos");
                    }

                    _mappingService.InverseMapMeta(metaFront, idOds, meta);
                    _context.Metas.Update(meta);
                    int nAfectados = await _context.SaveChangesAsync();

                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException($"Error al actualizar la meta de nombre '{metaFront.IdMeta}'");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }

                    resultado = metaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar la meta: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear la meta.", ex);
                }
                return resultado;
            });
            return resultado;
        }

        public async Task BorrarMeta(string idMeta, int idOds, bool commitTransaction = true)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                IDbContextTransaction? transaction = null;
                try
                {
                    if (!await ExisteMeta(idMeta, idOds))
                    {
                        throw new KeyNotFoundException($"No existe una meta con el mismo Id introducido: '{idMeta}'");
                    }

                    if (commitTransaction)
                    {
                        transaction = await _context.Database.BeginTransactionAsync();
                    }

                    Meta meta = await _context.Metas.FirstAsync(met => met.IdMeta == idMeta && met.IdOds == (short)idOds);

                    if (meta == null)
                    {
                        throw new ArgumentNullException("Error al tratar de traer la meta de la base de datos, aunque esta SÍ existe.");
                    }
                    meta.Eliminada = true;
                    _context.Metas.Update(meta);
                    int nAfectados = await _context.SaveChangesAsync();

                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException($"Error al borrar la meta con Id '{idMeta}'");
                    }

                    if (commitTransaction && transaction != null)
                    {
                        await transaction.CommitAsync();
                    }
                }
                catch (DbUpdateException dbEx)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}", dbEx);
                }
                catch (InvalidOperationException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error al borrar la meta: {ex.Message}");
                    throw;
                }
                catch (Exception ex)
                {
                    if (commitTransaction && transaction != null)
                    {
                        await transaction.RollbackAsync();
                    }
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al borrar la meta.", ex);
                }
            });
        }
        public async Task<IEnumerable<Meta>> CrearRelacionesMetas(List<OdsFront> odsFronts)
        {
            Dictionary<MetaFront, int> metasDelFront = AplanarListaMetas(odsFronts);
            var metas = new List<Meta>();
            try
            {
                foreach (var (metaFront, idOds) in metasDelFront)
                {
                    var meta = await _context.Metas.FirstOrDefaultAsync(m => m.IdMeta == metaFront.IdMeta && m.IdOds == (short)idOds);
                    if (meta != null)
                    {
                        metas.Add(meta);
                    }
                }
                return metas;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las metas");
            }
        }
        //MÉTODOS PRIVADOS
        private Dictionary<MetaFront, int> AplanarListaMetas(List<OdsFront> odsFronts)
        {

            Dictionary<MetaFront, int> metasDelFront = odsFronts.SelectMany(ods => ods.Metas.Select(meta => new { Meta = meta, Ods = ods.IdOds }))
                .ToDictionary(entrada => entrada.Meta, entrada => entrada.Ods);
            return metasDelFront;
        }

        private async Task<bool> ExisteMeta(string idMeta, int idOds, bool? metaEliminada = false)
        {
            var existeMeta = await _context.Metas.AnyAsync(i => i.IdMeta == idMeta && i.IdOds == (short)idOds && i.Eliminada == false);
            return existeMeta;
        }
    }
}
