﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Utilidades;

namespace ods_4Vientos.server.Services
{
    public class IndicadoresService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;

        public IndicadoresService(Proyecto4vodsContext context, IMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }

        public async Task<object> ObtenerCursos()
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                      .ToListAsync();

                var resultado = iniciativas.Select(i => i.CursoAcademico).Distinct().ToList();
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<object> IndicadorUno(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                     .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.Meta)
                        .ThenInclude(m => m.IdOdsNavigation)
                    .ToListAsync();

                var resultado = new
                {
                    indicador1 = iniciativas
                    .SelectMany(i => i.Meta
                        .Where(m => m.IdOdsNavigation != null)
                        .Select(m => new { ODS = m.IdOdsNavigation!.Nombre, Iniciativa = i.Nombre })
                    )
                    .GroupBy(i => i.ODS)
                    .Select(g => new
                    {
                        ODS = g.Key,
                        Iniciativas = g.Select(i => i.Iniciativa).Distinct().OrderBy(n => n)
                    })
                    .ToList()

                };

                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }


        public async Task<Object> IndicadorDos(string? cursoAcademico)
        {
            List<Iniciativa> iniciativasFiltradas;
            try
            {
                List<Iniciativa> iniciativas;
                iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.DifusionIniciativas)
                    .Include(i => i.Meta).ThenInclude(me => me.IdOdsNavigation)
                    .Include(i => i.Modulos).ThenInclude(mo => mo.IdCicloNavigation)
                    .Include(i => i.IdProfesors)
                    .Include(i => i.Identidads)
                    .ToListAsync();
                iniciativasFiltradas = iniciativas.Where(i => i.CursoAcademico == cursoAcademico).ToList();
                List<String> cursosAcademicosEncontrados = iniciativas.Select(i => (i.CursoAcademico ?? "Sin curso")).Distinct().ToList();
                cursosAcademicosEncontrados.Sort();
                var indicador2 = cursosAcademicosEncontrados
                .ToDictionary(
                    curso => curso,
                    curso => new
                    {
                        Proyecto = iniciativas.Count(i =>
                            string.Equals(i.TipoIniciativa, "Proyecto", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(i.CursoAcademico, curso, StringComparison.OrdinalIgnoreCase)
                        ),
                        Charla = iniciativas.Count(i =>
                            string.Equals(i.TipoIniciativa, "Charla", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(i.CursoAcademico, curso, StringComparison.OrdinalIgnoreCase)
                        ),
                        Taller = iniciativas.Count(i =>
                            string.Equals(i.TipoIniciativa, "Taller", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(i.CursoAcademico, curso, StringComparison.OrdinalIgnoreCase)
                        ),
                        Visita = iniciativas.Count(i =>
                            string.Equals(i.TipoIniciativa, "Visita", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(i.CursoAcademico, curso, StringComparison.OrdinalIgnoreCase)
                        ),
                        Otro = iniciativas.Count(i =>
                            string.Equals(i.TipoIniciativa, "Otro", StringComparison.OrdinalIgnoreCase)
                            && string.Equals(i.CursoAcademico, curso, StringComparison.OrdinalIgnoreCase)
                        )
                    });
                var resultado = new
                {
                    indicador2
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<object> IndicadorTres(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
             .Include(i => i.Modulos)
                 .ThenInclude(m => m.IdCicloNavigation)
             .ToListAsync();

                var resultado = new
                {
                    indicador3 = iniciativas
                    .SelectMany(i => i.Modulos.Select(m => new
                    {
                        cicloId = m.IdCicloNavigation.IdCiclo,
                        cicloNombre = m.IdCicloNavigation.NombreCiclo,
                        moduloNombre = m.Nombre,
                        iniciativaNombre = i.Nombre
                    }))
                    .GroupBy(x => new { x.cicloId, x.cicloNombre })
                    .Select(g => new
                    {
                        Ciclo = g.Key.cicloNombre,
                        Modulos = g.Select(x => x.moduloNombre).Distinct(),
                        Iniciativas = g.Select(x => x.iniciativaNombre).Distinct()
                    })
                    .ToList()
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<IEnumerable<object>> IndicadorCuatro(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
             .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
             .Select(i => new
             {
                 i.Nombre,
                 i.Descripcion
             })
             .ToListAsync();

                return iniciativas;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<object> IndicadorCinco(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.Meta)
                        .ThenInclude(m => m.IdOdsNavigation)
                    .ToListAsync();

                var resultado = new
                {
                    indicador5 = iniciativas
                    .SelectMany(i => i.Meta.Select(m => new
                    {
                        odsId = m.IdOdsNavigation!.IdOds,
                        odsNombre = m.IdOds + ". " + m.IdOdsNavigation!.Nombre,
                        metaNombre = m.IdOds + "." + m.IdMeta,
                        iniciativaNombre = i.Nombre
                    }))
                    .GroupBy(x => new { x.odsId, x.odsNombre })
                    .Select(g => new
                    {
                        Ods = g.Key.odsNombre,
                        Metas = g.Select(x => x.metaNombre).Distinct(),
                        Iniciativas = g.Select(x => x.iniciativaNombre).Distinct()
                    })
                    .ToList()
                };

                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<object> IndicadorSeis(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.Identidads)
                    .ToListAsync();

                var resultado = new
                {
                    indicador6 = iniciativas
                    .Where(i => i.Identidads.Any())
                    .Select(i => new
                    {
                        Iniciativa = i.Nombre,
                        EntidadesExternas = i.Identidads.Select(e => e.Nombre)
                    })
                    .ToList()
                };

                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        public async Task<object> IndicadorSiete(string? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.DifusionIniciativas)
                    .ToListAsync();

                var resultado = new
                {
                    indicador7 = iniciativas
                    .Where(i => i.DifusionIniciativas.Any())
                    .Select(i => new
                    {
                        Iniciativa = i.Nombre,
                        Difusiones = i.DifusionIniciativas.Select(e => new { e.Tipo, e.Enlace }),

                    })
                    .ToList()
                };

                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        /*     Diferenciar si son Proyectos (títulos y número), charlas o talleres (títulos y número).
       */
        public async Task<object> IndicadorOcho(String? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .ToListAsync();
                List<String> cursosAcademicosEncontrados = iniciativas.Select(i => (i.CursoAcademico ?? "Sin curso")).Distinct().ToList();
                cursosAcademicosEncontrados.Sort();
                var indicador8 = cursosAcademicosEncontrados.ToDictionary(
                    curso => curso,
                    curso => new
                    {
                        Valor = new
                        {
                            Cantidad = iniciativas.Count(i => (i.TipoIniciativa ?? String.Empty).Equals("Proyecto", StringComparison.CurrentCultureIgnoreCase)),
                            Titulos = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).Equals("Proyecto", StringComparison.CurrentCultureIgnoreCase)).Select(i => i.Nombre).ToList()
                        },
                        Charla = new
                        {
                            Cantidad = iniciativas.Count(i => (i.TipoIniciativa ?? String.Empty).Equals("Charla", StringComparison.CurrentCultureIgnoreCase)),
                            Titulos = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).Equals("Charla", StringComparison.CurrentCultureIgnoreCase)).Select(i => i.Nombre).ToList()
                        },
                        Taller = new
                        {
                            Cantidad = iniciativas.Count(i => (i.TipoIniciativa ?? String.Empty).Equals("Taller", StringComparison.CurrentCultureIgnoreCase)),
                            Titulos = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).Equals("Taller", StringComparison.CurrentCultureIgnoreCase)).Select(i => i.Nombre).ToList()
                        },
                        Visita = new
                        {
                            Cantidad = iniciativas.Count(i => (i.TipoIniciativa ?? String.Empty).Equals("Visita", StringComparison.CurrentCultureIgnoreCase)),
                            Titulos = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).Equals("Visita", StringComparison.CurrentCultureIgnoreCase)).Select(i => i.Nombre).ToList()
                        },
                        Otro = new
                        {
                            Cantidad = iniciativas.Count(i => (i.TipoIniciativa ?? String.Empty).Equals("Otro", StringComparison.CurrentCultureIgnoreCase)),
                            Titulos = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).Equals("Otro", StringComparison.CurrentCultureIgnoreCase)).Select(i => i.Nombre).ToList()
                        }

                    });

                var resultado = new
                {
                    indicador8
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger el indicador 8");
            }
        }

        /*     
         * REQUISITO: Cada ODS, y por lo tanto cada proyecto, charla…, está vinculada a una dimensión. Las dimensiones de Cuatrovientos son Dimensión Social, Dimensión
                Económica y Dimensión Medioambiental. Clasificados Genially vinculado a la diapositiva 2 de la presentación, pinchando en el logo de los ODS.
           
           INPUT: ¿Se requiere el nombre, dimension?
        */
        public async Task<object> Indicador9(String? cursoAcademico)
        {
            const String SOCIAL = "Social";
            const String ECONOMICA = "Económica";
            const String MEDIOAMBIENTAL = "Medioambiental";
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.Meta).ThenInclude(m => m.IdOdsNavigation)
                    .ToListAsync();

                List<String> cursosAcademicosEncontrados = iniciativas.Select(i => (i.CursoAcademico ?? "Sin curso")).Distinct().ToList();
                cursosAcademicosEncontrados.Sort();
                var dimensiones = iniciativas.SelectMany(i => i.Meta.Select(meta => meta.IdOdsNavigation.Dimension).Distinct()).ToList();
                var resultadoIntermedio = iniciativas.Select(i => new
                {
                    Titulo = i.Nombre,
                    Dimensiones = dimensiones,
                    Curso = i.CursoAcademico ?? ""
                });

                var indicador9 = cursosAcademicosEncontrados.ToDictionary(
                    curso => curso,
                    curso => new
                    {
                        Social = resultadoIntermedio
                       .Where(resul => resul.Dimensiones.Any(dimen => dimen.Equals(SOCIAL, StringComparison.OrdinalIgnoreCase))).Select(resul => new
                       {
                           resul.Titulo,
                           resul.Curso
                       }).ToList(),
                        Económica = resultadoIntermedio
                       .Where(resul => resul.Dimensiones.Any(dimen => dimen.Equals(ECONOMICA, StringComparison.OrdinalIgnoreCase))).Select(resul => new
                       {
                           resul.Titulo,
                           resul.Curso
                       }).ToList(),
                        Medioambiental = resultadoIntermedio
                       .Where(resul => resul.Dimensiones.Any(dimen => dimen.Equals(MEDIOAMBIENTAL, StringComparison.OrdinalIgnoreCase))).Select(resul => new
                       {
                           resul.Titulo,
                           resul.Curso
                       }).ToList()
                    });

                var resultado = new
                {
                    indicador9
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        /* REQUISITO: Personas que han sido responsables de las iniciativas, proyectos,..,número de personas (profesores o trabajadores).
         * 
         * INPUT: ¿Una persona RESPONSABLE es toda persona asignada a un proyecto? ¿O RESPONSABLE es un nuevo campo?
         */
        public async Task<object> Indicador10(String? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .Include(i => i.IdProfesors)
                    .ToListAsync();

                var resultado = new
                {
                    indicador10 = iniciativas
                    .Select(i => new
                    {
                        Iniciativa = i.Nombre,
                        Profesores = i.IdProfesors.Select(p => p.Nombre)
                    })
                    .GroupBy(i => i.Iniciativa)
                    .Select(g => new
                    {
                        Iniciativa = g.Key,
                        Profesores = g.SelectMany(i => i.Profesores).Distinct(),
                        NumeroProfesores = g.SelectMany(i => i.Profesores).Distinct().Count()
                    })
                    .ToList()
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        /* REQUISITO: De las acciones realizadas cuales son nuevas, innovadoras o que han hecho alguna modificación importante.
         *
         * INPUT: ¿Qué es modificación importante, más allá de Innovadora? ¿Dónde puedo saber si se ha hecho una modificación importante?
         */

        public async Task<object> Indicador11(String? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .ToListAsync();
                DateTime fechaActual = DateTime.Now;
                const int FECHA_RECIENTE = 30; // Días para considerar una iniciativa como reciente
                var resultado = new
                {
                    indicador11 = new
                    {
                        todas = iniciativas.ToList(),
                        nuevas = iniciativas.Where(i => i.FechaInicio >= fechaActual.AddDays(-FECHA_RECIENTE)),
                        innovadoras = iniciativas.Where(i => i.Innovadora == true)
                    }
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        /*
         *  REQUISITO: Cuánto tiempo se ha dedicado a cada acción. Por ejemplo, si es un proyecto cuántas horas se ha dedicado a ese proyecto.
         *  INPUT:  ¿Sólo se devuelve el tiempo, también el nombre y la acción?
         */
        public async Task<object> Indicador12(String? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .ToListAsync();
                List<String> tiposIniciativa = iniciativas.Select(i => (i.TipoIniciativa ?? String.Empty).ToLower()).Distinct().ToList() ?? new List<string>();
                var resultado = new
                {
                    indicador12 = new
                    {
                        HorasDeIniciativas = iniciativas.Select(i => new
                        {
                            Iniciativa = i.Nombre,
                            i.Horas
                        }),
                        HorasPorTipoAccion = tiposIniciativa.Select(t => new
                        {
                            TipoAccion = t,
                            Horas = iniciativas.Where(i => i.TipoIniciativa == t).Sum(i => i.Horas),
                            NumeroTipoAccion = iniciativas.Where(i => (i.TipoIniciativa ?? String.Empty).ToLower() == t).Count()
                        }).ToList()
                    }
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }
        /* REQUISITOS: Si esas acciones o proyectos han requerido de alguna visita, salida, charla…). 
         * INPUT: Es posible que sea más conveniente usar Equals en lugar de contains: contravisita.contains("visita") == true // PREGUNTAR //
         */
        public async Task<object> Indicador13(String? cursoAcademico)
        {
            try
            {
                var iniciativas = await _context.Iniciativas
                    .Where(i => (cursoAcademico == null || cursoAcademico.ToLower() == (i.CursoAcademico ?? String.Empty).ToLower()))
                    .ToListAsync();
                List<String> TIPOS_BUSCADOS = new List<string> { "visita", "salida", "charla" };
                List<String> cursosAcademicosEncontrados = iniciativas.Select(i => (i.CursoAcademico ?? "Sin curso")).Distinct().ToList();
                cursosAcademicosEncontrados.Sort();
                var Indicador13 = cursosAcademicosEncontrados.ToDictionary(curso =>
                curso,
                curso => iniciativas.Where(i => (i.CursoAcademico ?? "Sin curso").Equals(curso, StringComparison.CurrentCultureIgnoreCase) && TIPOS_BUSCADOS.Contains((i.TipoIniciativa ?? "").ToLower())).Select(i =>
                new
                {
                    i.Nombre,
                    Requeridos = i.TipoIniciativa
                }));

                var resultado = new
                {
                    Indicador13
                };
                return resultado;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
        }

        // MÉTODOS PRIVADOS \\
        private Dictionary<String, List<String>> DevolverClaveValores(List<Iniciativa> iniciativas)
        {
            return iniciativas.GroupBy(i => i.CursoAcademico ?? "")
                .ToDictionary(grupo =>
                grupo.Key,
                grupo => grupo.Select(i => i.TipoIniciativa ?? String.Empty).Where(tipo => !String.IsNullOrWhiteSpace(tipo)).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
                );
        }
    }
}
