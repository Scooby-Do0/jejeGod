﻿using FirebaseAdmin.Auth;
using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.Models;
using System.Security.Authentication;

namespace ods_4Vientos.server.Services.Utilidades
{
    public class LoginService
    {
        private Proyecto4vodsContext _context;
        public LoginService(Proyecto4vodsContext context)
        {
            _context = context;
        }
        public async Task<string> ComprobarToken(string authHeader)
        {
            string uid;
            try
            {
                if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                {
                    throw new ArgumentNullException("No se ha proporcionado un token");
                }
                authHeader = authHeader.Substring("Bearer ".Length).Trim();
                
                FirebaseToken decodedToken;

                decodedToken = await FirebaseAuth.DefaultInstance.VerifyIdTokenAsync(authHeader);
                uid = decodedToken.Uid;
                if (string.IsNullOrEmpty(uid)) throw new ArgumentNullException("No hay UID en el token");
            }
            catch (ArgumentNullException ex)
            {
                throw new AuthenticationException($"Error comprobando el token: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new AuthenticationException($"Error: {ex.Message}");
            }
            return uid;
        }

        public async Task<string> ObtenerRol(string uid)
        {
            UserRecord userRecord;
            try
            {
                userRecord = await FirebaseAuth.DefaultInstance.GetUserAsync(uid);
                var email = userRecord.Email;
                if (string.IsNullOrWhiteSpace(email)) throw new ArgumentNullException($"Se esperaba el Email del profesor, se recibió nulo o vacío");
                string rolDeProfesor = (await _context.Profesores.Where(prof => prof.Email.Equals(email, StringComparison.OrdinalIgnoreCase)).Select(prof => prof.Rol).FirstOrDefaultAsync() ?? string.Empty).ToString();
                return rolDeProfesor;
            }
            catch (ArgumentNullException ex)
            {
                throw new AuthenticationException($"Error autenticando en Firebase: {ex.Message}");
            }
            catch (Exception ex)
            {
                throw new AuthenticationException($"Error al obtener el usuario de Firebase: {ex.Message}");
            }
        }
    }
}
