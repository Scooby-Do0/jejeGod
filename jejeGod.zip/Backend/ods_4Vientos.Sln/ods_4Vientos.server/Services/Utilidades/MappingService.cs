﻿using ods_4Vientos.server.Models;
using ods_4Vientos.server.ModelosFront;
using Microsoft.Extensions.Configuration;

namespace ods_4Vientos.server.Services.Utilidades
{
    public interface IMappingService
    {
        public IniciativaFront MapIniciativaFront(Iniciativa iniciativa);
        public CicloFront MapCicloFront(Ciclo ciclo);
        public DifusionFront MapDifusionFront(DifusionIniciativa difusionIniciativa);
        public EntidadExternaFront MapEntidadExternaFront(EntidadesExterna entidadExterna);
        public MetaFront MapMetaFront(Meta meta);
        public ModuloFront MapModuloFront(Modulo modulo);
        public OdsFront MapOdFront(Od ods);
        public ProfesorFront MapProfesorFront(Profesore profesor);
        public Meta InverseMapMeta(MetaFront metaFront, int idOds, Meta? meta= null);
        public Od InverseMapOd(OdsFront odsFront, Od? ods= null, string? dimension = "");
        public Modulo InverseMapModulo(ModuloFront moduloFront, int idCiclo, Modulo? modulo= null);
        public Ciclo InverseMapCiclo(CicloFront cicloFront, Ciclo? ciclo = null);
        public Profesore InverseMapProfesor(ProfesorFront profesorFront, Profesore? profesor = null, string? rol = "Administrador");
        public EntidadesExterna InverseMapEntidadExterna(EntidadExternaFront entidadExternaFront, EntidadesExterna? entidadesExterna= null);
        public DifusionIniciativa InverseMapDifusion(DifusionFront difusionFront, int idIniciativa, DifusionIniciativa? difusionIniciativa = null);
        public Iniciativa InverseMapIniciativa(IniciativaFront iniciativaFront, Iniciativa? iniciativa = null);
        public List<string> AsignarDimensiones(List<string> listaDimensionPorOds);

    }
    public class MappingService : IMappingService
    {
        public IniciativaFront MapIniciativaFront(Iniciativa iniciativa)
        {
            var ciclosEntLista = CiclosEnModulos(iniciativa.Modulos.ToList());
            var odsEntLista = OdsEnMetas(iniciativa.Meta.ToList());
            var dimensionPorOds = odsEntLista.Select(ods => ods.Dimension).ToList();
            return new IniciativaFront
            {
                Id = iniciativa.Idiniciativa,
                Nombre = iniciativa.Nombre,
                Descripcion = iniciativa.Descripcion ?? "Sin descripción",
                Curso = iniciativa.CursoAcademico ?? "",
                Fecha_Inicio = iniciativa.FechaInicio,
                Fecha_Fin = iniciativa.FechaFin ?? null,
                Tipo_Iniciativa = iniciativa.TipoIniciativa ?? "Otro",
                Innovadora = iniciativa.Innovadora ?? false,
                Horas = iniciativa.Horas,
                Dimensiones = AsignarDimensiones(dimensionPorOds),
                DifusionLista = iniciativa.DifusionIniciativas.Select(difusion => MapDifusionFront(difusion)).ToList() ?? new List<DifusionFront>(),
                EntidadesLista = iniciativa.Identidads.Select(e => MapEntidadExternaFront(e)).ToList() ?? new List<EntidadExternaFront>(),
                OdsLista = odsEntLista.Select(od => MapOdFront(od)).ToList() ?? new List<OdsFront>(),
                ProfesoresLista = iniciativa.IdProfesors.Select(p => MapProfesorFront(p)).ToList() ?? new List<ProfesorFront>(),
                CiclosLista = ciclosEntLista.Select(ciclo => MapCicloFront(ciclo)).ToList() ?? new List<CicloFront>()
            };
        }
        public CicloFront MapCicloFront(Ciclo ciclo)
        {
            return new CicloFront
            {
                IdCiclo = ciclo.IdCiclo,
                NombreCiclo = ciclo.NombreCiclo,
                Modulos = ciclo.Modulos.Select(m => MapModuloFront(m)).ToList() ?? new List<ModuloFront>()
            };
        }

        public DifusionFront MapDifusionFront(DifusionIniciativa difusionIniciativa)
        {
            return new DifusionFront
            {
                Iddifusion = difusionIniciativa.Iddifusion,
                Tipo = difusionIniciativa.Tipo,
                Enlace = difusionIniciativa.Enlace,
            };
        }

        public EntidadExternaFront MapEntidadExternaFront(EntidadesExterna entidadExterna)
        {
            return new EntidadExternaFront
            {
                Identidad = entidadExterna.Identidad,
                Nombre = entidadExterna.Nombre
            };
        }
        public MetaFront MapMetaFront(Meta meta)
        {
            return new MetaFront
            {
                IdMeta = meta.IdMeta,
                Descripcion = meta.Descripcion

            };
        }
        public ModuloFront MapModuloFront(Modulo modulo)
        {
            return new ModuloFront
            {
                IdModulo = modulo.IdModulo,
                Nombre = modulo.Nombre
            };
        }
        public OdsFront MapOdFront(Od ods)
        {
            return new OdsFront
            {
                IdOds = ods.IdOds,
                Nombre = ods.Nombre,
                Metas = ods.Meta.Select(m => MapMetaFront(m)).ToList() ?? new List<MetaFront>()
            };
        }

        public ProfesorFront MapProfesorFront(Profesore profesor)
        {
            return new ProfesorFront
            {
                IdProfesor = profesor.IdProfesor,
                Nombre = profesor.Nombre
            };
        }

        // Privados de servicio
        private List<Ciclo> CiclosEnModulos(List<Modulo> modulos)
        {
            return modulos.Select(m => m.IdCicloNavigation)
                  .Distinct()
                  .ToList();
        }

        private List<Od> OdsEnMetas(List<Meta> metas)
        {
            return metas.Select(m => m.IdOdsNavigation)
                  .Distinct()
                  .ToList();
        }

        public List<string> AsignarDimensiones(List<string> listaOdsPorId)
        {
            return listaOdsPorId.Distinct().ToList();
        }

        // MAPEO DE MODELOS FRONT A ENTIDADES
        public Meta InverseMapMeta(MetaFront metaFront, int idOds, Meta? meta = null)
        {
            meta ??= new Meta();
            meta.IdOds = (short)idOds;
            meta.IdMeta = metaFront.IdMeta;
            meta.Descripcion = metaFront.Descripcion;
            return meta;
        }

        public Od InverseMapOd(OdsFront odsFront, Od? ods = null, string? dimension = "")
        {
            ods ??= new Od();
            ods.IdOds = (short)odsFront.IdOds;
            ods.Nombre = odsFront.Nombre;
            ods.Dimension = dimension ?? string.Empty;
            return ods;
        }

        public Modulo InverseMapModulo(ModuloFront moduloFront, int idCiclo, Modulo? modulo = null)
        {
            modulo ??= new Modulo();
            modulo.IdCiclo = (short)idCiclo;
            modulo.IdModulo = (short)moduloFront.IdModulo;
            modulo.Nombre = moduloFront.Nombre;
            return modulo;
        }

        public Ciclo InverseMapCiclo(CicloFront cicloFront, Ciclo? ciclo = null)
        {
            ciclo ??= new Ciclo();
            ciclo.IdCiclo = (short)cicloFront.IdCiclo;
            ciclo.NombreCiclo = cicloFront.NombreCiclo;
            return ciclo;
        }

        public Profesore InverseMapProfesor(ProfesorFront profesorFront, Profesore? profesor = null, string? rol = "Usuario")
        {
            profesor ??= new Profesore();
            profesor.IdProfesor = (short)profesorFront.IdProfesor;
            profesor.Nombre = profesorFront.Nombre;
            profesor.Rol = rol ?? "Usuario";
            return profesor;
        }

        public EntidadesExterna InverseMapEntidadExterna(EntidadExternaFront entidadExternaFront, EntidadesExterna? entidadesExterna= null)
        {
            entidadesExterna ??= new EntidadesExterna();
            entidadesExterna.Identidad = (short)entidadExternaFront.Identidad;
            entidadesExterna.Nombre = entidadExternaFront.Nombre;
            return entidadesExterna;
        }

        public DifusionIniciativa InverseMapDifusion(DifusionFront difusionFront, int idIniciativa, DifusionIniciativa? difusionIniciativa = null)
        {
            difusionIniciativa ??= new DifusionIniciativa();
            difusionIniciativa.Iddifusion = difusionIniciativa.Iddifusion != 0? difusionIniciativa.Iddifusion : difusionFront.Iddifusion;
            difusionIniciativa.Idiniciativa = (short)idIniciativa;
            difusionIniciativa.Tipo = difusionFront.Tipo;
            difusionIniciativa.Enlace = difusionFront.Enlace;
            return difusionIniciativa;
        }

        public Iniciativa InverseMapIniciativa(IniciativaFront iniciativaFront, Iniciativa? iniciativa = null)
        {
            iniciativa ??= new Iniciativa();
            iniciativa.Idiniciativa = iniciativa.Idiniciativa == 0 ? (short)iniciativaFront.Id : iniciativa.Idiniciativa;
            iniciativa.Nombre = iniciativaFront.Nombre;
            iniciativa.Descripcion = iniciativaFront.Descripcion;
            iniciativa.CursoAcademico = iniciativaFront.Curso;
            iniciativa.FechaInicio = iniciativaFront.Fecha_Inicio;
            iniciativa.FechaFin = iniciativaFront.Fecha_Fin;
            iniciativa.TipoIniciativa = iniciativaFront.Tipo_Iniciativa ?? "Otro";
            iniciativa.Innovadora = iniciativaFront.Innovadora;
            iniciativa.Horas = (short)iniciativaFront.Horas;
            return iniciativa;
        }
    }
}