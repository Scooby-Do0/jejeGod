﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.EntityFrameworkCore;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Entidades;
using ods_4Vientos.server.Services.Utilidades;
using System.Data;

namespace ods_4Vientos.server.Services
{
    public class IniciativaService
    {
        private readonly Proyecto4vodsContext _context;
        private readonly IMappingService _mappingService;
        private readonly DifusionIniciativaService _difusionIniciativaService;
        private readonly EntidadesExternasService _entidadesExternasService;
        private readonly ModulosService _modulosService;
        private readonly ProfesoresService _profesoresService;
        private readonly MetaService _metaService;

        public IniciativaService(Proyecto4vodsContext context, IMappingService mappingService, DifusionIniciativaService difusionIniciativaService, EntidadesExternasService entidadesExternasService, ModulosService modulosService, ProfesoresService profesoresService, MetaService metaService)
        {
            _context = context;
            _mappingService = mappingService;
            _difusionIniciativaService = difusionIniciativaService;
            _entidadesExternasService = entidadesExternasService;
            _modulosService = modulosService;
            _profesoresService = profesoresService;
            _metaService = metaService;
        }
        public async Task<IEnumerable<IniciativaFront>> ObtenerIniciativas()
        {
            List<Iniciativa> iniciativas;
            try
            {
                iniciativas = await _context.Iniciativas
                    .Include(i => i.DifusionIniciativas)
                    .Include(i => i.Meta).ThenInclude(me => me.IdOdsNavigation)
                    .Include(i => i.Modulos).ThenInclude(mo => mo.IdCicloNavigation)
                    .Include(i => i.IdProfesors)
                    .Include(i => i.Identidads)
                    .ToListAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al recoger las iniciativas");
            }
            return iniciativas.Select(ini => _mappingService.MapIniciativaFront(ini)).ToList();
        }

        public async Task<IniciativaFront> ObtenerIniciativaPorId(short id)
        {
            Iniciativa? iniciativa;
            try
            {
                iniciativa = await GetIniciativaPorId(id);
                if (iniciativa == null)
                {
                    throw new KeyNotFoundException("No se ha encontrado la iniciativa");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception($"Error al recoger las iniciativas: {e.Message}");
            }
            return _mappingService.MapIniciativaFront(iniciativa);
        }

        public async Task<IniciativaFront> CrearIniciativa(IniciativaFront iniciativaFront)
        {
            IniciativaFront? resultado = null;
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                await using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    if (await this.ExisteIniciativa(iniciativaFront.Id))
                    {
                        throw new DuplicateNameException("Ya existe una iniciativa con el mismo Id");
                    }
                    Iniciativa iniciativa = new Iniciativa();
                    _mappingService.InverseMapIniciativa(iniciativaFront, iniciativa);
                    await this.CrearRelacionesIniciativa(iniciativaFront, iniciativa, esIniciativaNueva: true);
                    _context.Iniciativas.Add(iniciativa);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new DuplicateNameException("Error al guardar la iniciativa, ya existía una Iniciativa con el mismo Id");
                    }
                    iniciativa.DifusionIniciativas = await _difusionIniciativaService.CrearRelacionDifusionIniciativas(iniciativaFront.DifusionLista, iniciativa.Idiniciativa);
                    await transaction.CommitAsync();
                    resultado = iniciativaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (DuplicateNameException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new DuplicateNameException(ex.Message);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear la iniciativa.", ex);
                }
            });
            return resultado;
        }

        public async Task<IniciativaFront> ActualizarIniciativa(IniciativaFront iniciativaFront)
        {
            IniciativaFront? resultado = null;
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                await using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    if (!await this.ExisteIniciativa(iniciativaFront.Id))
                    {
                        throw new KeyNotFoundException("La iniciativa no existe");
                    }
                    Iniciativa? iniciativa = await GetIniciativaPorId((short)iniciativaFront.Id);

                    if (iniciativa == null)
                    {
                        throw new ArgumentNullException($"No se ha podido traer la iniciativa de la BBDD: Aunque sí existe.");
                    }

                    _mappingService.InverseMapIniciativa(iniciativaFront, iniciativa);
                    await this.CrearRelacionesIniciativa(iniciativaFront, iniciativa);
                    iniciativa.DifusionIniciativas = await _difusionIniciativaService.CrearRelacionDifusionIniciativas(iniciativaFront.DifusionLista, iniciativa.Idiniciativa, iniciativa.DifusionIniciativas.ToList());
                    _context.Iniciativas.Update(iniciativa);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("No ha sido posible guardar los cambios de la iniciativa.");
                    }
                    await transaction.CommitAsync();
                    resultado = iniciativaFront;
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (KeyNotFoundException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al guardar la iniciativa: {ex.Message}");
                    throw new KeyNotFoundException(ex.Message);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al crear la iniciativa.", ex);
                }
            });
            return resultado;
        }

        public async Task<short> BorrarIniciativa(short idIniciativa)
        {
            var strategy = _context.Database.CreateExecutionStrategy();
            await strategy.ExecuteAsync(async () =>
            {
                await using var transaction = await _context.Database.BeginTransactionAsync();
                Iniciativa? iniciativa;
                try
                {
                    if (!await this.ExisteIniciativa(idIniciativa))
                    {
                        throw new KeyNotFoundException("La iniciativa no existe");
                    }
                    iniciativa = await GetIniciativaPorId(idIniciativa);

                    if (iniciativa == null)
                    {
                        throw new ArgumentNullException($"No se ha podido traer la iniciativa de la BBDD: Aunque sí existe.");
                    }

                    EliminarRelacionesIniciativa(iniciativa);
                    _context.DifusionIniciativas.RemoveRange(iniciativa.DifusionIniciativas);
                    _context.Iniciativas.Remove(iniciativa);
                    int nAfectados = _context.SaveChanges();
                    if (nAfectados == 0)
                    {
                        throw new NotImplementedException("Iniciativa no eliminada, no se ha modificado la base de datos");
                    }
                    await transaction.CommitAsync();
                }
                catch (DbUpdateException dbEx)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                    throw new DbUpdateException($"Error al guardar cambios en la base de datos: {dbEx.Message}");
                }
                catch (InvalidOperationException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error en la operación con la base de datos: {ex.Message}");
                    throw new InvalidOperationException("No se ha podido conectar con la base de datos o la conexión es inválida.", ex);
                }
                catch (KeyNotFoundException ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error al eliminar la iniciativa: {ex.Message}");
                    throw new KeyNotFoundException(ex.Message);
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"Error general: {ex.Message}");
                    throw new NotImplementedException("Ha ocurrido un error general al tratar de eliminar la iniciativa.", ex);
                }
            });
            return idIniciativa;
        }

        private async Task CrearRelacionesIniciativa(IniciativaFront iniciativaFront, Iniciativa iniciativa, bool esIniciativaNueva = false)
        {
            try
            {
                // Colleciones que permiten hacer la query de la base de datos de manera ágil
                var metasFrontFiltradas = iniciativaFront.OdsLista.SelectMany(ods => ods.Metas.Select(meta => $"{meta.IdMeta}:{(short)ods.IdOds}")).ToList();
                var modulosFrontFiltrados = iniciativaFront.CiclosLista.SelectMany(ciclo => ciclo.Modulos.Select(modul => $"{(short)modul.IdModulo}:{(short)ciclo.IdCiclo}"));
                var entidadesFrontFiltradas = iniciativaFront.EntidadesLista.Select(entidad => (short)entidad.Identidad).ToList();
                var profesoresFrontFiltrados = iniciativaFront.ProfesoresLista.Select(prof => (short)prof.IdProfesor).ToList();

                // Creación de las relaciones
                iniciativa.Meta = (esIniciativaNueva) ? (await _context.Metas.Where(met => metasFrontFiltradas.Contains(met.IdMeta + ":" + met.IdOds)).ToListAsync()) 
                    : (await _metaService.CrearRelacionesMetas(iniciativaFront.OdsLista)).ToList();
                iniciativa.Modulos = (esIniciativaNueva) ?  _context.Modulos.AsEnumerable().Where(modulo => modulosFrontFiltrados.Contains(modulo.IdModulo + ":" + modulo.IdCiclo)).ToList()
                    : (await _modulosService.CrearRelacionesModulos(iniciativaFront.CiclosLista)).ToList();
                iniciativa.Identidads = (esIniciativaNueva) ? (await _context.EntidadesExternas.Where(entidadExterna => entidadesFrontFiltradas.AsEnumerable().Contains(entidadExterna.Identidad)).Distinct().ToListAsync()) : (await _entidadesExternasService.CrearRelacionesEntidadesExternas(iniciativaFront.EntidadesLista)).ToList();
                iniciativa.IdProfesors = (esIniciativaNueva) ? (await _context.Profesores.Where(profesor => profesoresFrontFiltrados.AsEnumerable().Contains(profesor.IdProfesor)).Distinct().ToListAsync()) : (await _profesoresService.CrearRelacionProfesores(iniciativaFront.ProfesoresLista)).ToList();
            }
            catch (System.InvalidOperationException) 
            {
                throw;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw new Exception("Error al tratar de crear las relaciones de la Iniciativa");
            }
        }

        private void EliminarRelacionesIniciativa(Iniciativa iniciativa)
        {
            try
            {
                iniciativa.Meta.Clear();
                iniciativa.Modulos.Clear();
                iniciativa.Identidads.Clear();
                iniciativa.IdProfesors.Clear();
                iniciativa.DifusionIniciativas.Clear();
            }
            catch (Exception ex)
            {

                throw new NotImplementedException("No se han podido eliminar las relaciones de la iniciativa: " + ex);
            }
        }

        private async Task<bool> ExisteIniciativa(int idIniciativa)
        {
            var existeIniciativa = await _context.Iniciativas.AnyAsync(i => i.Idiniciativa == (short)idIniciativa);
            return existeIniciativa;
        }

        private async Task<Iniciativa?> GetIniciativaPorId(short id)
        {
            Iniciativa? iniciativa = await _context.Iniciativas
                   .Include(i => i.DifusionIniciativas)
                   .Include(i => i.Meta).ThenInclude(me => me.IdOdsNavigation)
                   .Include(i => i.Modulos).ThenInclude(mo => mo.IdCicloNavigation)
                   .Include(i => i.IdProfesors)
                   .Include(i => i.Identidads)
                   .FirstOrDefaultAsync(i => i.Idiniciativa == id);

            return iniciativa;
        }

    }
}
