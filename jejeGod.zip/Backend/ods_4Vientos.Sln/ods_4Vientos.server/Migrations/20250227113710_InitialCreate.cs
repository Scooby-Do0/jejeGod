﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ods_4Vientos.server.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "CICLOS",
                columns: table => new
                {
                    IdCiclo = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    NombreCiclo = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__CICLOS__AD4E49E7F98F0150", x => x.IdCiclo);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "ENTIDADES_EXTERNAS",
                columns: table => new
                {
                    IDEntidad = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    NOMBRE = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__ENTIDADE__0EA1E70980A57C5B", x => x.IDEntidad);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "INICIATIVAS",
                columns: table => new
                {
                    IDIniciativa = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    NOMBRE = table.Column<string>(type: "varchar(200)", maxLength: 200, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DESCRIPCION = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    CURSOACADEMICO = table.Column<string>(name: "CURSO ACADEMICO", type: "varchar(100)", maxLength: 100, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    FECHAINICIO = table.Column<DateTime>(name: "FECHA INICIO", type: "datetime", nullable: false),
                    FECHAFIN = table.Column<DateTime>(name: "FECHA FIN", type: "datetime", nullable: true),
                    TIPOINICIATIVA = table.Column<string>(name: "TIPO INICIATIVA", type: "varchar(100)", maxLength: 100, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ACCION = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    INNOVADORA = table.Column<bool>(type: "tinyint(1)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__INICIATI__0F570E47AD3AE3FB", x => x.IDIniciativa);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "ODS",
                columns: table => new
                {
                    IdODS = table.Column<short>(type: "smallint", nullable: false),
                    NOMBRE = table.Column<string>(type: "varchar(200)", maxLength: 200, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__ODS__2A0B5BE4FCFFA6B7", x => x.IdODS);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "PROFESORES",
                columns: table => new
                {
                    IdProfesor = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Nombre = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PROFESOR__C377C3A1364758BE", x => x.IdProfesor);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "MODULOS",
                columns: table => new
                {
                    IdModulo = table.Column<short>(type: "smallint", nullable: false),
                    IdCiclo = table.Column<short>(type: "smallint", nullable: false),
                    Nombre = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MODULOS", x => new { x.IdCiclo, x.IdModulo });
                    table.ForeignKey(
                        name: "FK_MODULOS",
                        column: x => x.IdCiclo,
                        principalTable: "CICLOS",
                        principalColumn: "IdCiclo");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "DIFUSION_INICIATIVAS",
                columns: table => new
                {
                    IDDifusion = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    IDIniciativa = table.Column<short>(type: "smallint", nullable: false),
                    Tipo = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Enlace = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__DIFUSION__BC15F45B8538CE9E", x => x.IDDifusion);
                    table.ForeignKey(
                        name: "FK_DIFUSION_INICIATIVAS",
                        column: x => x.IDIniciativa,
                        principalTable: "INICIATIVAS",
                        principalColumn: "IDIniciativa",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "INICIATIVAS_ENTIDADES_EXTERNAS",
                columns: table => new
                {
                    IDIniciativa = table.Column<short>(type: "smallint", nullable: false),
                    IDEntidad = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INICIATIVAS_ENTIDADES_EXTERNAS", x => new { x.IDIniciativa, x.IDEntidad });
                    table.ForeignKey(
                        name: "FK__INICIATIV__IDEnt__3F466844",
                        column: x => x.IDEntidad,
                        principalTable: "ENTIDADES_EXTERNAS",
                        principalColumn: "IDEntidad");
                    table.ForeignKey(
                        name: "FK__INICIATIV__IDIni__3E52440B",
                        column: x => x.IDIniciativa,
                        principalTable: "INICIATIVAS",
                        principalColumn: "IDIniciativa");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "METAS",
                columns: table => new
                {
                    IdODS = table.Column<short>(type: "smallint", nullable: false),
                    IdMeta = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DESCRIPCION = table.Column<string>(type: "varchar(200)", maxLength: 200, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ID_METAS", x => new { x.IdODS, x.IdMeta });
                    table.ForeignKey(
                        name: "FK_ID_ODS",
                        column: x => x.IdODS,
                        principalTable: "ODS",
                        principalColumn: "IdODS");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "INICIATIVAS_PROFESORES",
                columns: table => new
                {
                    IdProfesor = table.Column<short>(type: "smallint", nullable: false),
                    IdIniciativa = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INICIATIVAS_PROFESORES", x => new { x.IdProfesor, x.IdIniciativa });
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_PROFESORES_INICIATIVAS",
                        column: x => x.IdIniciativa,
                        principalTable: "INICIATIVAS",
                        principalColumn: "IDIniciativa");
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_PROFESORES_PROFESORES",
                        column: x => x.IdProfesor,
                        principalTable: "PROFESORES",
                        principalColumn: "IdProfesor");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "INICIATIVAS_MODULOS",
                columns: table => new
                {
                    IdIniciativa = table.Column<short>(type: "smallint", nullable: false),
                    IdModulo = table.Column<short>(type: "smallint", nullable: false),
                    IdCiclo = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INICIATIVAS_MODULOS", x => new { x.IdIniciativa, x.IdModulo, x.IdCiclo });
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_MODULOS_INICIATIVA",
                        column: x => x.IdIniciativa,
                        principalTable: "INICIATIVAS",
                        principalColumn: "IDIniciativa");
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_MODULOS_MODULO",
                        columns: x => new { x.IdCiclo, x.IdModulo },
                        principalTable: "MODULOS",
                        principalColumns: new[] { "IdCiclo", "IdModulo" });
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "PROFESORES_MODULOS",
                columns: table => new
                {
                    IdCiclo = table.Column<short>(type: "smallint", nullable: false),
                    IdModulo = table.Column<short>(type: "smallint", nullable: false),
                    IdProfesor = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PROFESORES_MODULOS", x => new { x.IdCiclo, x.IdModulo, x.IdProfesor });
                    table.ForeignKey(
                        name: "FK_MODULOS_PROFESORES_MODULOS",
                        columns: x => new { x.IdCiclo, x.IdModulo },
                        principalTable: "MODULOS",
                        principalColumns: new[] { "IdCiclo", "IdModulo" });
                    table.ForeignKey(
                        name: "FK__PROFESORE__IdPro__49C3F6B7",
                        column: x => x.IdProfesor,
                        principalTable: "PROFESORES",
                        principalColumn: "IdProfesor");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "INICIATIVAS_METAS",
                columns: table => new
                {
                    IdIniciativa = table.Column<short>(type: "smallint", nullable: false),
                    IdODS = table.Column<short>(type: "smallint", nullable: false),
                    IdMeta = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_INICIATIVAS_METAS", x => new { x.IdIniciativa, x.IdODS, x.IdMeta });
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_METAS_INICIATIVAS",
                        column: x => x.IdIniciativa,
                        principalTable: "INICIATIVAS",
                        principalColumn: "IDIniciativa");
                    table.ForeignKey(
                        name: "FK_INICIATIVAS_METAS_METAS",
                        columns: x => new { x.IdODS, x.IdMeta },
                        principalTable: "METAS",
                        principalColumns: new[] { "IdODS", "IdMeta" });
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_DIFUSION_INICIATIVAS_IDIniciativa",
                table: "DIFUSION_INICIATIVAS",
                column: "IDIniciativa");

            migrationBuilder.CreateIndex(
                name: "IX_INICIATIVAS_ENTIDADES_EXTERNAS_IDEntidad",
                table: "INICIATIVAS_ENTIDADES_EXTERNAS",
                column: "IDEntidad");

            migrationBuilder.CreateIndex(
                name: "IX_INICIATIVAS_METAS_IdODS_IdMeta",
                table: "INICIATIVAS_METAS",
                columns: new[] { "IdODS", "IdMeta" });

            migrationBuilder.CreateIndex(
                name: "IX_INICIATIVAS_MODULOS_IdCiclo_IdModulo",
                table: "INICIATIVAS_MODULOS",
                columns: new[] { "IdCiclo", "IdModulo" });

            migrationBuilder.CreateIndex(
                name: "IX_INICIATIVAS_PROFESORES_IdIniciativa",
                table: "INICIATIVAS_PROFESORES",
                column: "IdIniciativa");

            migrationBuilder.CreateIndex(
                name: "IX_PROFESORES_MODULOS_IdProfesor",
                table: "PROFESORES_MODULOS",
                column: "IdProfesor");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DIFUSION_INICIATIVAS");

            migrationBuilder.DropTable(
                name: "INICIATIVAS_ENTIDADES_EXTERNAS");

            migrationBuilder.DropTable(
                name: "INICIATIVAS_METAS");

            migrationBuilder.DropTable(
                name: "INICIATIVAS_MODULOS");

            migrationBuilder.DropTable(
                name: "INICIATIVAS_PROFESORES");

            migrationBuilder.DropTable(
                name: "PROFESORES_MODULOS");

            migrationBuilder.DropTable(
                name: "ENTIDADES_EXTERNAS");

            migrationBuilder.DropTable(
                name: "METAS");

            migrationBuilder.DropTable(
                name: "INICIATIVAS");

            migrationBuilder.DropTable(
                name: "MODULOS");

            migrationBuilder.DropTable(
                name: "PROFESORES");

            migrationBuilder.DropTable(
                name: "ODS");

            migrationBuilder.DropTable(
                name: "CICLOS");
        }
    }
}
