using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ods_4Vientos.server.Data;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services;
using ods_4Vientos.server.Services.Entidades;
using ods_4Vientos.server.Services.Utilidades;
using Pomelo.EntityFrameworkCore.MySql.Internal;
using System;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("https://localhost:7217", /*"https://0.0.0.0:7217",*/ "http://0.0.0.0:5236");
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(
        policy =>
        {
            policy.AllowAnyOrigin() // Permite cualquier origen
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        });
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//Add services to the container.
builder.Services.AddScoped<IniciativaService>();
builder.Services.AddScoped<MetaService>();
builder.Services.AddScoped<OdsService>();
builder.Services.AddScoped<ModulosService>();
builder.Services.AddScoped<CicloService>();
builder.Services.AddScoped<ProfesoresService>();
builder.Services.AddScoped<EntidadesExternasService>();
builder.Services.AddScoped<DifusionIniciativaService>();
builder.Services.AddScoped<IndicadoresService>();
builder.Services.AddSingleton<IMappingService, MappingService>();
builder.Services.AddScoped<LoginService>();

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

var mysqlConnectionString = DatabaseConfig.GetConnectionString("MySqlConnection", builder.Configuration);
builder.Services.AddDbContext<Proyecto4vodsContext>(options =>
    options.UseMySql(
        mysqlConnectionString,
        ServerVersion.AutoDetect(mysqlConnectionString),
        mysqlOptions =>
        {
            mysqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(10),
                errorNumbersToAdd: null);
            mysqlOptions.EnableStringComparisonTranslations();
        }));


var firebaseProjectId = "proyecto4vods-8679e";

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = $"https://securetoken.google.com/{firebaseProjectId}";
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = $"https://securetoken.google.com/{firebaseProjectId}",
            ValidateAudience = true,
            ValidAudience = firebaseProjectId,
            ValidateLifetime = true
        };
    });

var path = "Credenciales/firebase-adminsdk.json";
if (!File.Exists(path))
    throw new FileNotFoundException("El archivo de credenciales Firebase no fue encontrado en " + path);

FirebaseApp.Create(new AppOptions
{
    Credential = GoogleCredential.FromFile(path)
});


//Para SqlServer
//builder.Services.AddDbContext<IniciativaDbContext>(options => options.UseSqlServer(mysqlConnectionString));
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Ods_4Vientos API v1");
        c.RoutePrefix = ""; // Esto hace que Swagger se abra en la ra�z "/"
    });
    app.MapOpenApi();
}

app.UseCors();
app.UseAuthorization();

app.MapControllers();

app.Run();
