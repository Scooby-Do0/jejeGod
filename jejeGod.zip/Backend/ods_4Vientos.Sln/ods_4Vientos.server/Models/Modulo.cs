﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class Modulo
{
    public short IdModulo { get; set; }

    public short IdCiclo { get; set; }

    public string Nombre { get; set; } = null!;

    public bool Eliminada { get; set; }

    public virtual Ciclo IdCicloNavigation { get; set; } = null!;
    [JsonIgnore]
    public virtual ICollection<Iniciativa> IdIniciativas { get; set; } = new List<Iniciativa>();

    public virtual ICollection<Profesore> IdProfesors { get; set; } = new List<Profesore>();
}
