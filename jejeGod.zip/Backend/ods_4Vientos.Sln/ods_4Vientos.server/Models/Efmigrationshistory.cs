﻿using System;
using System.Collections.Generic;

namespace ods_4Vientos.server.Models;

public partial class Efmigrationshistory
{
    public string MigrationId { get; set; } = null!;

    public string ProductVersion { get; set; } = null!;
}
