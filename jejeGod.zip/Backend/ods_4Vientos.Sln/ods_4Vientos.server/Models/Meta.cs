﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class Meta
{
    public short IdOds { get; set; }

    public string IdMeta { get; set; } = null!;

    public string Descripcion { get; set; } = null!;

    public bool Eliminada { get; set; }

    public virtual Od IdOdsNavigation { get; set; } = null!;
    [JsonIgnore]
    public virtual ICollection<Iniciativa> IdIniciativas { get; set; } = new List<Iniciativa>();
}
