﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class DifusionIniciativa
{
    public int Iddifusion { get; set; }

    public short Idiniciativa { get; set; }

    public string Tipo { get; set; } = null!;

    public string Enlace { get; set; } = null!;
    [JsonIgnore]
    public virtual Iniciativa IdiniciativaNavigation { get; set; } = null!;
}
