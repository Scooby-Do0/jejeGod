﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class Od
{
    public short IdOds { get; set; }

    public string Nombre { get; set; } = null!;
    [JsonIgnore]
    public bool Eliminada { get; set; }

    public string Dimension { get; set; } = "";

    public virtual ICollection<Meta> Meta { get; set; } = new List<Meta>();
}
