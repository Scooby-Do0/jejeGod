﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class Profesore
{
    public short IdProfesor { get; set; }

    public string Nombre { get; set; } = null!;
    [JsonIgnore]
    public string Email { get; set; } = null!;

    public string Rol { get; set; } = null!;

    public bool Eliminada { get; set; }

    public virtual ICollection<Iniciativa> IdIniciativas { get; set; } = new List<Iniciativa>();

    public virtual ICollection<Modulo> Modulos { get; set; } = new List<Modulo>();
}
