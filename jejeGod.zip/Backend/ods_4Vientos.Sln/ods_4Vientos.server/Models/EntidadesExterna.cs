﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ods_4Vientos.server.Models;

public partial class EntidadesExterna
{
    public short Identidad { get; set; }

    public string Nombre { get; set; } = null!;
    [JsonIgnore]
    public bool Eliminada { get; set; }

    public virtual ICollection<Iniciativa> Idiniciativas { get; set; } = new List<Iniciativa>();
}
