﻿using System;
using System.Collections.Generic;

namespace ods_4Vientos.server.Models;

public partial class Iniciativa
{
    public short Idiniciativa { get; set; }

    public string Nombre { get; set; } = null!;

    public string? Descripcion { get; set; }

    public string? CursoAcademico { get; set; }

    public DateTime FechaInicio { get; set; } = DateTime.Now;

    public DateTime? FechaFin { get; set; }

    public string? TipoIniciativa { get; set; }

    public bool? Innovadora { get; set; }

    public short Horas { get; set; }

    public virtual ICollection<DifusionIniciativa> DifusionIniciativas { get; set; } = new List<DifusionIniciativa>();

    public virtual ICollection<Profesore> IdProfesors { get; set; } = new List<Profesore>();

    public virtual ICollection<EntidadesExterna> Identidads { get; set; } = new List<EntidadesExterna>();

    public virtual ICollection<Meta> Meta { get; set; } = new List<Meta>();

    public virtual ICollection<Modulo> Modulos { get; set; } = new List<Modulo>();
}
