﻿namespace ods_4Vientos.server.Data
{
    public class DatabaseConfig
    {
        public static string GetConnectionString(String dbServer,IConfiguration configuration)
        {
            var machineName = Environment.MachineName.ToUpper();

            var serverMappings = configuration.GetSection("SqlServerNames").Get<Dictionary<string, string>>();

            var serverName = serverMappings != null && serverMappings.ContainsKey(machineName)
                ? serverMappings[machineName]
                : serverMappings["Default"];

            var connectionString = configuration.GetConnectionString(dbServer)
                .Replace("{ServerName}", serverName);

            return connectionString;
        }
    }
}
