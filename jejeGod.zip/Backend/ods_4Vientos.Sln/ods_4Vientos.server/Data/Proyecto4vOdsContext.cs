﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace ods_4Vientos.server.Models;

public partial class Proyecto4vodsContext : DbContext
{
    public Proyecto4vodsContext()
    {
    }

    public Proyecto4vodsContext(DbContextOptions<Proyecto4vodsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Ciclo> Ciclos { get; set; }

    public virtual DbSet<DifusionIniciativa> DifusionIniciativas { get; set; }

    public virtual DbSet<Efmigrationshistory> Efmigrationshistories { get; set; }

    public virtual DbSet<EntidadesExterna> EntidadesExternas { get; set; }

    public virtual DbSet<Iniciativa> Iniciativas { get; set; }

    public virtual DbSet<Meta> Metas { get; set; }

    public virtual DbSet<Modulo> Modulos { get; set; }

    public virtual DbSet<Od> Ods { get; set; }

    public virtual DbSet<Profesore> Profesores { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=127.0.0.1;port=3306;database=proyecto4vods;user=root;charset=utf8mb4", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.32-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Ciclo>(entity =>
        {
            entity.HasKey(e => e.IdCiclo).HasName("PRIMARY");

            entity.ToTable("ciclos");

            entity.Property(e => e.IdCiclo).HasColumnType("smallint(6)");
            entity.Property(e => e.NombreCiclo).HasMaxLength(100);
        });

        modelBuilder.Entity<DifusionIniciativa>(entity =>
        {
            entity.HasKey(e => e.Iddifusion).HasName("PRIMARY");

            entity.ToTable("difusion_iniciativas");

            entity.HasIndex(e => e.Idiniciativa, "IX_DIFUSION_INICIATIVAS_IDIniciativa");

            entity.Property(e => e.Iddifusion)
                .HasColumnType("int(11)")
                .HasColumnName("IDDifusion");
            entity.Property(e => e.Enlace).HasMaxLength(500);
            entity.Property(e => e.Idiniciativa)
                .HasColumnType("smallint(6)")
                .HasColumnName("IDIniciativa");
            entity.Property(e => e.Tipo).HasMaxLength(100);

            entity.HasOne(d => d.IdiniciativaNavigation).WithMany(p => p.DifusionIniciativas)
                .HasForeignKey(d => d.Idiniciativa)
                .HasConstraintName("FK_DIFUSION_INICIATIVAS");
        });

        modelBuilder.Entity<Efmigrationshistory>(entity =>
        {
            entity.HasKey(e => e.MigrationId).HasName("PRIMARY");

            entity.ToTable("__efmigrationshistory");

            entity.Property(e => e.MigrationId).HasMaxLength(150);
            entity.Property(e => e.ProductVersion).HasMaxLength(32);
        });

        modelBuilder.Entity<EntidadesExterna>(entity =>
        {
            entity.HasKey(e => e.Identidad).HasName("PRIMARY");

            entity.ToTable("entidades_externas");

            entity.Property(e => e.Identidad)
                .HasColumnType("smallint(6)")
                .HasColumnName("IDEntidad");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .HasColumnName("NOMBRE");
        });

        modelBuilder.Entity<Iniciativa>(entity =>
        {
            entity.HasKey(e => e.Idiniciativa).HasName("PRIMARY");

            entity.ToTable("iniciativas");

            entity.Property(e => e.Idiniciativa)
                .HasColumnType("smallint(6)")
                .HasColumnName("IDIniciativa");
            entity.Property(e => e.CursoAcademico)
                .HasMaxLength(100)
                .HasColumnName("CURSO ACADEMICO");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(2500)
                .HasColumnName("DESCRIPCION");
            entity.Property(e => e.FechaFin)
                .HasColumnType("datetime")
                .HasColumnName("FECHA FIN");
            entity.Property(e => e.FechaInicio)
                .HasColumnType("datetime")
                .HasColumnName("FECHA INICIO");
            entity.Property(e => e.Horas)
                .HasColumnType("smallint(6)")
                .HasColumnName("HORAS");
            entity.Property(e => e.Innovadora).HasColumnName("INNOVADORA");
            entity.Property(e => e.Nombre)
                .HasMaxLength(200)
                .HasColumnName("NOMBRE");
            entity.Property(e => e.TipoIniciativa)
                .HasMaxLength(100)
                .HasColumnName("TIPO INICIATIVA");

            entity.HasMany(d => d.Identidads).WithMany(p => p.Idiniciativas)
                .UsingEntity<Dictionary<string, object>>(
                    "IniciativasEntidadesExterna",
                    r => r.HasOne<EntidadesExterna>().WithMany()
                        .HasForeignKey("Identidad")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__INICIATIV__IDEnt__3F466844"),
                    l => l.HasOne<Iniciativa>().WithMany()
                        .HasForeignKey("Idiniciativa")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__INICIATIV__IDIni__3E52440B"),
                    j =>
                    {
                        j.HasKey("Idiniciativa", "Identidad")
                            .HasName("PRIMARY")
                            .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });
                        j.ToTable("iniciativas_entidades_externas");
                        j.HasIndex(new[] { "Identidad" }, "IX_INICIATIVAS_ENTIDADES_EXTERNAS_IDEntidad");
                        j.IndexerProperty<short>("Idiniciativa")
                            .HasColumnType("smallint(6)")
                            .HasColumnName("IDIniciativa");
                        j.IndexerProperty<short>("Identidad")
                            .HasColumnType("smallint(6)")
                            .HasColumnName("IDEntidad");
                    });

            entity.HasMany(d => d.Meta).WithMany(p => p.IdIniciativas)
                .UsingEntity<Dictionary<string, object>>(
                    "IniciativasMeta",
                    r => r.HasOne<Meta>().WithMany()
                        .HasForeignKey("IdOds", "IdMeta")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_METAS_METAS"),
                    l => l.HasOne<Iniciativa>().WithMany()
                        .HasForeignKey("IdIniciativa")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_METAS_INICIATIVAS"),
                    j =>
                    {
                        j.HasKey("IdIniciativa", "IdOds", "IdMeta")
                            .HasName("PRIMARY")
                            .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });
                        j.ToTable("iniciativas_metas");
                        j.HasIndex(new[] { "IdOds", "IdMeta" }, "IX_INICIATIVAS_METAS_IdODS_IdMeta");
                        j.IndexerProperty<short>("IdIniciativa").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdOds")
                            .HasColumnType("smallint(6)")
                            .HasColumnName("IdODS");
                        j.IndexerProperty<string>("IdMeta").HasMaxLength(4);
                    });

            entity.HasMany(d => d.Modulos).WithMany(p => p.IdIniciativas)
                .UsingEntity<Dictionary<string, object>>(
                    "IniciativasModulo",
                    r => r.HasOne<Modulo>().WithMany()
                        .HasForeignKey("IdCiclo", "IdModulo")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_MODULOS_MODULO"),
                    l => l.HasOne<Iniciativa>().WithMany()
                        .HasForeignKey("IdIniciativa")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_MODULOS_INICIATIVA"),
                    j =>
                    {
                        j.HasKey("IdIniciativa", "IdModulo", "IdCiclo")
                            .HasName("PRIMARY")
                            .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });
                        j.ToTable("iniciativas_modulos");
                        j.HasIndex(new[] { "IdCiclo", "IdModulo" }, "IX_INICIATIVAS_MODULOS_IdCiclo_IdModulo");
                        j.IndexerProperty<short>("IdIniciativa").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdModulo").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdCiclo").HasColumnType("smallint(6)");
                    });
        });

        modelBuilder.Entity<Meta>(entity =>
        {
            entity.HasKey(e => new { e.IdOds, e.IdMeta })
                .HasName("PRIMARY")
                .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

            entity.ToTable("metas");

            entity.Property(e => e.IdOds)
                .HasColumnType("smallint(6)")
                .HasColumnName("IdODS");
            entity.Property(e => e.IdMeta).HasMaxLength(4);
            entity.Property(e => e.Descripcion)
                .HasMaxLength(2500)
                .HasColumnName("DESCRIPCION");

            entity.HasOne(d => d.IdOdsNavigation).WithMany(p => p.Meta)
                .HasForeignKey(d => d.IdOds)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ID_ODS");
        });

        modelBuilder.Entity<Modulo>(entity =>
        {
            entity.HasKey(e => new { e.IdCiclo, e.IdModulo })
                .HasName("PRIMARY")
                .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });

            entity.ToTable("modulos");

            entity.Property(e => e.IdCiclo).HasColumnType("smallint(6)");
            entity.Property(e => e.IdModulo).HasColumnType("smallint(6)");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.IdCicloNavigation).WithMany(p => p.Modulos)
                .HasForeignKey(d => d.IdCiclo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MODULOS");

            entity.HasMany(d => d.IdProfesors).WithMany(p => p.Modulos)
                .UsingEntity<Dictionary<string, object>>(
                    "ProfesoresModulo",
                    r => r.HasOne<Profesore>().WithMany()
                        .HasForeignKey("IdProfesor")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__PROFESORE__IdPro__49C3F6B7"),
                    l => l.HasOne<Modulo>().WithMany()
                        .HasForeignKey("IdCiclo", "IdModulo")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_MODULOS_PROFESORES_MODULOS"),
                    j =>
                    {
                        j.HasKey("IdCiclo", "IdModulo", "IdProfesor")
                            .HasName("PRIMARY")
                            .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });
                        j.ToTable("profesores_modulos");
                        j.HasIndex(new[] { "IdProfesor" }, "IX_PROFESORES_MODULOS_IdProfesor");
                        j.IndexerProperty<short>("IdCiclo").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdModulo").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdProfesor").HasColumnType("smallint(6)");
                    });
        });

        modelBuilder.Entity<Od>(entity =>
        {
            entity.HasKey(e => e.IdOds).HasName("PRIMARY");

            entity.ToTable("ods");

            entity.Property(e => e.IdOds)
                .ValueGeneratedNever()
                .HasColumnType("smallint(6)")
                .HasColumnName("IdODS");
            entity.Property(e => e.Nombre)
                .HasMaxLength(200)
                .HasColumnName("NOMBRE");
        });

        modelBuilder.Entity<Profesore>(entity =>
        {
            entity.HasKey(e => e.IdProfesor).HasName("PRIMARY");

            entity.ToTable("profesores");

            entity.Property(e => e.IdProfesor).HasColumnType("smallint(6)");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasMany(d => d.IdIniciativas).WithMany(p => p.IdProfesors)
                .UsingEntity<Dictionary<string, object>>(
                    "IniciativasProfesore",
                    r => r.HasOne<Iniciativa>().WithMany()
                        .HasForeignKey("IdIniciativa")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_PROFESORES_INICIATIVAS"),
                    l => l.HasOne<Profesore>().WithMany()
                        .HasForeignKey("IdProfesor")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_INICIATIVAS_PROFESORES_PROFESORES"),
                    j =>
                    {
                        j.HasKey("IdProfesor", "IdIniciativa")
                            .HasName("PRIMARY")
                            .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0 });
                        j.ToTable("iniciativas_profesores");
                        j.HasIndex(new[] { "IdIniciativa" }, "IX_INICIATIVAS_PROFESORES_IdIniciativa");
                        j.IndexerProperty<short>("IdProfesor").HasColumnType("smallint(6)");
                        j.IndexerProperty<short>("IdIniciativa").HasColumnType("smallint(6)");
                    });
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
