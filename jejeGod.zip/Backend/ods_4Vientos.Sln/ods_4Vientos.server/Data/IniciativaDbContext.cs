﻿using Microsoft.EntityFrameworkCore;

namespace ods_4Vientos.server.Data
{
    public class IniciativaDbContext : DbContext
    {
        public IniciativaDbContext(DbContextOptions<IniciativaDbContext> options)
            : base(options)
        {
        }

        /*Para traer modelos desde Power Shell: Dentro de la carpeta del proyecto.
         * Importante Cambiar el {Server} por .  O nombre de la instancia de SqlServer en .AppSettings.
         * dotnet ef dbcontext scaffold Name=SqlServerConnection Microsoft.EntityFrameworkCore.SqlServer -o Models -f
         * */

        /* Para migrar base de datos a MySql
         * dotnet ef migrations remove --context Proyecto4vOdsContext
           dotnet ef migrations add InitialCreate --context Proyecto4vOdsContext
           dotnet ef database update --context Proyecto4vOdsContext
         */

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
