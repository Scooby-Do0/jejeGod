﻿namespace ods_4Vientos.server.ModelosFront
{
    public class ModuloFront
    {
        public int IdModulo { get; set; }

        public string Nombre { get; set; }

        public ModuloFront()
        {
        }
        public ModuloFront(int idModulo, string nombre)
        {
            IdModulo = idModulo;
            Nombre = nombre;
        }
    }
}
