﻿using ods_4Vientos.server.Models;

namespace ods_4Vientos.server.ModelosFront
{
    public class IniciativaFront
    {
        public int Id { get; set; }
        public String Nombre { get; set; }
        public String Descripcion { get; set; }
        public String Curso { get; set; }
        public DateTime Fecha_Inicio { get; set; }
        public DateTime? Fecha_Fin { get; set; }
        public String Tipo_Iniciativa { get; set; }
        public Boolean Innovadora { get; set; }
        public int Horas { get; set; }
        public List<String>? Dimensiones { get; set; }
        public List<DifusionFront> DifusionLista { get; set; }
        public List<EntidadExternaFront> EntidadesLista { get; set; }
        public List<OdsFront> OdsLista { get; set; }
        public List<ProfesorFront> ProfesoresLista {        get; set; }
        public List<CicloFront> CiclosLista { get; set; }

        public IniciativaFront()
        {
            DifusionLista = new List<DifusionFront>();
            EntidadesLista = new List<EntidadExternaFront>();
            OdsLista = new List<OdsFront>();
            ProfesoresLista = new List<ProfesorFront>();
            CiclosLista = new List<CicloFront>();
        }
        public IniciativaFront(int id, string nombre, string descripcion, string curso, DateTime fecha_Inicio, DateTime fecha_Fin, string tipo_Iniciativa, bool innovadora, int horas)
        {
            Id = id;
            Nombre = nombre;
            Descripcion = descripcion;
            Curso = curso;
            Fecha_Inicio = fecha_Inicio;
            Fecha_Fin = fecha_Fin;
            Tipo_Iniciativa = tipo_Iniciativa;
            Innovadora = innovadora;
            Horas = horas;
            DifusionLista = new List<DifusionFront>();
            EntidadesLista = new List<EntidadExternaFront>();
            OdsLista = new List<OdsFront>();
            ProfesoresLista = new List<ProfesorFront>();
            CiclosLista = new List<CicloFront>();
        }
        public IniciativaFront(int id, string nombre, string descripcion, string curso, DateTime fecha_Inicio, DateTime fecha_Fin, string tipo_Iniciativa, bool innovadora, int horas, List<DifusionFront> difusionLista, List<EntidadExternaFront> entidadesLista, List<OdsFront> odsLista, List<ProfesorFront> profesoresLista, List<CicloFront> ciclosLista) : this(id, nombre, descripcion, curso, fecha_Inicio, fecha_Fin, tipo_Iniciativa, innovadora, horas)
        {
            DifusionLista = difusionLista;
            EntidadesLista = entidadesLista;
            OdsLista = odsLista;
            ProfesoresLista = profesoresLista;
            CiclosLista = ciclosLista;
        }
    }


}
