﻿namespace ods_4Vientos.server.ModelosFront
{
    public class OdsFront
    {
        public int IdOds { get; set; }
        public string Nombre { get; set; }
        public List<MetaFront> Metas { get; set; }

        public OdsFront()
        {
            Metas = new List<MetaFront>();
        }

        public OdsFront(int idOds, string nombre)
        {
            IdOds = idOds;
            Nombre = nombre;
            Metas = new List<MetaFront>();
        }
        public OdsFront(int idOds, string nombre, List<MetaFront> metas) : this(idOds, nombre)
        {
            Metas = metas;
        }
    }
}
