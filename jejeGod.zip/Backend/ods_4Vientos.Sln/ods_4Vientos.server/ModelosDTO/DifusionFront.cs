﻿namespace ods_4Vientos.server.ModelosFront
{
    public class DifusionFront
    {
        public int Iddifusion { get; set; }

        public string Tipo { get; set; }

        public string Enlace { get; set; }

        public DifusionFront()
        {
        }

        public DifusionFront(int iddifusion, string tipo, string enlace)
        {
            Iddifusion = iddifusion;
            Tipo = tipo;
            Enlace = enlace;
        }
    }
}
