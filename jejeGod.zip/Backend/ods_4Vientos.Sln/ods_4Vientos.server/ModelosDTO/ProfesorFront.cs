﻿namespace ods_4Vientos.server.ModelosFront
{
    public class ProfesorFront
    {
        public int IdProfesor { get; set; }
        public string Nombre { get; set; }
        public ProfesorFront()
        {
        }
        public ProfesorFront(int idProfesor, string nombre)
        {
            IdProfesor = idProfesor;
            Nombre = nombre;
        }
    }
}
