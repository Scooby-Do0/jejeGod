﻿namespace ods_4Vientos.server.ModelosFront
{
    public class CicloFront
    {
        public int IdCiclo { get; set; }
        public string NombreCiclo { get; set; }
        public List<ModuloFront> Modulos { get; set; }

        public CicloFront()
        {
            Modulos = new List<ModuloFront>();
        }
        public CicloFront(int idCiclo, string nombreCiclo)
        {
            IdCiclo = idCiclo;
            NombreCiclo = nombreCiclo;
            Modulos = new List<ModuloFront>();
        }

        public CicloFront(int idCiclo, string nombreCiclo, List<ModuloFront> modulos) : this(idCiclo, nombreCiclo)
        {
            Modulos = modulos;
        }
    }
}
