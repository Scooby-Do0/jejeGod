﻿namespace ods_4Vientos.server.ModelosFront
{
    public class MetaFront
    {
        public String IdMeta { get; set; }
        public String Descripcion { get; set; }
        public MetaFront()
        {
        }
        public MetaFront(String idMeta, string descripcion)
        {
            IdMeta = idMeta;
            Descripcion = descripcion;
        }
    }
}
