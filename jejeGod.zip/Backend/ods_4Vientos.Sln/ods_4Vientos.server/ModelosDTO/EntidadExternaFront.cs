﻿namespace ods_4Vientos.server.ModelosFront
{
    public class EntidadExternaFront
    {
        public int Identidad { get; set; }

        public string Nombre { get; set; }

        public EntidadExternaFront()
        {
        }

        public EntidadExternaFront(int identidad, string nombre)
        {
            Identidad = identidad;
            Nombre = nombre;
        }
    }
}
