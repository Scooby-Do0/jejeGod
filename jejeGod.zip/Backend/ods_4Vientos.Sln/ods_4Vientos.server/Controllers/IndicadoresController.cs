﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services;
using System.Security.Authentication;

namespace ods_4Vientos.server.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class IndicadoresController : ControllerBase
    {
        public readonly IndicadoresService _indicadoresService;

        public IndicadoresController(IndicadoresService indicadoresService)
        {
            this._indicadoresService = indicadoresService;
        }

        [HttpGet("/cursos")]
        [Authorize]
        public async Task<ActionResult> GetCursos()
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.ObtenerCursos();
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("1/{curso?}")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<string>>> GetIndicador1(string curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorUno(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("2/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador2(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorDos(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("3/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador3(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorTres(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("4/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador4(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorCuatro(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("5/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador5(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorCinco(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("6/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador6(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorSeis(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("7/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador7(string? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorSiete(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("8/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador8(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.IndicadorOcho(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("9/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador9(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.Indicador9(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("10/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador10(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.Indicador10(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("11/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador11(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.Indicador11(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("12/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador12(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.Indicador12(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

        [HttpGet("13/{curso?}")]
        [Authorize]
        public async Task<ActionResult> GetIndicador13(String? curso)
        {
            object resultado;
            try
            {
                var resultado2 = await _indicadoresService.Indicador13(curso);
                resultado = resultado2;
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(resultado);
        }

    }
}
