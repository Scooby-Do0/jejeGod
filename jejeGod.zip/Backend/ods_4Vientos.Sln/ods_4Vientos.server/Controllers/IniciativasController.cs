﻿using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services;
using ods_4Vientos.server.Services.Entidades;
using ods_4Vientos.server.Services.Utilidades;
using System.Security.Authentication;

namespace ods_4Vientos.server.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class IniciativasController : ControllerBase
    {
        private readonly IniciativaService _iniciativaService;
        private readonly LoginService _loginService;

        public IniciativasController(IniciativaService iniciativaService, LoginService loginService)
        {
            _iniciativaService = iniciativaService;
            _loginService = loginService;
        }

        [HttpGet("iniciativas")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<IniciativaFront>>> GetIniciativas()
        {

            List<IniciativaFront> iniciativas;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                var iniciativas2 = await _iniciativaService.ObtenerIniciativas();
                iniciativas = iniciativas2.ToList();
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(iniciativas);
        }

        [HttpGet("iniciativas/{id}")]
        [Authorize]
        public async Task<ActionResult<IniciativaFront>> GetIniciativasPorId(short id)
        {
            IniciativaFront iniciativa;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                var iniciativa2 = await _iniciativaService.ObtenerIniciativaPorId(id);
                iniciativa = iniciativa2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(iniciativa);
        }

        [HttpPost("iniciativas")]
        [Authorize]
        public async Task<ActionResult<IniciativaFront>> PostIniciativa(IniciativaFront iniciativa)
        {
            IniciativaFront iniciativaCreada;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                var iniciativa2 = await _iniciativaService.CrearIniciativa(iniciativa);
                iniciativaCreada = iniciativa2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(iniciativaCreada);
        }

        [HttpPut("iniciativas")]
        [Authorize]
        public async Task<ActionResult<IniciativaFront>> PutIniciativa(IniciativaFront iniciativa)
        {
            string authHeader = HttpContext.Request.Headers["Authorization"];
            IniciativaFront iniciativaCreada;
            try
            {
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                var iniciativa2 = await _iniciativaService.ActualizarIniciativa(iniciativa);
                iniciativaCreada = iniciativa2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(iniciativaCreada);
        }

        [HttpDelete("iniciativas/{idIniciativa}")]
        [Authorize]
        public async Task<ActionResult<IniciativaFront>> DeleteIniciativa(short idIniciativa)
        {
            string authHeader = HttpContext.Request.Headers["Authorization"];
            short id;
            try
            {
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                var id2 = await _iniciativaService.BorrarIniciativa(idIniciativa);
                id = id2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(id);
        }

        [HttpGet("iniciativas/rol")]
        public async Task<ActionResult<IniciativaFront>> GetRolProfesor(String email)
        {
            String rolAsignado = String.Empty;
            try
            {
                rolAsignado = await _loginService.ObtenerRol(email);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(rolAsignado);
        }

    }
}
