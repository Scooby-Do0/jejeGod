﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ods_4Vientos.server.ModelosFront;
using ods_4Vientos.server.Models;
using ods_4Vientos.server.Services.Entidades;
using ods_4Vientos.server.Services.Utilidades;
using System.Security.Authentication;

namespace ods_4Vientos.server.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EntidadesController : ControllerBase
    {
        private readonly CicloService _cicloService;
        private readonly DifusionIniciativaService _difusionIniciativaService;
        private readonly EntidadesExternasService _entidadesExternasService;
        private readonly MetaService _metaService;
        private readonly ModulosService _modulosService;
        private readonly OdsService _odsService;
        private readonly ProfesoresService _profesoresService;
        private readonly LoginService _loginService;

        public EntidadesController(CicloService cicloService, DifusionIniciativaService difusionIniciativaService, EntidadesExternasService entidadesExternasService, MetaService metaService, ModulosService modulosService, OdsService odsService, ProfesoresService profesoresService, LoginService loginService)
        {
            _cicloService = cicloService;
            _difusionIniciativaService = difusionIniciativaService;
            _entidadesExternasService = entidadesExternasService;
            _metaService = metaService;
            _modulosService = modulosService;
            _odsService = odsService;
            _profesoresService = profesoresService;
            _loginService = loginService;
        }

        // GET ENTIDADES AUXILIARES //
        [HttpGet("ods")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<OdsFront>>> GetOds()
        {
            List<OdsFront> ods;
            try
            {
                var ods2 = await _odsService.ObtenerOds();
                ods = ods2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ods);
        }

        [HttpGet("metas")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<MetaFront>>> GetMetas()
        {
            List<MetaFront> metas;
            try
            {
                var metas2 = await _metaService.ObtenerMetas();
                metas = metas2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(metas);
        }

        [HttpGet("metas/{idOds}")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<MetaFront>>> GetMetasDeOds(short idOds)
        {
            List<MetaFront> metas;
            try
            {
                var metas2 = await _metaService.ObtenerMetasDeOds(idOds);
                metas = metas2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(metas);
        }

        [HttpGet("entidadesExternas")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<EntidadExternaFront>>> GetEntidadesExternas()
        {
            List<EntidadExternaFront> entidadesExt;
            try
            {
                var entidadesExt2 = await _entidadesExternasService.ObtenerEntidadesExternas();
                entidadesExt = entidadesExt2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(entidadesExt);
        }

        [HttpGet("ciclos")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<CicloFront>>> GetCiclos()
        {
            List<CicloFront> ciclos;
            try
            {
                var ciclos2 = await _cicloService.ObtenerCiclos();
                ciclos = ciclos2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ciclos);
        }

        [HttpGet("modulos")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<ModuloFront>>> GetModulos()
        {
            List<ModuloFront> modulos;
            try
            {
                var modulos2 = await _modulosService.ObtenerModulos();
                modulos = modulos2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(modulos);
        }

        [HttpGet("modulos/{idCiclo}")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<ModuloFront>>> GetModulosDeCiclo(short idCiclo)
        {
            List<ModuloFront> modulos;
            try
            {
                var modulos2 = await _modulosService.ObtenerModulosDeCiclo(idCiclo);
                modulos = modulos2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(modulos);
        }

        [HttpGet("profesores")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<ProfesorFront>>> GetProfesores()
        {
            List<ProfesorFront> profesores;
            try
            {
                var profesores2 = await _profesoresService.ObtenerProfesores();
                profesores = profesores2.ToList();
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(profesores);
        }

        // POST ENTIDADES AUXILIARES //
        [HttpPost("ciclo")]
        [Authorize]
        public async Task<ActionResult<CicloFront>> PostCiclo(CicloFront cicloFront)
        {
            CicloFront ciclo;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized($"No tienes permisos para crear Ciclos");
                }
                var ciclo2 = await _cicloService.CrearCiclo(cicloFront);
                ciclo = ciclo2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ciclo);
        }
        [HttpPost("modulo/{idCiclo}")]
        [Authorize]
        public async Task<ActionResult<ModuloFront>> PostModulo(ModuloFront moduloFront, int idCiclo)
        {
            ModuloFront modulo;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear un módulo");
                }
                var modulo2 = await _modulosService.CrearModulo(moduloFront, idCiclo);
                modulo = modulo2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(modulo);
        }

        [HttpPost("ods /{dimension}")]
        [Authorize]
        public async Task<ActionResult<OdsFront>> PostOds(OdsFront odsFront, String? dimension)
        {
            OdsFront ods;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear Ods");
                }
                var ods2 = await _odsService.CrearOds(odsFront, dimension: dimension);
                ods = ods2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ods);
        }
        [HttpPost("meta/{idOds}")]
        [Authorize]
        public async Task<ActionResult<MetaFront>> PostMeta(MetaFront metaFront, int idOds)
        {
            MetaFront meta;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear una Meta");
                }
                var meta2 = await _metaService.CrearMeta(metaFront, idOds);
                meta = meta2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(meta);
        }
        [HttpPost("entidadExterna")]
        [Authorize]
        public async Task<ActionResult<EntidadExternaFront>> PostEntidadExterna(EntidadExternaFront entidadExternaFront)
        {
            EntidadExternaFront entidadExterna;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear una Entidad Externa");
                }
                var entidadExterna2 = await _entidadesExternasService.CrearEntidadExterna(entidadExternaFront);
                entidadExterna = entidadExterna2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(entidadExterna);
        }
        [HttpPost("profesor")]
        [Authorize]
        public async Task<ActionResult<ProfesorFront>> PostProfesor(ProfesorFront profesorFront)
        {
            ProfesorFront profesor;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear un Profesor");
                }
                var profesor2 = await _profesoresService.CrearProfesor(profesorFront);
                profesor = profesor2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(profesor);
        }

        // UPDATE ENTIDADES AUXILIARES //
        [HttpPut("ciclo")]
        [Authorize]
        public async Task<ActionResult<CicloFront>> UpdateCiclo(CicloFront cicloFront)
        {
            CicloFront ciclo;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para actualizar un Ciclo");
                }
                var ciclo2 = await _cicloService.EditarCiclo(cicloFront);
                ciclo = ciclo2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ciclo);
        }

        [HttpPut("modulo/{idCiclo}")]
        [Authorize]
        public async Task<ActionResult<ModuloFront>> UpdateModulo(ModuloFront moduloFront, int idCiclo)
        {
            ModuloFront modulo;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para actualizar un Módulo");
                }
                var modulo2 = await _modulosService.EditarModulo(moduloFront, idCiclo);
                modulo = modulo2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(modulo);
        }
        [HttpPut("ods")]
        [Authorize]
        public async Task<ActionResult<OdsFront>> UpdateOds(OdsFront odsFront)
        {
            OdsFront ods;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para actualizar un Ods");
                }
                var ods2 = await _odsService.EditarOds(odsFront);
                ods = ods2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(ods);
        }
        [HttpPut("meta/{idOds}")]
        [Authorize]
        public async Task<ActionResult<MetaFront>> UpdateMeta(MetaFront metaFront, int idOds)
        {
            MetaFront meta;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para actualizar una Meta");
                }
                var meta2 = await _metaService.EditarMeta(metaFront, idOds);
                meta = meta2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(meta);
        }

        [HttpPut("entidadExterna")]
        [Authorize]
        public async Task<ActionResult<EntidadExternaFront>> UpdateEntidadExterna(EntidadExternaFront entidadExternaFront)
        {
            EntidadExternaFront entidadExterna;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para editar una Entidad Externa");
                }
                var entidadExterna2 = await _entidadesExternasService.EditarEntidadExterna(entidadExternaFront);
                entidadExterna = entidadExterna2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(entidadExterna);
        }
        [HttpPut("profesor")]
        [Authorize]
        public async Task<ActionResult<ProfesorFront>> UpdateProfesor(ProfesorFront profesorFront)
        {
            ProfesorFront profesor;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                var profesor2 = await _profesoresService.EditarProfesor(profesorFront);
                profesor = profesor2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(profesor);
        }
        [HttpPut("difusion/{idIniciativa}")]
        [Authorize]
        public async Task<ActionResult<DifusionFront>> UpdateDifusionIniciativa(DifusionFront difusionFront, int idIniciativa)
        {
            DifusionFront? difusion;
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                var difusion2 = await _difusionIniciativaService.EditarDifusionIniciativa(difusionFront, idIniciativa);
                difusion = difusion2;
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return Ok(difusion);
        }
        // BORRAR ENTIDADES AUXILIARES //

        [HttpPatch("ciclo/{idCiclo}")]
        [Authorize]
        public async Task<ActionResult> EliminarCiclo(int idCiclo)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _cicloService.BorrarCiclo(idCiclo);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }

        [HttpPatch("modulo/{idModulo}/{idCiclo}")]
        [Authorize]
        public async Task<ActionResult<ModuloFront>> EliminarModulo(int idModulo, int idCiclo)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _modulosService.BorrarModulo(idModulo, idCiclo);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }
        [HttpPatch("ods/{idOds}")]
        [Authorize]
        public async Task<ActionResult> EliminarOds(int idOds)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _odsService.BorrarOds(idOds);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }

        [HttpPatch("meta/{idOds}")]
        [Authorize]
        public async Task<ActionResult<MetaFront>> EliminarMeta(string idMeta, int idOds)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _metaService.BorrarMeta(idMeta, idOds);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }

        [HttpPatch("profesor/{idProfesor}")]
        [Authorize]
        public async Task<ActionResult> EliminarProfesor(int idProfesor)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _profesoresService.BorrarProfesor(idProfesor);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }

        [HttpPatch("entidadExterna/{idEntidadExterna}")]
        [Authorize]
        public async Task<ActionResult> EliminarEntidadExterna(int idEntidadExterna)
        {
            try
            {
                string authHeader = HttpContext.Request.Headers["Authorization"];
                string uid = await _loginService.ComprobarToken(authHeader);
                string rolAsignado = await _loginService.ObtenerRol(uid);
                if (rolAsignado != "Administrador")
                {
                    return Unauthorized("No tienes permisos para crear iniciativas");
                }
                await _entidadesExternasService.BorrarEntidadExterna(idEntidadExterna);
            }
            catch (AuthenticationException e)
            {
                return Unauthorized(e.Message);
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return NoContent();
        }

    }
}
