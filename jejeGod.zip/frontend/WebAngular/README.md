# Web – ODSALos4Vientos

Este proyecto representa la **interfaz web** de la plataforma ODSALos4Vientos, desarrollada en Angular 19. Permite la gestión y visualización de las iniciativas.

Desarrollado utilizando **Visual Studio Code**, que se recomienda como entorno principal para trabajar con esta aplicación.

---

> [!WARNING]
> Antes de ejecutar esta aplicación web, es necesario que el backend esté funcionando correctamente.  
> Sigue las instrucciones en el README principal para activar el backend: [Pasos para activar el backend](https://github.com/JulenMO/ODSALos4Vientos#cómo-ejecutar-el-backend)

---

## Requisitos previos

- [Node.js](https://nodejs.org/es)
- [Angular 19](https://angular.dev/installation)
- [Visual Studio Code](https://code.visualstudio.com/) (recomendado)

---

## Instalación y ejecución

1. Abre una terminal en la carpeta del proyecto:

```
ODSALos4Vientos/frontend/WebAngular
```

2. Instala las dependencias:

```
npm install
```

3. Ejecuta el servidor de desarrollo:

```
ng serve
```

4. Abre tu navegador en:

```
http://localhost:4200/
```

> [!TIP]
> Si necesitas cambiar el puerto, puedes hacerlo con `ng serve --port=XXXX`

---

## Estructura básica del proyecto

- `/src/app/components/` → Componentes visuales (vistas, menús, páginas)
- `/src/app/services/` → Servicios para conexión con la API
- `/src/app/models/` → Modelos TypeScript para estructuras de datos

---

## Tecnologías utilizadas

- **[Angular 19](https://angular.dev/installation)**
- **[Bootstrap 5.5](https://getbootstrap.com/docs/5.3/getting-started/introduction/)**
- **[Font Awesome](https://fontawesome.com/)**
- **[Apache ECharts](https://echarts.apache.org/en/index.html)**
- **TypeScript**
- **SCSS**
- **HTML**

---




