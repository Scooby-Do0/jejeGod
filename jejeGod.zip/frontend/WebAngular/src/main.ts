import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';

import { provideEchartsCore } from 'ngx-echarts';
import { ApplicationConfig } from '@angular/core';

import * as echarts from 'echarts/core';
import { BarChart, GaugeChart, SunburstChart, GraphChart, PieChart,SankeyChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  GridComponent,
  LegendComponent
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

echarts.use([
  BarChart,
  PieChart ,
  GaugeChart,
  SunburstChart,
  GraphChart,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  LegendComponent,
  CanvasRenderer,
  SankeyChart,
]);

const config: ApplicationConfig = {
  ...appConfig,
  providers: [
    ...appConfig.providers!,
    provideEchartsCore({ echarts })
  ]
};

bootstrapApplication(AppComponent, config)
  .catch(err => console.error(err));
