import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ciclo } from '../modelos/ciclo';
import { Modulo } from '../modelos/modulo';

@Injectable({
  providedIn: 'root'
})
export class CicloService {
  private baseUrl = 'https://localhost:7217/Entidades';

  constructor(private http: HttpClient) {}

  getCiclos(): Observable<Ciclo[]> {
    return this.http.get<Ciclo[]>(`${this.baseUrl}/ciclos`);
  }

  getModulos(idCiclo: number): Observable<Modulo[]> {
    return this.http.get<Modulo[]>(`${this.baseUrl}/modulos/${idCiclo}`);
  }

  postCiclo(ciclo: Ciclo): Observable<Ciclo> {
    return this.http.post<Ciclo>(`${this.baseUrl}/ciclo`, ciclo);
  }

  putCiclo(ciclo: Ciclo): Observable<Ciclo> {
    return this.http.put<Ciclo>(`${this.baseUrl}/ciclo`, ciclo);
  }

  patchCiclo(idCiclo: number): Observable<any> {
    return this.http.patch(`${this.baseUrl}/ciclo/${idCiclo}`, null);
  }

  postModulo(idCiclo: number, modulo: Modulo): Observable<Modulo> {
    return this.http.post<Modulo>(`${this.baseUrl}/modulo/${idCiclo}`, modulo);
  }

  putModulo(idCiclo: number, modulo: Modulo): Observable<Modulo> {
    return this.http.put<Modulo>(`${this.baseUrl}/modulo/${idCiclo}`, modulo);
  }

  patchModulo(idCiclo: number, idModulo: number): Observable<any> {
    return this.http.patch(`${this.baseUrl}/modulo/${idModulo}/${idCiclo}`, null);
  }
}
