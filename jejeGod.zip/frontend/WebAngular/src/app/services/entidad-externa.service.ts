import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EntidadExterna } from '../modelos/entidad-externa';

@Injectable({
  providedIn: 'root'
})
export class EntidadExternaService {
  private apiUrl = 'https://localhost:7217/Entidades/entidadesExternas';
  private baseEntidadUrl = 'https://localhost:7217/Entidades/entidadExterna';

  constructor(private httpClient: HttpClient) {}

  getEntidadesExternas(): Observable<EntidadExterna[]> {
    return this.httpClient.get<EntidadExterna[]>(this.apiUrl);
  }

  postEntidadExterna(entidad: EntidadExterna): Observable<any> {
    return this.httpClient.post(this.baseEntidadUrl, entidad);
  }

  putEntidadExterna(entidad: EntidadExterna): Observable<any> {
    return this.httpClient.put(this.baseEntidadUrl, entidad);
  }

  deleteEntidadExterna(id: number): Observable<any> {
    const url = `${this.baseEntidadUrl}/${id}`;
    return this.httpClient.patch(url, null);
  }
  
}
