import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DifusionIniciativa } from '../modelos/difusion-iniciativa';

@Injectable({
  providedIn: 'root'
})
export class DifusionIniciativaService {
  private baseUrl = 'https://localhost:7217/Entidades';

  constructor(private http: HttpClient) {}

  getDifusiones(): Observable<DifusionIniciativa[]> {
    return this.http.get<DifusionIniciativa[]>(`${this.baseUrl}/difusion`);
  }

  putDifusion(idIniciativa: number, difusion: DifusionIniciativa): Observable<any> {
    return this.http.put(`${this.baseUrl}/difusion/${idIniciativa}`, difusion);
  }
}
