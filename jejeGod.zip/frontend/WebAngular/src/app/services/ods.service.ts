import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ods } from '../modelos/ods';
import { Meta } from '../modelos/meta';

@Injectable({
  providedIn: 'root'
})
export class OdsService {
  private baseUrl = 'https://localhost:7217/Entidades';

  constructor(private httpClient: HttpClient) { }

  getOds(): Observable<Ods[]> {
    return this.httpClient.get<Ods[]>(`${this.baseUrl}/ods`);
  }

  postOds(ods: Ods): Observable<any> {
    console.log("ey" + ods.toString());
    return this.httpClient.post(`${this.baseUrl}/ods`, ods);
  }

  putOds(ods: Ods): Observable<any> {
    return this.httpClient.put(`${this.baseUrl}/ods`, ods);
  }

  deleteOds(idOds: number): Observable<any> {
    return this.httpClient.patch(`${this.baseUrl}/ods/${idOds}`, null);
  }

  postMeta(idOds: number, meta: Meta): Observable<any> {
    const body = {
      idMeta: meta.idMeta.toString(),
      descripcion: meta.descripcion
    };
    return this.httpClient.post(`${this.baseUrl}/meta/${idOds}`, body);
  }

  putMeta(idOds: number, meta: Meta): Observable<any> {
    const body = {
      idMeta: meta.idMeta.toString(),
      descripcion: meta.descripcion
    };
    return this.httpClient.put(`${this.baseUrl}/meta/${idOds}`, body);
  }

  deleteMeta(idOds: number, idMeta: string): Observable<any> {
    const params = new HttpParams().set('idMeta', idMeta);
    const body = {
      idMeta: idMeta,
      descripcion: ''
    };
    return this.httpClient.patch(`${this.baseUrl}/meta/${idOds}`, body, { params });
  }
}
