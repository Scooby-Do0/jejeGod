import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from, Observable, of, switchMap } from 'rxjs';
import { Iniciativa } from '../modelos/iniciativa';
import { getAuth } from 'firebase/auth';

@Injectable({
  providedIn: 'root'
})
export class IniciativaService {
  private apiUrl = 'https://localhost:7217/Iniciativas/';

  constructor(private http: HttpClient) { }

  getTodasIniciativas(): Observable<Iniciativa[]> {

    return this.http.get<Iniciativa[]>(this.apiUrl + "iniciativas");
  }

  getIniciativaPorId(id: number): Observable<Iniciativa> {
    return this.http.get<Iniciativa>(this.apiUrl + "iniciativas/" + id);
  }

  crearIniciativa(iniciativa: Iniciativa): Observable<Iniciativa> {
    console.log(iniciativa.difusionLista);

    return this.http.post<Iniciativa>(this.apiUrl + "iniciativas", iniciativa);
  }

  modificarIniciativa(iniciativa: Iniciativa): Observable<Iniciativa> {
    return this.http.put<Iniciativa>(this.apiUrl + "iniciativas", iniciativa);
  }

  borrarIniciativa(id: number): Observable<Iniciativa> {
    return this.http.delete<Iniciativa>(this.apiUrl + "iniciativas/" + id);
  }
}
