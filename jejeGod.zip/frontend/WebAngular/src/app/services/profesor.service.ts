import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Profesor } from '../modelos/profesor';

@Injectable({
  providedIn: 'root'
})
export class ProfesorService {
  private baseUrl = 'https://localhost:7217/Entidades';

  constructor(private http: HttpClient) {}

  getProfesores(): Observable<Profesor[]> {
    return this.http.get<Profesor[]>(`${this.baseUrl}/profesores`);
  }

  postProfesor(profesor: Profesor): Observable<any> {
    return this.http.post(`${this.baseUrl}/profesor`, profesor);
  }

  putProfesor(profesor: Profesor): Observable<any> {
    return this.http.put(`${this.baseUrl}/profesor`, profesor);
  }

  patchProfesor(idProfesor: number): Observable<any> {
    return this.http.patch(`${this.baseUrl}/profesor/${idProfesor}`, null);
  }
}
