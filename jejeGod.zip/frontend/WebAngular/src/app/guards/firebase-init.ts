import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { environment } from '../environments/environment';

export const firebaseApp = !getApps().length
  ? initializeApp(environment.firebaseConfig)
  : getApps()[0];

export const firebaseAuth = getAuth(firebaseApp);
