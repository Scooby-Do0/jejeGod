import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { getAuth } from 'firebase/auth';

@Injectable({ providedIn: 'root' })
export class AuthGuard {
  constructor(private router: Router) { }

  async canActivate(): Promise<boolean> {
    const auth = getAuth();

    for (let i = 0; i < 10; i++) {
      if (auth.currentUser) break;
      await new Promise(r => setTimeout(r, 50));
    }

    const user = auth.currentUser;

    if (user) return true;



    this.router.navigate(['/login']);
    return false;
  }
}
