import { Routes } from '@angular/router';
import { IniciativaComponent } from './components/consulta/iniciativa/iniciativa.component';
import { DetalleComponent } from './components/detalle/detalle.component';
import { CrearIniciativaComponent } from './components/crear-iniciativa/crear-iniciativa.component';
import { IndicadoresComponent } from './components/indicadores/indicadores/indicadores.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'iniciativa', component: IniciativaComponent, canActivate: [AuthGuard] },
  { path: 'detalle/:id', component: DetalleComponent, canActivate: [AuthGuard] },
  { path: 'indicadores', component: IndicadoresComponent, canActivate: [AuthGuard] },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }
];