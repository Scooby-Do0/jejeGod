import { Component, effect } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NgIf } from '@angular/common';
import { FooterComponent } from './components/compartidos/footer/footer.component';
import { NavegacionComponent } from './components/navegacion/navegacion.component';
import { MenuComponent } from './components/compartidos/menu/menu.component';
import { getAuth, onAuthStateChanged } from 'firebase/auth';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    FooterComponent,
    NavegacionComponent,
    MenuComponent,
    NgIf
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'ods-4Vientos.client';
  mostrarMenu = true;

  constructor(private router: Router) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        document.body.style.overflow = 'auto';
        this.mostrarMenu = !event.urlAfterRedirects.includes('/login');
      });

    const auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      if (!user) {
        localStorage.removeItem('usuario');
        this.router.navigate(['/login']);
      }
    });
  }
}
