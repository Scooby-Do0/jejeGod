export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyA2KIXWKfh_ZXXGD_UCEuWZks0HGhF_y6I",
    authDomain: "proyecto4vods-8679e.firebaseapp.com",
    projectId: "proyecto4vods-8679e",
    storageBucket: "proyecto4vods-8679e.appspot.com",
    messagingSenderId: "769704058547",
    appId: "1:769704058547:web:b75bf09097b6e0670a9ac6"
  }
};
