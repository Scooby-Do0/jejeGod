import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

import { initializeApp } from 'firebase/app';
import { firebaseAuth } from '../../guards/firebase-init';
import { signInWithPopup, GoogleAuthProvider, User } from 'firebase/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnDestroy {
  usuario: User | null = null;
  rol: 'admin' | 'user' | null = null;

  isSpinning = false;
  isExpanded = false;
  loginVisible = false;
  textVisible = false;

  message: string = 'CUATROVIENTOS';
  private timeout1: any;
  private timeout2: any;

  constructor(private router: Router) {
  }

  startAnimation(): void {
    if (this.isSpinning || this.isExpanded) return;

    this.isSpinning = true;
    this.textVisible = true;

    this.timeout1 = setTimeout(() => {
      this.isExpanded = true;
      this.textVisible = false;

      this.timeout2 = setTimeout(() => {
        this.loginVisible = true;
      }, 500);
    }, 1000);
  }

  loginConGoogle(): void {
    const provider = new GoogleAuthProvider();
  
    signInWithPopup(firebaseAuth, provider)
      .then((result) => {
        this.usuario = result.user;
        this.rol = 'user';
  
        localStorage.setItem(
          'usuario',
          JSON.stringify({
            nombre: this.usuario.displayName,
            email: this.usuario.email,
            photoURL: this.usuario.photoURL,
            rol: this.rol,
          })
        );
  
        console.log('Usuario logueado:', this.usuario.displayName, 'Rol:', this.rol);
        this.router.navigate(['/iniciativa']);
      })
      .catch((error) => {
        console.error('Error en login:', error);
        alert('Error al iniciar sesión con Google');
      });
  }
  

  ngOnDestroy(): void {
    clearTimeout(this.timeout1);
    clearTimeout(this.timeout2);
  }
}
