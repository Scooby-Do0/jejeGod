import { AfterViewInit, Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

declare const bootstrap: any;

@Component({
  selector   : 'app-dialog-iniciativa',
  standalone : true,
  imports    : [CommonModule],
  templateUrl: './dialog.iniciativa.component.html',
  styleUrls  : ['./dialog.iniciativa.component.scss']
})
export class DialogIniciativaComponent implements AfterViewInit {

  @Output() eliminarConfirmado = new EventEmitter<void>();

  
  ngAfterViewInit(): void {
    const modalEl = document.getElementById('deleteModal');
    if (!modalEl) { return; }

    modalEl.addEventListener('hidden.bs.modal', () => this.restaurarScroll());

    modalEl.addEventListener('shown.bs.modal', () => {
      document.body.style.overflow = 'hidden';
    });
  }

  confirmDelete(): void {
    this.eliminarConfirmado.emit();
    this.cerrarModal();        
  }

  cerrarModal(): void {
    const modalEl = document.getElementById('deleteModal');
    const instance = modalEl ? bootstrap.Modal.getInstance(modalEl) : null;
    instance?.hide();        
  }

  private restaurarScroll(): void {
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
    document.body.style.removeProperty('padding-right');

    document.querySelectorAll('.modal-backdrop')
            .forEach(el => el.parentElement?.removeChild(el));
  }
}
