import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogIniciativaComponent } from './dialog.iniciativa.component';

describe('DialogIniciativaComponent', () => {
  let component: DialogIniciativaComponent;
  let fixture: ComponentFixture<DialogIniciativaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DialogIniciativaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DialogIniciativaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
