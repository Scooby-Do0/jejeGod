import {
  Component,
  Input,
  Output,
  EventEmitter,
  ElementRef,
  ViewChild,
  AfterViewInit,
  ChangeDetectorRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Iniciativa } from '../../../modelos/iniciativa';

@Component({
  selector: 'app-card-iniciativa',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './card.iniciativa.component.html',
  styleUrls: ['./card.iniciativa.component.scss']
})

export class CardIniciativaComponent implements AfterViewInit {
  @Input() iniciativa: Iniciativa | undefined;

  @Output() eliminar = new EventEmitter<number>();
  @Output() seleccionar = new EventEmitter<number>();
  @Output() editar = new EventEmitter<number>();

  @ViewChild('carouselWrapper') carouselWrapper!: ElementRef;
  @ViewChild('ciclosContainer') ciclosContainer!: ElementRef;
  @ViewChild('odsVisible') odsVisible!: ElementRef;

  private tooltipTimeout: any = null;
  private tooltipEl: HTMLDivElement | null = null;


  hasOverflowCiclos: boolean = false;
  hasOverflowODS: boolean = false;
  visibleODS: any[] = [];
  isScrolling: boolean = false;

  private resizeObserver: ResizeObserver | undefined;

  constructor(private cdRef: ChangeDetectorRef) { }

  ngAfterViewInit(): void {
    this.calcularODSVisibles();
    this.calcularOverflowCiclos();
    this.cdRef.detectChanges();

    // Más robusto que window.resize
    this.resizeObserver = new ResizeObserver(() => {
      this.calcularODSVisibles();
      this.calcularOverflowCiclos();
      this.cdRef.detectChanges();
    });

    if (this.carouselWrapper?.nativeElement) {
      this.resizeObserver.observe(this.carouselWrapper.nativeElement);
    }
    if (this.ciclosContainer?.nativeElement) {
      this.resizeObserver.observe(this.ciclosContainer.nativeElement);
    }
  }

  ngOnDestroy(): void {
    this.resizeObserver?.disconnect();
  }

  calcularOverflowCiclos(): void {
    if (!this.ciclosContainer?.nativeElement) return;
    const el = this.ciclosContainer.nativeElement;
    this.hasOverflowCiclos = el.scrollWidth > el.clientWidth;
  }

  calcularODSVisibles(): void {
    if (!this.iniciativa || !this.carouselWrapper?.nativeElement) return;

    const wrapperWidth = this.carouselWrapper.nativeElement.offsetWidth;
    const odsWidth = 30;
    const maxODS = Math.floor(wrapperWidth / odsWidth);

    if ((this.iniciativa.odsLista?.length || 0) > maxODS) {
      this.hasOverflowODS = true;
      this.visibleODS = this.iniciativa.odsLista.slice(0, maxODS - 1);
    } else {
      this.hasOverflowODS = false;
      this.visibleODS = this.iniciativa.odsLista;
    }
  }

  startScrollODS(): void {
    if (this.hasOverflowODS) {
      this.isScrolling = true;
    }
  }

  stopScrollODS(): void {
    this.isScrolling = false;
  }

  onEliminar(event: Event): void {
    event.stopPropagation();
    if (this.iniciativa?.id !== undefined) {
      this.eliminar.emit(this.iniciativa.id);
    }
  }

  onSeleccionarIniciativa(): void {
    if (this.iniciativa?.id !== undefined) {
      this.seleccionar.emit(this.iniciativa.id);
    }
  }

  onEditarIniciativa(id: number): void {
    if (id !== undefined) {
      this.editar.emit(id);
    }
  }



  iniciarTooltip(event: MouseEvent) {
    const el = event.target as HTMLElement;
    const isTruncated = el.scrollWidth > el.clientWidth;

    if (!isTruncated) return;

    this.tooltipTimeout = setTimeout(() => {
      this.showCustomTooltip(el, this.iniciativa?.nombre || '');
    }, 1500);
  }

  cancelarTooltip() {
    clearTimeout(this.tooltipTimeout);
    this.removeCustomTooltip();
  }

  private showCustomTooltip(target: HTMLElement, text: string) {
    this.removeCustomTooltip();

    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    tooltip.innerText = text;

    document.body.appendChild(tooltip);

    const rect = target.getBoundingClientRect();
    tooltip.style.top = `${rect.top - 36}px`;
    tooltip.style.left = `${rect.left}px`;

    this.tooltipEl = tooltip;
  }

  private removeCustomTooltip() {
    if (this.tooltipEl) {
      this.tooltipEl.remove();
      this.tooltipEl = null;
    }
  }



  getOdsIcon(idOds: number): string {
    return `/img/${idOds}.png`;
  }

  get ciclosTexto(): string {
    return this.iniciativa?.ciclosLista?.map(c => c.nombreCiclo).join(', ') || 'Sin ciclos';
  }

  trackByOds(index: number, item: any): number {
    return item.idOds;
  }
}
