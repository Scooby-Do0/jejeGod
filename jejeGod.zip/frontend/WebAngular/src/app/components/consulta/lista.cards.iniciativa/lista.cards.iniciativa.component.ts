import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardIniciativaComponent } from '../card.iniciativa/card.iniciativa.component';
import { Iniciativa } from '../../../modelos/iniciativa';

@Component({
  selector: 'app-lista-cards-iniciativa',
  standalone: true,
  imports: [CommonModule, CardIniciativaComponent],
  templateUrl: './lista.cards.iniciativa.component.html',
  styleUrls: ['./lista.cards.iniciativa.component.scss']
})
export class ListaCardsIniciativaComponent {
  @Input() listaIniciativas: Iniciativa[] = [];
  @Output() eliminar = new EventEmitter<number>();
  @Output() seleccionar = new EventEmitter<number>();
  @Output() editar = new EventEmitter<number>();

  trackByIniciativa(index: number, item: Iniciativa) {
    return item.id;
  }

  onEliminarIniciativa(idIniciativa: number): void {
    this.eliminar.emit(idIniciativa);
  }

  onSeleccionarIniciativa(idIniciativa: number): void {
    this.seleccionar.emit(idIniciativa);
  }

  onEditarIniciativa(idIniciativa: number): void {
    this.editar.emit(idIniciativa);
  }
}
