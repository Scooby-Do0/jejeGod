import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaCardsIniciativaComponent } from './lista.cards.iniciativa.component';

describe('ListaCardsIniciativaComponent', () => {
  let component: ListaCardsIniciativaComponent;
  let fixture: ComponentFixture<ListaCardsIniciativaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListaCardsIniciativaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListaCardsIniciativaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
