import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface FiltroOpciones {
  dimensionSeleccionada?: string[];
  odsSeleccionados?: string[];
  entidadesSeleccionadas?: string[];
  cursosSeleccionados?: string[];        // ciclos
  cursosEscolaresSeleccionados?: string[]; // <-- nuevo
  fechaInicio?: string;
  fechaFin?: string;
  horasMinimas?: number;
  horasMaximas?: number;
  soloInnovadoras?: boolean | null;
  orden?: string;
}


@Component({
  selector: 'app-filtro-iniciativa',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './filtro.iniciativa.component.html',
  styleUrls: ['./filtro.iniciativa.component.scss']
})
export class FiltroIniciativaComponent implements OnInit {
  @Input() ods: string[] = [];
  @Input() entidades: string[] = [];
  @Input() cursosDisponibles: string[] = [];

  @Output() filtroCambiado = new EventEmitter<FiltroOpciones>();
  @Input() cursosEscolaresDisponibles: string[] = [];
  dimensionSeleccionada: string[] = [];
  odsSeleccionados: string[] = [];
  entidadesSeleccionadas: string[] = [];
  cursosSeleccionados: string[] = [];
  fechaInicio: string | null = null;
  fechaFin: string | null = null;
  horasMinimas: number | null = null;
  horasMaximas: number | null = null;
  soloInnovadoras: boolean | null = null;
  ordenSeleccionado: string = '';
  cursosEscolaresSeleccionados: string[] = [];

  constructor(private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.cdr.detectChanges();
  }

  onDimensionChange(dimension: string, event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.checked) {
      this.dimensionSeleccionada.push(dimension);
    } else {
      this.dimensionSeleccionada = this.dimensionSeleccionada.filter(d => d !== dimension);
    }
    this.emitirFiltros();
  }

  onOdsChange(od: string, event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.checked) {
      this.odsSeleccionados.push(od);
    } else {
      this.odsSeleccionados = this.odsSeleccionados.filter(x => x !== od);
    }
    this.emitirFiltros();
  }

  onEntidadChange(ent: string, event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.checked) {
      this.entidadesSeleccionadas.push(ent);
    } else {
      this.entidadesSeleccionadas = this.entidadesSeleccionadas.filter(x => x !== ent);
    }
    this.emitirFiltros();
  }

  onCursoChange(curso: string, event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.checked) {
      this.cursosSeleccionados.push(curso);
    } else {
      this.cursosSeleccionados = this.cursosSeleccionados.filter(x => x !== curso);
    }
    this.emitirFiltros();
  }

  setInnovadoraFiltro(valor: boolean | null): void {
    this.soloInnovadoras = valor;
    this.emitirFiltros();
  }

  onOrdenChange(event: any) {
    this.ordenSeleccionado = event.target.value;
    this.emitirFiltros();
  }

  limpiarFiltros() {
    this.dimensionSeleccionada = [];
    this.odsSeleccionados = [];
    this.entidadesSeleccionadas = [];
    this.cursosSeleccionados = [];
    this.fechaInicio = null;
    this.fechaFin = null;
    this.horasMinimas = null;
    this.horasMaximas = null;
    this.soloInnovadoras = null;
    this.ordenSeleccionado = '';
    this.emitirFiltros();
  }

  emitirFiltros(): void {
    this.filtroCambiado.emit({
      dimensionSeleccionada: this.dimensionSeleccionada,
      odsSeleccionados: this.odsSeleccionados,
      entidadesSeleccionadas: this.entidadesSeleccionadas,
      cursosSeleccionados: this.cursosSeleccionados,
      cursosEscolaresSeleccionados: this.cursosEscolaresSeleccionados,
      fechaInicio: this.fechaInicio || undefined,
      fechaFin: this.fechaFin || undefined,
      horasMinimas: this.horasMinimas != null && this.horasMinimas >= 0 ? this.horasMinimas : undefined,
      horasMaximas: this.horasMaximas != null && this.horasMaximas >= 0 ? this.horasMaximas : undefined,
      soloInnovadoras: this.soloInnovadoras,
      orden: this.ordenSeleccionado || ''
    });

  }

  onCursoEscolarChange(curso: string, event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.checked) {
      this.cursosEscolaresSeleccionados.push(curso);
    } else {
      this.cursosEscolaresSeleccionados = this.cursosEscolaresSeleccionados.filter(x => x !== curso);
    }
    this.emitirFiltros();
  }
}
