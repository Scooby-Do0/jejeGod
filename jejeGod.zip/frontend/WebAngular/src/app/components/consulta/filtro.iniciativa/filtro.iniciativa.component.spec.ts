import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiltroIniciativaComponent } from './filtro.iniciativa.component';

describe('FiltroIniciativaComponent', () => {
  let component: FiltroIniciativaComponent;
  let fixture: ComponentFixture<FiltroIniciativaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FiltroIniciativaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FiltroIniciativaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
