import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CabeceraIniciativaComponent } from '../cabecera.iniciativa/cabecera.iniciativa.component';
import { FiltroIniciativaComponent, FiltroOpciones } from '../filtro.iniciativa/filtro.iniciativa.component';
import { ListaCardsIniciativaComponent } from '../lista.cards.iniciativa/lista.cards.iniciativa.component';
import { DialogIniciativaComponent } from '../dialog.iniciativa/dialog.iniciativa.component';
import { Iniciativa } from '../../../modelos/iniciativa';
import { Ods } from '../../../modelos/ods';
import { Ciclo } from '../../../modelos/ciclo';
import { EntidadExterna } from '../../../modelos/entidad-externa';
import { IniciativaService } from '../../../services/iniciativa.service';
import { OdsService } from '../../../services/ods.service';
import { EntidadExternaService } from '../../../services/entidad-externa.service';
import { CicloService } from '../../../services/ciclo.service';
import { ViewChild } from '@angular/core';
import { CrearIniciativaComponent } from '../../crear-iniciativa/crear-iniciativa.component';
import { GestionarEntidadesComponent } from '../../gestionar-entidad/gestionar-entidades-externas/gestionar-entidades-externas.component';
import { GestionarOdsComponent } from '../../gestionar-entidad/gestionar-ods/gestionar-ods.component';
import { GestionarCicloComponent } from '../../gestionar-entidad/gestionar-ciclos/gestionar-ciclos.component';
import { GestionarProfesoresComponent } from '../../gestionar-entidad/gestionar-profesores/gestionar-profesores.component';
import { ChangeDetectorRef } from '@angular/core';
import { Meta } from '../../../modelos/meta';
import { Modulo } from '../../../modelos/modulo';
import { DetalleComponent } from '../../detalle/detalle.component';

type FormSnapshot = {
  iniciativa: Partial<Iniciativa>;
  fechaInicioStr: string;
  fechaFinStr: string;
  cursoInput: string;
  metasSeleccionadasPorOds: Record<number, Meta[]>;
  modulosSeleccionados: Modulo[];
  redesSeleccionadas: { id: string; nombre: string; icono: string; enlace: string; idDifusion?: number }[];
};

declare var bootstrap: any;

@Component({
  selector: 'app-iniciativa',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    CabeceraIniciativaComponent,
    FiltroIniciativaComponent,
    ListaCardsIniciativaComponent,
    DialogIniciativaComponent, CrearIniciativaComponent,
    GestionarEntidadesComponent,
    GestionarOdsComponent,
    GestionarCicloComponent,
    GestionarProfesoresComponent, DetalleComponent
  ],
  templateUrl: './iniciativa.component.html',
  styleUrls: ['./iniciativa.component.scss']
})

export class IniciativaComponent implements OnInit {
  listaIniciativas: Iniciativa[] = [];
  listaIniciativasFiltradas: Iniciativa[] = [];
  terminoBusqueda: string = '';
  odsDisponibles: string[] = [];
  entidadesDisponibles: string[] = [];
  ciclosDisponibles: string[] = [];
  filtroOpciones: FiltroOpciones = {};
  idIniciativaAEliminar: number | null = null;
  paginaActual: number = 1;
  iniciativasPorPagina: number = 50;
  totalPaginas: number = 1;
  mostrarGestionarEntidades = false;
  mostrarGestionarOds = false;
  mostrarGestionarCiclos = false;
  mostrarGestionarProfesores = false;
  crearIniciativaAbierta: boolean = false;
  idIniciativaAEditar: number | null = null;
  orden: Record<'nombre' | 'curso' | 'horas', 'asc' | 'desc' | undefined> = {
    nombre: undefined,
    curso: undefined,
    horas: undefined
  };
  mostrarAlertaError: boolean = false;
  mensajeAlertaError: string = '';
  detalleAbierto = false;
  idIniciativaAVer: number | null = null;
  formularioTemporal: FormSnapshot | null = null;
  cargandoIniciativas: boolean = true;


  constructor(
    private iniciativaService: IniciativaService,
    private odsService: OdsService,
    private entidadExternaService: EntidadExternaService,
    private cicloService: CicloService,
    private router: Router,
    private cd: ChangeDetectorRef
  ) { }

  @ViewChild(FiltroIniciativaComponent) filtroComp!: FiltroIniciativaComponent;
  @ViewChild(CrearIniciativaComponent) crearIniciativa!: CrearIniciativaComponent;

  ngOnInit(): void {
    this.cargarIniciativas();
    this.cargarOds();
    this.cargarEntidades();
    this.cargarCiclos();
  }

  cargarIniciativas(): void {
    this.cargandoIniciativas = true;
    this.iniciativaService.getTodasIniciativas().subscribe({
      next: (data: Iniciativa[]) => {
        this.listaIniciativas = data;
        this.listaCursosEscolares = [...new Set(data.map(i => i.curso))].filter(Boolean);
        this.listaIniciativas.forEach((ini: any) => (ini['_animState'] = 'visible'));
        this.aplicarFiltrosYBusqueda();
        this.cargandoIniciativas = false;

      },
      error: (err) => {
        console.error('Error al cargar iniciativas:', err);
        this.cargandoIniciativas = false;
      }
    });
  }

  cargarOds(): void {
    this.odsService.getOds().subscribe({
      next: (response: any) => {
        if (Array.isArray(response)) {
          this.odsDisponibles = response.map((o: Ods) => o.idOds.toString());
        }
      },
      error: (err) => console.error("Error al cargar ODS:", err)
    });
  }

  cargarEntidades(): void {
    this.entidadExternaService.getEntidadesExternas().subscribe({
      next: (entidades: EntidadExterna[]) => {
        this.entidadesDisponibles = entidades.map(e => e.nombre);
      },
      error: (err) => console.error('Error al cargar entidades:', err)
    });
  }

  cargarCiclos(): void {
    this.cicloService.getCiclos().subscribe({
      next: (response: any) => {
        if (Array.isArray(response)) {
          this.ciclosDisponibles = response.map((c: Ciclo) => c.nombreCiclo);
        }
      },
      error: (err) => console.error("Error al cargar ciclos:", err)
    });
  }

  filtrarIniciativasPorCabecera(termino: string): void {
    this.terminoBusqueda = termino.trim().toLowerCase();
    this.aplicarFiltrosYBusqueda();
  }

  onFiltroActualizado(filtro: FiltroOpciones): void {
    this.filtroOpciones = filtro;
    this.paginaActual = 1;
    this.aplicarFiltrosYBusqueda();
  }

  toggleOrden(campo: 'nombre' | 'curso' | 'horas'): void {
    const actual = this.orden[campo];
    if (actual === 'desc') {
      this.orden = { nombre: undefined, curso: undefined, horas: undefined };
    } else {
      this.orden = { nombre: undefined, curso: undefined, horas: undefined };
      this.orden[campo] = actual === 'asc' ? 'desc' : 'asc';
    }
    this.aplicarFiltrosYBusqueda();
  }

  aplicarFiltrosYBusqueda(): void {
    let resultado = [...this.listaIniciativas];
    if (this.terminoBusqueda) {
      const txt = this.terminoBusqueda;
      resultado = resultado.filter(ini => {
        const nombre = ini.nombre?.toLowerCase() || '';
        const desc = ini.descripcion?.toLowerCase() || '';
        const dims = ini.dimensiones?.join(' ').toLowerCase() || '';
        const odsNames = ini.odsLista.map(o => o.nombre.toLowerCase()).join(' ');
        return nombre.includes(txt) || desc.includes(txt) || dims.includes(txt) || odsNames.includes(txt);
      });
    }

    if (this.filtroOpciones.odsSeleccionados?.length) {
      resultado = resultado.filter(ini =>
        this.filtroOpciones.odsSeleccionados!.every(sel =>
          ini.odsLista.some(ods => ods.idOds.toString() === sel)
        )
      );
    }

    if (this.filtroOpciones.entidadesSeleccionadas?.length) {
      resultado = resultado.filter(ini =>
        this.filtroOpciones.entidadesSeleccionadas!.every(entSel =>
          ini.entidadesLista.some(e => e.nombre === entSel)
        )
      );
    }
    if (this.filtroOpciones.cursosEscolaresSeleccionados?.length) {
      resultado = resultado.filter(ini =>
        this.filtroOpciones.cursosEscolaresSeleccionados!.includes(ini.curso)
      );
    }
    if (this.filtroOpciones.dimensionSeleccionada?.length) {
      resultado = resultado.filter(ini => {
        const normalizar = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        const dimsInic = ini.dimensiones.map(normalizar);
        const dimsFilt = this.filtroOpciones.dimensionSeleccionada!.map(normalizar);
        return dimsFilt.every(df => dimsInic.includes(df));
      });
    }

    if (this.filtroOpciones.cursosSeleccionados?.length) {
      resultado = resultado.filter(ini =>
        this.filtroOpciones.cursosSeleccionados!.every(curso =>
          ini.ciclosLista.some(c => c.nombreCiclo === curso)
        )
      );
    }

    if (this.filtroOpciones.soloInnovadoras != null) {
      resultado = resultado.filter(ini => ini.innovadora === this.filtroOpciones.soloInnovadoras);
    }

    if (this.filtroOpciones.fechaInicio) {
      const fechaInicioFiltro = new Date(this.filtroOpciones.fechaInicio);
      resultado = resultado.filter(ini => new Date(ini.fecha_Inicio) >= fechaInicioFiltro);
    }

    if (this.filtroOpciones.fechaFin) {
      const fechaFinFiltro = new Date(this.filtroOpciones.fechaFin);
      resultado = resultado.filter(ini => ini.fecha_Fin ? new Date(ini.fecha_Fin) <= fechaFinFiltro : false);
    }

    if (this.filtroOpciones.horasMinimas != null) {
      resultado = resultado.filter(ini => ini.horas >= this.filtroOpciones.horasMinimas!);
    }

    if (this.filtroOpciones.horasMaximas != null) {
      resultado = resultado.filter(ini => ini.horas <= this.filtroOpciones.horasMaximas!);
    }

    const criteriosOrden = ['nombre', 'curso', 'horas'];
    resultado.sort((a, b) => {
      for (const criterio of criteriosOrden) {
        const dir = this.orden[criterio as keyof typeof this.orden];
        if (!dir) continue;
        let comp = 0;
        if (criterio === 'nombre') comp = a.nombre.localeCompare(b.nombre);
        else if (criterio === 'curso') comp = a.curso.localeCompare(b.curso);
        else if (criterio === 'horas') comp = a.horas - b.horas;
        if (comp !== 0) return dir === 'asc' ? comp : -comp;
      }
      return 0;
    });

    this.listaIniciativasFiltradas = resultado;
    this.calcularPaginacion();
  }

  calcularPaginacion(): void {
    this.totalPaginas = Math.ceil(this.listaIniciativasFiltradas.length / this.iniciativasPorPagina);
    if (this.paginaActual > this.totalPaginas) this.paginaActual = this.totalPaginas || 1;
  }

  get iniciativasPaginadas(): Iniciativa[] {
    const startIndex = (this.paginaActual - 1) * this.iniciativasPorPagina;
    const endIndex = startIndex + this.iniciativasPorPagina;
    return this.listaIniciativasFiltradas.slice(startIndex, endIndex);
  }

  irPrimeraPagina() {
    this.paginaActual = 1;
  }

  irUltimaPagina() {
    this.paginaActual = this.totalPaginas;
  }

  paginaAnterior() {
    if (this.paginaActual > 1) this.paginaActual--;
  }

  paginaSiguiente() {
    if (this.paginaActual < this.totalPaginas) this.paginaActual++;
  }

  onEliminarIniciativa(id: number): void {
    this.idIniciativaAEliminar = id;
    const modal = document.getElementById('deleteModal');
    if (modal) {
      const bsModal = new bootstrap.Modal(modal);
      bsModal.show();
    }
  }

  confirmarEliminar(): void {
    if (this.idIniciativaAEliminar != null) {
      const index = this.listaIniciativas.findIndex(x => x.id === this.idIniciativaAEliminar);
      if (index !== -1) this.listaIniciativas[index]['_animState'] = 'removing';

      this.iniciativaService.borrarIniciativa(this.idIniciativaAEliminar).subscribe({
        next: () => setTimeout(() => this.cargarIniciativas(), 400),
        error: (err) => console.error('Error al eliminar iniciativa:', err)
      });
      this.idIniciativaAEliminar = null;
    }
  }

  onSeleccionarIniciativa(id: number): void {
    this.abrirDetalle(id);
  }

  onEditarIniciativa(id: number): void {
    this.crearIniciativaAbierta = true;
    this.idIniciativaAEditar = id;
  }
  onCrearIniciativa(): void {
    document.body.style.overflow = 'hidden';
    this.idIniciativaAEditar = null;
    this.crearIniciativaAbierta = true;
    this.mostrarAlertaError = false;

    setTimeout(() => {
      this.cd.detectChanges();
    });
  }

  mostrarAlertaDesdeHijo(msg: string) {
    this.mostrarAlertaError = true;
    this.mensajeAlertaError = msg;
  }

  ocultarAlertaError(event: Event): void {
    event.stopPropagation();
    this.mostrarAlertaError = false;
  }
  onCerrarCrearIniciativa(evento: 'cerrar' | 'actualizar') {
    this.cerrarCrearIniciativa();
    if (evento === 'actualizar') {
      this.cargarIniciativas();
    }
  }




  hayFiltrosActivos(): boolean {
    const f = this.filtroOpciones;
    return (
      (f.odsSeleccionados?.length ?? 0) > 0 ||
      (f.entidadesSeleccionadas?.length ?? 0) > 0 ||
      (f.dimensionSeleccionada?.length ?? 0) > 0 ||
      (f.cursosSeleccionados?.length ?? 0) > 0 ||
      !!f.fechaInicio || !!f.fechaFin ||
      typeof f.horasMinimas === 'number' ||
      typeof f.horasMaximas === 'number' ||
      typeof f.soloInnovadoras === 'boolean'
    );
  }

  quitarOds(odsSel: string): void {
    this.filtroComp.odsSeleccionados = this.filtroComp.odsSeleccionados?.filter(o => o !== odsSel);
    this.filtroComp.emitirFiltros();
  }

  quitarEntidad(ent: string): void {
    this.filtroComp.entidadesSeleccionadas = this.filtroComp.entidadesSeleccionadas?.filter(e => e !== ent);
    this.filtroComp.emitirFiltros();
  }

  quitarDimension(dim: string): void {
    this.filtroComp.dimensionSeleccionada = this.filtroComp.dimensionSeleccionada?.filter(d => d !== dim);
    this.filtroComp.emitirFiltros();
  }

  quitarCurso(cur: string): void {
    this.filtroComp.cursosSeleccionados = this.filtroComp.cursosSeleccionados?.filter(c => c !== cur);
    this.filtroComp.emitirFiltros();
  }


  resetFiltros(): void {
    this.filtroOpciones = {};
    this.orden = { nombre: undefined, curso: undefined, horas: undefined };
    this.paginaActual = 1;

    if (this.filtroComp) {
      this.filtroComp.limpiarFiltros();
    }

    this.aplicarFiltrosYBusqueda();
  }
  cerrarCrearIniciativa(): void {
    if (this.idIniciativaAEditar === null && this.crearIniciativa) {
      const f = this.crearIniciativa;
      this.formularioTemporal = structuredClone({
        iniciativa: { ...f.iniciativa, id: 0 },
        fechaInicioStr: f.fechaInicioStr,
        fechaFinStr: f.fechaFinStr,
        cursoInput: f.cursoInput,
        metasSeleccionadasPorOds: f.metasSeleccionadasPorOds,
        modulosSeleccionados: f.modulosSeleccionados,
        redesSeleccionadas: f.redesSeleccionadas
      });
    } else {
      this.formularioTemporal = null;
    }

    this.crearIniciativaAbierta = false;
    document.body.style.overflow = 'auto';
  }



  abrirGestionarEntidades() {
    this.mostrarGestionarEntidades = true;
  }

  abrirGestionarOds() {
    this.mostrarGestionarOds = true;
  }

  abrirGestionarCiclos() {
    this.mostrarGestionarCiclos = true;
  }

  abrirGestionarProfesores() {
    this.mostrarGestionarProfesores = true;
  }

  cerrarGestionar() {
    this.mostrarGestionarEntidades = false;
    this.mostrarGestionarOds = false;
    this.mostrarGestionarCiclos = false;
    this.mostrarGestionarProfesores = false;
  }
  filtrosColapsados = false;
  animandoCierreFiltros = false;

  toggleFiltros() {
    if (!this.filtrosColapsados) {
      this.animandoCierreFiltros = true;

      setTimeout(() => {
        this.filtrosColapsados = true;
        this.animandoCierreFiltros = false;
      }, 300);
    } else {
      this.filtrosColapsados = false;
    }
  }

  listaCursosEscolares: string[] = [];

  quitarCursoEscolar(curso: string): void {
    this.filtroComp.cursosEscolaresSeleccionados = this.filtroComp.cursosEscolaresSeleccionados?.filter(c => c !== curso);
    this.filtroComp.emitirFiltros();
  }

  quitarInnovadora(): void {
    this.filtroComp.setInnovadoraFiltro(null);
  }

  abrirDetalle(id: number): void {
    document.body.style.overflow = 'hidden';
    this.idIniciativaAVer = id;
    this.detalleAbierto = true;
  }

  cerrarDetalle(): void {
    this.detalleAbierto = false;
    this.idIniciativaAVer = null;
    document.body.style.overflow = 'auto';
  }
  onIniciativaClonada(): void {
    this.cargarIniciativas();
  }

}
