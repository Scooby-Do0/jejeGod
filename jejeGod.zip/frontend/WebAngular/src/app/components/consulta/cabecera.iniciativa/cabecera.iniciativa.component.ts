import { Component, EventEmitter, Output, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cabecera-iniciativa',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cabecera.iniciativa.component.html',
  styleUrls: ['./cabecera.iniciativa.component.scss']
})
export class CabeceraIniciativaComponent {
  @Output() buscarIniciativa = new EventEmitter<string>();
  @Input() totalResultados: number = 0;  
  terminoBusqueda: string = '';

  onBusquedaCambio(): void {
    this.buscarIniciativa.emit(this.terminoBusqueda.trim());
  }
}
