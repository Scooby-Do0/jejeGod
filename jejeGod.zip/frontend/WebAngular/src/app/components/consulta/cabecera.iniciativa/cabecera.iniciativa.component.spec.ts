import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraIniciativaComponent } from './cabecera.iniciativa.component';

describe('CabeceraIniciativaComponent', () => {
  let component: CabeceraIniciativaComponent;
  let fixture: ComponentFixture<CabeceraIniciativaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CabeceraIniciativaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CabeceraIniciativaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
