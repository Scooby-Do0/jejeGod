import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { IniciativaService } from '../../services/iniciativa.service';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Iniciativa } from '../../modelos/iniciativa';
import { Router } from '@angular/router';


@Component({
  selector: 'app-detalle',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.scss']
})
export class DetalleComponent implements OnInit {
  @Input() id!: number;
  @Output() cerrar = new EventEmitter<void>();
  @Output() clonado = new EventEmitter<void>();

  iniciativa$: Observable<Iniciativa> = of();
  expandedOdsId: number | null = null;
  mensajeError: string | null = null;
  mostrarError: boolean = false;
  mostrarConfirmacion: boolean = false;

  constructor(
    private iniciativaService: IniciativaService,
    private router: Router
  ) { }
  ngOnInit(): void {
    if (this.id) this.cargarIniciativa(this.id);
  }

  private cargarIniciativa(idIniciativa: number): void {
    this.iniciativa$ = this.iniciativaService.getIniciativaPorId(idIniciativa).pipe(
      map((iniciativa) => ({
        ...iniciativa,
        ciclosLista: iniciativa.ciclosLista || [],
        profesoresLista: iniciativa.profesoresLista || [],
        odsLista: iniciativa.odsLista || [],
        entidadesLista: iniciativa.entidadesLista || [],
        difusionLista: iniciativa.difusionLista || [],
        dimensiones: iniciativa.dimensiones || []
      })),
      catchError((error) => {
        console.error('Error al cargar la iniciativa:', error);
        return of({
          id: 0,
          nombre: 'No disponible',
          descripcion: 'No disponible',
          curso: 'No disponible',
          fecha_Inicio: new Date(),
          fecha_Fin: null,
          tipo_Iniciativa: 'No disponible',
          accion: 'No disponible',
          innovadora: false,
          horas: 0,
          dimensiones: [],
          difusionLista: [],
          entidadesLista: [],
          odsLista: [],
          profesoresLista: [],
          ciclosLista: []
        });
      })
    );
  }

  getOdsIcon(id: number): string {
    return `/img/${id}.png`;
  }

  getDifusionIcon(tipo: string): string {
    const tipoLower = tipo?.toLowerCase() || '';
    const iconosDisponibles = ['instagram', 'facebook', 'twitter', 'linkedin', 'youtube'];
    return iconosDisponibles.includes(tipoLower)
      ? `/img/${tipoLower}.png`
      : `/img/web.png`;
  }

  toggleExpandedODS(id: number): void {
    this.expandedOdsId = this.expandedOdsId === id ? null : id;
  }

  getDimensionClass(dim: string): string {
    switch (dim.toLowerCase()) {
      case 'medioambiental': return 'medioambiental';
      case 'social': return 'social';
      case 'económica': return 'economico';
      default: return '';
    }
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  abrirDialogoConfirmacion(): void {
    this.mostrarConfirmacion = true;
  }
  
  confirmarClonado(): void {
    this.mostrarConfirmacion = false;
    this.iniciativa$.subscribe(orig => {
      const payload = this.buildClonePayload(orig);
      this.iniciativaService.crearIniciativa(payload).subscribe({
        next: () => {
          this.clonado.emit();
          this.cerrar.emit();
        },
        error: err => {
          console.error('Error al clonar', err);
          this.mensajeError = '⚠️ Error al clonar la iniciativa.';
          this.mostrarError = true;
          setTimeout(() => this.mostrarError = false, 4000);
        }
      });
    });
  }
  

  private buildClonePayload(orig: Iniciativa): Iniciativa {
    const clone: Iniciativa = { ...orig, id: 0 };

    clone.fecha_Inicio = new Date(orig.fecha_Inicio);
    clone.fecha_Fin = orig.fecha_Fin ? new Date(orig.fecha_Fin) : null;

    const anioIni = clone.fecha_Inicio.getMonth() >= 8
      ? clone.fecha_Inicio.getFullYear()
      : clone.fecha_Inicio.getFullYear() - 1;
    clone.curso = `${anioIni}-${anioIni + 1}`;

    clone.difusionLista = orig.difusionLista.map(d => ({
      ...d,
      iddifusion: 0
    }));


    return clone;
  }
  cancelarClonado(): void {
    this.mostrarConfirmacion = false;
  }
  confirmarClonadoDesdeModal(): void {
    this.iniciativa$.subscribe(orig => {
      const payload = this.buildClonePayload(orig);
  
      this.iniciativaService.crearIniciativa(payload).subscribe({
        next: () => {
          this.clonado.emit();
          this.cerrar.emit();
          this.limpiarBackdropYScroll();
        },
        error: err => {
          console.error('Error al clonar', err);
          this.mensajeError = '⚠️ Error al clonar la iniciativa.';
          this.mostrarError = true;
          setTimeout(() => this.mostrarError = false, 4000);
          this.limpiarBackdropYScroll();
        }
      });
    });
  }
  
  private limpiarBackdropYScroll(): void {
    setTimeout(() => {
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
  }, 300);
  
    const backdrops = document.querySelectorAll('.modal-backdrop');
    backdrops.forEach(b => b.remove());
  }
  
  
}

