import { Component, Input, OnInit, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { HostListener } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';


import { IniciativaService } from '../../services/iniciativa.service';
import { OdsService } from '../../services/ods.service';
import { CicloService } from '../../services/ciclo.service';
import { ProfesorService } from '../../services/profesor.service';
import { EntidadExternaService } from '../../services/entidad-externa.service';

import { Iniciativa } from '../../modelos/iniciativa';
import { Ods } from '../../modelos/ods';
import { Ciclo } from '../../modelos/ciclo';
import { Profesor } from '../../modelos/profesor';
import { EntidadExterna } from '../../modelos/entidad-externa';
import { Meta } from '../../modelos/meta';
import { Modulo } from '../../modelos/modulo';


type FormSnapshot = {
  iniciativa: Partial<Iniciativa>;
  fechaInicioStr: string;
  fechaFinStr: string;
  cursoInput: string;
  metasSeleccionadasPorOds: Record<number, Meta[]>;
  modulosSeleccionados: Modulo[];
  redesSeleccionadas: { id: string; nombre: string; icono: string; enlace: string; idDifusion?: number }[];
};

@Component({
  selector: 'app-crear-iniciativa',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './crear-iniciativa.component.html',
  styleUrls: ['./crear-iniciativa.component.scss']
})

export class CrearIniciativaComponent implements OnInit, OnChanges {



  iniciativa: Iniciativa = {
    id: 0,
    nombre: '',
    descripcion: '',
    curso: '',
    fecha_Inicio: new Date(),
    fecha_Fin: new Date(),
    tipo_Iniciativa: '',
    innovadora: false,
    horas: 1,
    dimensiones: [],
    difusionLista: [],
    entidadesLista: [],
    odsLista: [],
    profesoresLista: [],
    ciclosLista: []
  };

  odsDisponibles: Ods[] = [];
  ciclosDisponibles: Ciclo[] = [];
  profesoresDisponibles: Profesor[] = [];
  entidadesDisponibles: EntidadExterna[] = [];

  metasSeleccionadasPorOds: Record<number, Meta[]> = {};
  modulosSeleccionados: Modulo[] = [];

  mostrarMetas: Record<number, boolean> = {};
  mostrarModulos: Record<number, boolean> = {};
  expandirMetas: Record<number, boolean> = {};
  activeDropdown: string | null = null;
  cursoInput: string = '';
  formularioTemporal: FormSnapshot | null = null;

  @Input() idIniciativa: number | null = null;
  @Output() cerrar = new EventEmitter<'cerrar' | 'actualizar'>();
  @ViewChild('crearIniciativa') crearIniciativa!: CrearIniciativaComponent;
  @Input() snapshot: FormSnapshot | null = null;
  @Output() mostrarErrorExterno = new EventEmitter<string>();


  redesDisponibles = [
    { nombre: 'Otro', icono: 'fa-solid fa-globe', id: 'otro' },
    { nombre: 'Instagram', icono: 'fa-brands fa-instagram', id: 'instagram' },
    { nombre: 'X (Twitter)', icono: 'fa-brands fa-square-x-twitter', id: 'twitter' },
    { nombre: 'LinkedIn', icono: 'fa-brands fa-linkedin', id: 'linkedin' },
    { nombre: 'YouTube', icono: 'fa-brands fa-youtube', id: 'youtube' },
    { nombre: 'Facebook', icono: 'fa-brands fa-facebook', id: 'facebook' }
  ];

  redesSeleccionadas: { id: string; idDifusion?: number, nombre: string; icono: string; enlace: string }[] = [];

  errorMensaje: string = "";
  mostrarError: boolean = false;

  fechaInicioStr: string = "";
  fechaFinStr: string = "";

  constructor(
    private iniciativaService: IniciativaService,
    private odsService: OdsService,
    private cicloService: CicloService,
    private profesorService: ProfesorService,
    private entidadService: EntidadExternaService,
    private router: Router,
    private route: ActivatedRoute
  ) { }




  ngOnInit(): void {
    Promise.all([
      this.odsService.getOds().toPromise(),
      this.cicloService.getCiclos().toPromise(),
      this.profesorService.getProfesores().toPromise(),
      this.entidadService.getEntidadesExternas().toPromise()
    ]).then(([ods, ciclos, profesores, entidades]) => {
      this.odsDisponibles = Array.isArray(ods)
        ? ods.map(o => ({
          ...o,
          metas: this.ordenarMetas(o.metas)
        }))
        : [];
      this.ciclosDisponibles = Array.isArray(ciclos) ? ciclos : [];
      this.profesoresDisponibles = Array.isArray(profesores) ? profesores : [];
      this.entidadesDisponibles = Array.isArray(entidades) ? entidades : [];

      this.catálogosCargados = true;

      if (this.idIniciativa) {
        this.cargarIniciativa();
      }

      this.route.paramMap.subscribe(params => {
        const id = params.get('id');
        if (id) {
          this.idIniciativa = +id;
          this.cargarIniciativa();
        }
      });
    }).catch(error => {
      console.error('Error al cargar datos iniciales:', error);
    });
  }


  mostrarPopupEntidades: boolean = false;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['idIniciativa']) {
      if (this.idIniciativa) {
        if (this.catálogosCargados) {
          this.cargarIniciativa();
        }
      } else {
        this.resetFormulario();
      }
    }

    if (changes['snapshot'] && this.snapshot) {
      this.cargarDesdeSnapshot(this.snapshot);
    }
  }

  resetFormulario(): void {
    this.iniciativa = {
      id: 0,
      nombre: '',
      descripcion: '',
      curso: '',
      fecha_Inicio: null as any,
      fecha_Fin: null as any,
      tipo_Iniciativa: '',
      innovadora: false,
      horas: 1,
      dimensiones: [],
      difusionLista: [],
      entidadesLista: [],
      odsLista: [],
      profesoresLista: [],
      ciclosLista: []
    };

    this.metasSeleccionadasPorOds = {};
    this.modulosSeleccionados = [];
    this.redesSeleccionadas = [];
    this.fechaInicioStr = this.fechaInicioStr ?? '';
    this.fechaFinStr = this.fechaFinStr ?? '';
    this.cursoInput = this.cursoInput ?? '';
    this.mostrarMetas = {};
    this.mostrarModulos = {};
    this.expandirMetas = {};
    this.activeDropdown = null;
  }

  cargarIniciativa(): void {
    if (!this.idIniciativa) return;

    this.iniciativaService.getIniciativaPorId(this.idIniciativa).subscribe({
      next: iniciativa => {
        this.iniciativa = iniciativa;
        this.fechaInicioStr = this.formatearFecha(iniciativa.fecha_Inicio);
        this.fechaFinStr = this.formatearFecha(iniciativa.fecha_Fin);

        this.metasSeleccionadasPorOds = {};
        iniciativa.odsLista.forEach(odsSel => {
          this.metasSeleccionadasPorOds[odsSel.idOds] = odsSel.metas;
        });

        this.modulosSeleccionados = [];
        iniciativa.ciclosLista.forEach(cicloSel => {
          cicloSel.modulos.forEach(modSel => {
            this.modulosSeleccionados.push(modSel);
          });
        });

        this.iniciativa.odsLista = this.odsDisponibles
          .filter(ods => this.metasSeleccionadasPorOds[ods.idOds]?.length > 0)
          .map(ods => ({
            ...ods,
            metas: this.ordenarMetas(ods.metas)
          }));

        this.iniciativa.ciclosLista = this.ciclosDisponibles
          .filter(ciclo => ciclo.modulos.some(modulo =>
            this.modulosSeleccionados.some(m => m.idModulo === modulo.idModulo)
          ))
          .map(ciclo => ({
            ...ciclo,
            modulos: ciclo.modulos.map(modulo => ({ ...modulo }))
          }));

        this.iniciativa.profesoresLista = iniciativa.profesoresLista.map(profSel => {
          return this.profesoresDisponibles.find(p => p.idProfesor === profSel.idProfesor) ?? profSel;
        });

        this.iniciativa.entidadesLista = iniciativa.entidadesLista.map(entSel => {
          return this.entidadesDisponibles.find(e => e.identidad === entSel.identidad) ?? entSel;
        });

        this.redesSeleccionadas = iniciativa.difusionLista.map((dif, index) => {
          const redConocida = this.redesDisponibles.find(r => r.nombre === dif.tipo);
          return redConocida
            ? { id: redConocida.id, idDifusion: dif.iddifusion, nombre: redConocida.nombre, icono: redConocida.icono, enlace: dif.enlace }
            : { id: 'otro-' + index, idDifusion: dif.iddifusion, nombre: dif.tipo, icono: 'fa-solid fa-globe', enlace: dif.enlace };
        });
      },
      error: err => console.error('Error al cargar iniciativa:', err)
    });
  }



  formatearFecha(fecha: any): string {
    if (!fecha) return "";
    const d = new Date(fecha);
    return isNaN(d.getTime()) ? "" : d.toISOString().split("T")[0];
  }


  guardarIniciativa(): void {
    const error = this.validarIniciativa();
    if (error) return this.mostrarAlerta(error);

    this.iniciativa.fecha_Inicio = new Date(`${this.fechaInicioStr}T00:00:00`);
    this.iniciativa.fecha_Fin = this.fechaFinStr ? new Date(`${this.fechaFinStr}T00:00:00`) : null;
    this.iniciativa.curso = this.calcularCursoAcademico();

    this.iniciativa.odsLista = this.iniciativa.odsLista.map(ods => ({
      ...ods,
      metas: this.metasSeleccionadasPorOds[ods.idOds] ?? []
    })).filter(ods => ods.metas.length > 0);


    this.iniciativa.ciclosLista = this.ciclosDisponibles
      .filter(ciclo => this.iniciativa.ciclosLista.some(c => c.idCiclo === ciclo.idCiclo))
      .map(ciclo => ({
        ...ciclo,
        modulos: ciclo.modulos.filter(mod => this.modulosSeleccionados.some(m => m.idModulo === mod.idModulo))
      }))
      .filter(ciclo => ciclo.modulos.length > 0);

    this.iniciativa.difusionLista = this.redesSeleccionadas.map(r => ({
      iddifusion: r.idDifusion ?? 0,
      tipo: r.nombre,
      enlace: r.enlace

    }));

    const callback = () => this.router.navigate(['/iniciativas']);
    const request = this.idIniciativa
      ? this.iniciativaService.modificarIniciativa(this.iniciativa)
      : this.iniciativaService.crearIniciativa(this.iniciativa);
      console.log('Objeto que se envía:', JSON.stringify(this.iniciativa, null, 2));

    request.subscribe({
      next: () => {
        this.resetFormulario();
        this.cerrar.emit('actualizar');
      },
      error: err => console.error(err)
    });
  }

  validarIniciativa(): string | null {
    if (!(this.iniciativa.nombre?.trim())) return "El nombre es obligatorio.";
    if (!(this.iniciativa.descripcion?.trim())) return "La descripción es obligatoria.";
    if (!this.fechaInicioStr.match(/\d{4}-\d{2}-\d{2}/)) return "Fecha de inicio no válida.";
    if (this.fechaFinStr && !this.fechaFinStr.match(/\d{4}-\d{2}-\d{2}/)) return "Fecha de fin no válida.";

    const inicio = new Date(`${this.fechaInicioStr}T00:00:00`);
    const fin = this.fechaFinStr ? new Date(`${this.fechaFinStr}T00:00:00`) : null;

    if (isNaN(inicio.getTime())) return "Fecha de inicio inválida.";
    if (fin && isNaN(fin.getTime())) return "Fecha de fin inválida.";
    if (fin && fin < inicio) return "La fecha de fin no puede ser anterior a la de inicio.";
    if (!this.iniciativa.tipo_Iniciativa || this.iniciativa.tipo_Iniciativa === "Seleccione una opción")
      return "Seleccione un tipo de iniciativa válido.";
    if (this.iniciativa.horas === null || this.iniciativa.horas === undefined || this.iniciativa.horas < 0)
      return "Las horas deben ser un número igual o mayor a 0.";

    if (this.cursoInput) {
      const partes = this.cursoInput.split('-');
      const anioInicio = parseInt(partes[0], 10);
      const anioFin = parseInt(partes[1], 10);
    
      if (
        isNaN(anioInicio) ||
        isNaN(anioFin) ||
        partes[0].length !== 4 ||
        partes[1].length !== 4 ||
        anioFin !== anioInicio + 1
      ) {
        return "El formato del curso escolar es inválido. Ejemplo válido: 2023-2024.";
      }
    }
    


    const odsConMetas = this.iniciativa.odsLista.filter(ods =>
      (this.metasSeleccionadasPorOds[ods.idOds]?.length ?? 0) > 0
    );

    if (odsConMetas.length === 0) return "Seleccione al menos un ODS con metas asociadas.";

    const ciclosConModulos = this.iniciativa.ciclosLista.filter(c =>
      c.modulos.some(mod => this.modulosSeleccionados.some(m => m.idModulo === mod.idModulo))
    );
    if (ciclosConModulos.length === 0) return "Seleccione al menos un Ciclo con módulos.";

    if (this.iniciativa.profesoresLista.length === 0)
      return "Seleccione al menos un profesor.";

    return null;
  }


  calcularCursoAcademico(): string {
    if (this.cursoInput) {
      const partes = this.cursoInput.split('-');
      if (partes.length === 2) {
        const anioInicio = parseInt(partes[0], 10);
        const anioFin = parseInt(partes[1], 10);

        if (!isNaN(anioInicio) && !isNaN(anioFin) && anioFin === anioInicio + 1) {
          return `${anioInicio}-${anioFin}`;
        }
      }
      return '';
    }

    if (!this.fechaInicioStr) return "";

    const fechaInicio = new Date(`${this.fechaInicioStr}T00:00:00`);
    if (isNaN(fechaInicio.getTime())) return "";

    const anioInicio = fechaInicio.getMonth() >= 8
      ? fechaInicio.getFullYear()
      : fechaInicio.getFullYear() - 1;

    const anioFin = anioInicio + 1;

    return `${anioInicio}-${anioFin}`;
  }
  private alertaTimeout: any;
  private catálogosCargados = false;

  mostrarAlerta(error: string): void {
    this.errorMensaje = error;
    this.mostrarError = true;
    this.mostrarErrorExterno.emit(error);

    clearTimeout(this.alertaTimeout);
    this.alertaTimeout = setTimeout(() => {
      this.mostrarError = false;
    }, 5000);

    setTimeout(() => {
      const focusMap: { [clave: string]: string } = {
        'nombre': 'nombre',
        'descripción': 'descripcion',
        'inicio': 'fechaInicio',
        'fin': 'fechaFin',
        'horas': 'horas',
        'curso': 'curso',
        'tipo': 'tipo',
        'ODS': 'ods-dropdown',
        'Ciclo': 'ciclos-dropdown',
        'profesor': 'profesores-dropdown',
        'entidad externa': 'entidades-dropdown'
      };

      for (const palabra in focusMap) {
        if (error.toLowerCase().includes(palabra.toLowerCase())) {
          const elem = document.getElementById(focusMap[palabra]);
          if (elem) {
            (elem as HTMLElement).focus?.();
            (elem as HTMLElement).click?.();
          }
          break;
        }
      }
    }, 100);
  }


  cerrarAlerta(): void {
    this.mostrarError = false;
  }

  toggleSeleccionOds(ods: Ods): void {
    const index = this.iniciativa.odsLista.findIndex(o => o.idOds === ods.idOds);
    if (index === -1) {
      const odsCompleto = this.odsDisponibles.find(o => o.idOds === ods.idOds);
      if (odsCompleto) {
        const odsOrdenado = {
          ...odsCompleto,
          metas: this.ordenarMetas(odsCompleto.metas)
        };
        this.iniciativa.odsLista.push(odsOrdenado);
      }
    } else {
      this.iniciativa.odsLista.splice(index, 1);
      delete this.metasSeleccionadasPorOds[ods.idOds];
    }
  }


  toggleMostrarMetas(odsId: number): void {
    this.mostrarMetas[odsId] = !this.mostrarMetas[odsId];
  }

  toggleExpandirMetas(odsId: number): void {
    this.expandirMetas[odsId] = !this.expandirMetas[odsId];
  }

  obtenerMetasVisible(ods: Ods): Meta[] {
    return this.expandirMetas[ods.idOds] ? ods.metas : ods.metas.slice(0, 4);
  }

  toggleSeleccionMeta(meta: Meta, idOds: number): void {
    if (!this.metasSeleccionadasPorOds[idOds]) {
      this.metasSeleccionadasPorOds[idOds] = [];
    }

    const lista = this.metasSeleccionadasPorOds[idOds];
    const i = lista.findIndex(m => m.idMeta === meta.idMeta);
    i === -1 ? lista.push(meta) : lista.splice(i, 1);
  }


  toggleSeleccionCiclo(ciclo: Ciclo): void {
    const i = this.iniciativa.ciclosLista.findIndex(c => c.idCiclo === ciclo.idCiclo);
    if (i === -1) {
      this.iniciativa.ciclosLista.push(ciclo);
    } else {
      this.iniciativa.ciclosLista.splice(i, 1);
      this.modulosSeleccionados = this.modulosSeleccionados.filter(m => !ciclo.modulos.some(cm => cm.idModulo === m.idModulo));
    }
  }

  toggleMostrarModulos(cicloId: number): void {
    this.mostrarModulos[cicloId] = !this.mostrarModulos[cicloId];
  }

  toggleSeleccionModulo(modulo: Modulo): void {
    const i = this.modulosSeleccionados.findIndex(m => m.idModulo === modulo.idModulo);
    i === -1 ? this.modulosSeleccionados.push(modulo) : this.modulosSeleccionados.splice(i, 1);
  }

  toggleSeleccionProfesor(profesor: Profesor): void {
    const i = this.iniciativa.profesoresLista.findIndex(p => p.idProfesor === profesor.idProfesor);
    i === -1 ? this.iniciativa.profesoresLista.push(profesor) : this.iniciativa.profesoresLista.splice(i, 1);
  }

  toggleSeleccionEntidad(entidad: EntidadExterna): void {
    const i = this.iniciativa.entidadesLista.findIndex(e => e.identidad === entidad.identidad);
    i === -1 ? this.iniciativa.entidadesLista.push(entidad) : this.iniciativa.entidadesLista.splice(i, 1);
  }
  setInnovadora(valor: boolean): void {
    this.iniciativa.innovadora = valor;
  }

  toggleSeleccionRed(red: { id: string; nombre: string; icono: string }): void {
    if (red.id === 'otro') {
      const nuevoId = 'otro-' + Date.now();
      this.redesSeleccionadas.push({ id: nuevoId, nombre: '', icono: 'fa-solid fa-globe', enlace: '' });
    } else {
      const index = this.redesSeleccionadas.findIndex(r => r.id === red.id);
      index === -1
        ? this.redesSeleccionadas.push({ ...red, enlace: '' })
        : this.redesSeleccionadas.splice(index, 1);
    }
  }

  actualizarEnlaceRed(id: string, enlace: string): void {
    const red = this.redesSeleccionadas.find(r => r.id === id);
    if (red) red.enlace = enlace;
  }

  actualizarNombreRed(id: string, nombre: string): void {
    const red = this.redesSeleccionadas.find(r => r.id === id);
    if (red) red.nombre = nombre;
  }
  toggleDropdown(nombre: string): void {
    this.activeDropdown = this.activeDropdown === nombre ? null : nombre;
  }


  eliminarRed(id: string): void {
    this.redesSeleccionadas = this.redesSeleccionadas.filter(r => r.id !== id);
  }

  estaSeleccionada(red: { id: string }): boolean {
    return this.redesSeleccionadas.some(r => r.id === red.id);
  }

  alternarInnovadora(): void {
    this.iniciativa.innovadora = !this.iniciativa.innovadora;
  }

  volverALista(): void {
    this.cerrar.emit();
  }


  estaModuloSeleccionado(modulo: Modulo): boolean {
    return this.modulosSeleccionados.some(m => m.idModulo === modulo.idModulo);
  }

  trackByMeta(index: number, meta: Meta): string {
    return meta.idMeta;
  }

  trackByModulo(index: number, modulo: Modulo): number {
    return modulo.idModulo;
  }

  odsSeleccionado(ods: Ods): boolean {
    return this.iniciativa.odsLista.some(o => o.idOds === ods.idOds);
  }

  metaSeleccionada(meta: Meta, idOds: number): boolean {
    return this.metasSeleccionadasPorOds[idOds]?.some(m => m.idMeta === meta.idMeta) ?? false;
  }


  cicloSeleccionado(ciclo: Ciclo): boolean {
    return this.iniciativa.ciclosLista.some(c => c.idCiclo === ciclo.idCiclo);
  }

  moduloSeleccionado(modulo: Modulo): boolean {
    return this.modulosSeleccionados.some(m => m.idModulo === modulo.idModulo);
  }
  ordenarMetas(metas: Meta[]): Meta[] {
    return [...metas].sort((a, b) =>
      a.idMeta.toString().localeCompare(b.idMeta.toString(), undefined, { numeric: true, sensitivity: 'base' })
    );
  }




  formatearCurso(): void {
    this.cursoInput = this.cursoInput.replace(/[^\d-]/g, '');
  
    const match = this.cursoInput.match(/^(\d{4})-?(\d{0,4})/);
    if (match) {
      const inicio = match[1];
      const fin = match[2] ?? '';
      this.cursoInput = fin ? `${inicio}-${fin}` : inicio;
    }
  
    if (this.cursoInput.length > 9) {
      this.cursoInput = this.cursoInput.slice(0, 9);
    }
  }
  

  onKeyPressCurso(event: KeyboardEvent): void {
    const inputChar = event.key;
    if (!/[\d-]/.test(inputChar)) {
      event.preventDefault();
    }
  }
  

  cargarDesdeSnapshot(snapshot: FormSnapshot): void {
    this.iniciativa = { id: 0, ...snapshot.iniciativa } as Iniciativa;
    this.fechaInicioStr = snapshot.fechaInicioStr;
    this.fechaFinStr = snapshot.fechaFinStr;
    this.cursoInput = snapshot.cursoInput;
    this.metasSeleccionadasPorOds = structuredClone(snapshot.metasSeleccionadasPorOds);
    this.modulosSeleccionados = structuredClone(snapshot.modulosSeleccionados);
    this.redesSeleccionadas = structuredClone(snapshot.redesSeleccionadas);
  }


}


