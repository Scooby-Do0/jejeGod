import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionarCicloComponent } from './gestionar-ciclos.component';

describe('GestionarCiclosComponent', () => {
  let component: GestionarCicloComponent;
  let fixture: ComponentFixture<GestionarCicloComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionarCicloComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GestionarCicloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
