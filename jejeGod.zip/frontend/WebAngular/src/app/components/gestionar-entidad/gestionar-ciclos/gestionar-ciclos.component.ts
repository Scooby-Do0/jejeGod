import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Ciclo } from '../../../modelos/ciclo';
import { Modulo } from '../../../modelos/modulo';
import { CicloService } from '../../../services/ciclo.service';

@Component({
  selector: 'app-gestionar-ciclos',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './gestionar-ciclos.component.html',
  styleUrls: ['./gestionar-ciclos.component.scss']
})
export class GestionarCicloComponent implements OnInit {
  ciclos: Ciclo[] = [];
  ciclosFiltrados: Ciclo[] = [];
  busqueda: string = '';
  mensajeError: string = '';

  paginaActual: number = 1;
  ciclosPorPagina: number = 6;

  nuevoCicloNombre: string = '';
  cicloEditando: Ciclo | null = null;
  cicloExpandido: number | null = null;

  nuevoModuloNombre: { [idCiclo: number]: string } = {};
  moduloEditando: Modulo | null = null;

  cicloParaEliminar: Ciclo | null = null;
  moduloParaEliminar: { ciclo: Ciclo; modulo: Modulo } | null = null;

  cicloRemoviendo: number | null = null;
  moduloRemoviendo: number | null = null;

  @Output() cerrarPopup = new EventEmitter<void>();
  @Output() ciclosActualizados = new EventEmitter<Ciclo[]>();

  constructor(private cicloService: CicloService) {}

  ngOnInit(): void {
    this.cargarCiclos();
  }

  cargarCiclos(): void {
    this.cicloService.getCiclos().subscribe({
      next: data => {
        this.ciclos = data;
        this.filtrarCiclos();
      },
      error: err => console.error('Error cargando ciclos:', err)
    });
  }

  filtrarCiclos(): void {
    const term = this.busqueda.trim().toLowerCase();
    this.ciclosFiltrados = this.ciclos.filter(c =>
      c.nombreCiclo.toLowerCase().includes(term)
    );
    this.paginaActual = Math.min(this.paginaActual, this.paginasTotales || 1);
  }

  get paginasTotales(): number {
    return Math.ceil(this.ciclosFiltrados.length / this.ciclosPorPagina);
  }

  get paginasArray(): number[] {
    return Array.from({ length: this.paginasTotales }, (_, i) => i + 1);
  }

  ciclosPaginados(): Ciclo[] {
    const inicio = (this.paginaActual - 1) * this.ciclosPorPagina;
    return this.ciclosFiltrados.slice(inicio, inicio + this.ciclosPorPagina);
  }

  crearCiclo(): void {
    this.mensajeError = '';

    const nombre = this.nuevoCicloNombre.trim();
    if (!nombre) {
      this.mensajeError = 'El nombre del ciclo es obligatorio';
      return;
    }

    if (this.ciclos.some(c => c.nombreCiclo.trim().toLowerCase() === nombre.toLowerCase())) {
      this.mensajeError = 'Ya existe un ciclo con ese nombre';
      return;
    }

    const nuevo: Ciclo = {
      idCiclo: 0,
      nombreCiclo: nombre,
      modulos: []
    };

    this.cicloService.postCiclo(nuevo).subscribe({
      next: () => {
        this.nuevoCicloNombre = '';
        this.cargarCiclos();
      },
      error: err => console.error('Error creando ciclo:', err)
    });
  }

  comenzarEdicion(ciclo: Ciclo): void {
    this.cicloEditando = { ...ciclo, modulos: [...ciclo.modulos] };
  }

  cancelarEdicion(): void {
    this.cicloEditando = null;
  }

  guardarEdicion(): void {
    if (!this.cicloEditando) return;

    const nombre = this.cicloEditando.nombreCiclo.trim();
    if (!nombre) {
      this.mensajeError = 'El nombre del ciclo es obligatorio';
      return;
    }

    if (this.ciclos.some(c => c.idCiclo !== this.cicloEditando?.idCiclo && c.nombreCiclo.trim().toLowerCase() === nombre.toLowerCase())) {
      this.mensajeError = 'Ya existe otro ciclo con ese nombre';
      return;
    }

    this.cicloEditando.nombreCiclo = nombre;

    this.cicloService.putCiclo(this.cicloEditando).subscribe({
      next: () => {
        this.cicloEditando = null;
        this.cargarCiclos();
      },
      error: err => console.error('Error actualizando ciclo:', err)
    });
  }

  toggleExpandirModulos(id: number): void {
    this.cicloExpandido = this.cicloExpandido === id ? null : id;
    this.moduloEditando = null;
  }

  crearModulo(ciclo: Ciclo): void {
    this.mensajeError = '';

    const nombre = (this.nuevoModuloNombre[ciclo.idCiclo] || '').trim();
    if (!nombre) {
      this.mensajeError = 'El nombre del módulo es obligatorio';
      return;
    }

    if (ciclo.modulos.some(m => m.nombre.trim().toLowerCase() === nombre.toLowerCase())) {
      this.mensajeError = 'Ya existe un módulo con ese nombre en este ciclo';
      return;
    }

    const idMasAlto = ciclo.modulos.length > 0
      ? Math.max(...ciclo.modulos.map(m => m.idModulo))
      : 0;

    const nuevoModulo: Modulo = {
      idModulo: idMasAlto + 1,
      nombre: nombre
    };

    this.cicloService.postModulo(ciclo.idCiclo, nuevoModulo).subscribe({
      next: () => {
        this.nuevoModuloNombre[ciclo.idCiclo] = '';
        this.cargarCiclos();
        this.cicloExpandido = ciclo.idCiclo;
      },
      error: err => console.error('Error creando módulo:', err)
    });
  }

  empezarEditarModulo(modulo: Modulo): void {
    this.moduloEditando = { ...modulo };
  }

  cancelarEditarModulo(): void {
    this.moduloEditando = null;
  }

  guardarModulo(ciclo: Ciclo): void {
    if (!this.moduloEditando) return;

    const nombre = this.moduloEditando.nombre.trim();
    if (!nombre) {
      this.mensajeError = 'El nombre del módulo es obligatorio';
      return;
    }

    if (ciclo.modulos.some(m => m.idModulo !== this.moduloEditando?.idModulo && m.nombre.trim().toLowerCase() === nombre.toLowerCase())) {
      this.mensajeError = 'Ya existe otro módulo con ese nombre en este ciclo';
      return;
    }

    this.moduloEditando.nombre = nombre;

    this.cicloService.putModulo(ciclo.idCiclo, this.moduloEditando).subscribe({
      next: () => {
        this.moduloEditando = null;
        this.cargarCiclos();
        this.cicloExpandido = ciclo.idCiclo;
      },
      error: err => console.error('Error guardando módulo:', err)
    });
  }

  confirmarEliminarCiclo(ciclo: Ciclo): void {
    this.cicloParaEliminar = ciclo;
  }

  cancelarEliminarCiclo(): void {
    this.cicloParaEliminar = null;
  }

  eliminarCicloConfirmado(): void {
    if (!this.cicloParaEliminar) return;

    const id = this.cicloParaEliminar.idCiclo;
    this.cicloRemoviendo = id;

    setTimeout(() => {
      this.cicloService.patchCiclo(id).subscribe({
        next: () => {
          this.cicloRemoviendo = null;
          this.cicloParaEliminar = null;
          this.cargarCiclos();
        },
        error: err => {
          console.error('Error eliminando ciclo:', err);
          this.cicloRemoviendo = null;
        }
      });
    }, 300);
  }

  confirmarEliminarModulo(ciclo: Ciclo, modulo: Modulo): void {
    this.moduloParaEliminar = { ciclo, modulo };
  }

  cancelarEliminarModulo(): void {
    this.moduloParaEliminar = null;
  }

  eliminarModuloConfirmado(): void {
    if (!this.moduloParaEliminar) return;

    const { ciclo, modulo } = this.moduloParaEliminar;
    this.moduloRemoviendo = modulo.idModulo;

    setTimeout(() => {
      this.cicloService.patchModulo(ciclo.idCiclo, modulo.idModulo).subscribe({
        next: () => {
          this.moduloRemoviendo = null;
          this.moduloParaEliminar = null;
          this.cargarCiclos();
        },
        error: err => {
          console.error('Error eliminando módulo:', err);
          this.moduloRemoviendo = null;
        }
      });
    }, 300);
  }

  cerrar(): void {
    this.cerrarPopup.emit();
    this.ciclosActualizados.emit(this.ciclos);
  }

  trackByCiclo(index: number, item: Ciclo): number {
    return item.idCiclo;
  }

  trackByModulo(index: number, item: Modulo): number {
    return item.idModulo;
  }
}
