import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EntidadExterna } from '../../../modelos/entidad-externa';
import { EntidadExternaService } from '../../../services/entidad-externa.service';

@Component({
  selector: 'app-gestionar-entidades',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './gestionar-entidades-externas.component.html',
  styleUrls: ['./gestionar-entidades-externas.component.scss']
})
export class GestionarEntidadesComponent implements OnInit {
  entidades: EntidadExterna[] = [];
  entidadesFiltradas: EntidadExterna[] = [];
  entidadEditando: EntidadExterna | null = null;
  entidadParaEliminar: EntidadExterna | null = null;

  nuevoNombre: string = '';
  busqueda: string = '';
  mensajeError: string = '';

  paginaActual: number = 1;
  entidadesPorPagina: number = 10;

  @Output() onCerrar = new EventEmitter<void>();
  @Output() onActualizarLista = new EventEmitter<EntidadExterna[]>();

  constructor(private entidadService: EntidadExternaService) {}

  ngOnInit(): void {
    this.cargarEntidades();
  }

  cargarEntidades(): void {
    this.entidadService.getEntidadesExternas().subscribe({
      next: (res) => {
        this.entidades = res;
        this.entidadesFiltradas = [...res];
        this.paginaActual = 1;
      },
      error: (err) => console.error('Error cargando entidades externas', err),
    });
  }

  filtrarEntidades(): void {
    const filtro = this.busqueda.toLowerCase().trim();
    this.entidadesFiltradas = this.entidades.filter(e =>
      e.nombre.toLowerCase().includes(filtro)
    );
    this.paginaActual = 1;
  }

  entidadesPaginadas(): EntidadExterna[] {
    const start = (this.paginaActual - 1) * this.entidadesPorPagina;
    const end = start + this.entidadesPorPagina;
    return this.entidadesFiltradas.slice(start, end);
  }

  get paginasTotales(): number {
    return Math.ceil(this.entidadesFiltradas.length / this.entidadesPorPagina);
  }

  get paginasArray(): number[] {
    return Array.from({ length: this.paginasTotales }, (_, i) => i + 1);
  }

  comenzarEdicion(entidad: EntidadExterna): void {
    this.entidadEditando = { ...entidad };
    this.mensajeError = '';
  }

  cancelarEdicion(): void {
    this.entidadEditando = null;
    this.mensajeError = '';
  }

  guardarEdicion(): void {
    if (!this.entidadEditando || this.entidadEditando.identidad === undefined) return;

    const nuevoNombre = this.entidadEditando.nombre.trim().toUpperCase();
    const yaExiste = this.entidades.some(e =>
      e.identidad !== this.entidadEditando!.identidad &&
      e.nombre.trim().toUpperCase() === nuevoNombre
    );

    if (yaExiste) {
      this.mensajeError = 'Ya existe una entidad con ese nombre.';
      return;
    }

    this.entidadService.putEntidadExterna(this.entidadEditando).subscribe({
      next: () => {
        this.cargarEntidades();
        this.entidadEditando = null;
        this.mensajeError = '';
      },
      error: (err) => console.error('Error al guardar edición:', err),
    });
  }

  crearEntidad(): void {
    const nombre = this.nuevoNombre.trim();
    if (!nombre) return;

    const nombreUpper = nombre.toUpperCase();
    const yaExiste = this.entidades.some(e =>
      e.nombre.trim().toUpperCase() === nombreUpper
    );

    if (yaExiste) {
      this.mensajeError = 'Ya existe una entidad con ese nombre.';
      return;
    }

    const nueva: EntidadExterna = {
      identidad: 0,
      nombre: nombre
    };

    this.entidadService.postEntidadExterna(nueva).subscribe({
      next: () => {
        this.nuevoNombre = '';
        this.mensajeError = '';
        this.cargarEntidades();
      },
      error: (err) => console.error('Error al crear entidad', err),
    });
  }

  confirmarEliminar(entidad: EntidadExterna): void {
    this.entidadParaEliminar = entidad;
  }

  cancelarEliminar(): void {
    this.entidadParaEliminar = null;
  }

  eliminarEntidadConfirmada(): void {
    if (!this.entidadParaEliminar) return;

    const id = this.entidadParaEliminar.identidad;
    this.entidadService.deleteEntidadExterna(id).subscribe({
      next: () => {
        this.entidadParaEliminar = null;
        this.cargarEntidades();
      },
      error: (err) => console.error('Error al eliminar entidad', err),
    });
  }

  cerrar(): void {
    this.onCerrar.emit();
    this.onActualizarLista.emit(this.entidades);
  }
}
