import { Component, EventEmitter, OnInit, Output, Renderer2 } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { OdsService } from '../../../services/ods.service';
import { Ods } from '../../../modelos/ods';
import { Meta } from '../../../modelos/meta';

@Component({
  selector: 'app-gestionar-ods',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './gestionar-ods.component.html',
  styleUrls: ['./gestionar-ods.component.scss']
})
export class GestionarOdsComponent implements OnInit {
  ods: Ods[] = [];
  odsFiltrados: Ods[] = [];

  busqueda = '';
  mensajeError = '';

  paginaActual = 1;
  odsPorPagina = 8;

  nuevoOdsId?: number;
  nuevoOdsNombre = '';
  archivoNuevo?: File;

  odsEditando: Ods | null = null;
  archivoEdicion?: File;

  odsExpandido: number | null = null;
  nuevaMetaId: { [idOds: number]: string } = {};
  nuevaMetaDesc: { [idOds: number]: string } = {};
  metaEditando: Meta | null = null;

  odsParaEliminar: Ods | null = null;
  metaParaEliminar: { ods: Ods, meta: Meta } | null = null;

  odsRemoviendo: number | null = null;
  metaRemoviendo: string | null = null; // Cambiado a string

  @Output() cerrarPopup = new EventEmitter<void>();
  @Output() odsActualizados = new EventEmitter<Ods[]>();

  constructor(
    private odsService: OdsService,
    private http: HttpClient,
    private renderer: Renderer2
  ) { }

  ngOnInit(): void {
    this.cargarOds();
  }

  cargarOds(): void {
    this.odsService.getOds().subscribe({
      next: lista => {
        this.ods = lista;
        this.filtrarOds();
      },
      error: err => console.error('Error cargando ODS', err)
    });
  }

  filtrarOds(): void {
    const f = this.normalizar(this.busqueda);
    this.odsFiltrados = this.ods.filter(o =>
      this.normalizar(o.nombre).includes(f) || o.idOds.toString().includes(f)
    );
    this.paginaActual = Math.min(this.paginaActual, this.paginasTotales || 1);
  }

  odsPaginados(): Ods[] {
    const inicio = (this.paginaActual - 1) * this.odsPorPagina;
    return this.odsFiltrados.slice(inicio, inicio + this.odsPorPagina);
  }

  get paginasTotales(): number {
    return Math.ceil(this.odsFiltrados.length / this.odsPorPagina);
  }

  get paginasArray(): number[] {
    return Array.from({ length: this.paginasTotales }, (_, i) => i + 1);
  }

  crearOds(): void {
    this.mensajeError = '';
    if (!this.nuevoOdsId || !this.nuevoOdsNombre.trim()) {
      this.mensajeError = 'ID y nombre son obligatorios';
      return;
    }

    const idExiste = this.ods.some(o => o.idOds === this.nuevoOdsId);
    if (idExiste) {
      this.mensajeError = 'Ese ID ya existe';
      return;
    }

    const nombreNormalizado = this.normalizar(this.nuevoOdsNombre);
    const nombreExiste = this.ods.some(o => this.normalizar(o.nombre) === nombreNormalizado);
    if (nombreExiste) {
      this.mensajeError = 'Ese nombre ya existe';
      return;
    }

    const nuevo: Ods = {
      idOds: this.nuevoOdsId,
      nombre: this.nuevoOdsNombre.trim(),
      descripcion: '',
      metas: []
    };

    this.odsService.postOds(nuevo).subscribe({
      next: () => {
        if (this.archivoNuevo) this.subirIcono(nuevo.idOds, this.archivoNuevo);
        this.resetFormularioNuevo();
        this.cargarOds();
      },
      error: err => console.error('Error creando ODS', err)
    });
  }

  comenzarEdicion(o: Ods): void {
    this.odsEditando = { ...o, metas: [...o.metas] };
    this.archivoEdicion = undefined;
    this.mensajeError = '';
  }

  cancelarEdicion(): void {
    this.odsEditando = null;
    this.archivoEdicion = undefined;
    this.mensajeError = '';
  }

  guardarEdicion(): void {
    if (!this.odsEditando) return;

    const nombreNormalizado = this.normalizar(this.odsEditando.nombre);
    const nombreExiste = this.ods.some(o =>
      o.idOds !== this.odsEditando!.idOds &&
      this.normalizar(o.nombre) === nombreNormalizado
    );

    if (nombreExiste) {
      this.mensajeError = 'Ya existe un ODS con ese nombre';
      return;
    }

    this.odsService.putOds(this.odsEditando).subscribe({
      next: () => {
        if (this.archivoEdicion) this.subirIcono(this.odsEditando!.idOds, this.archivoEdicion);
        this.odsEditando = null;
        this.cargarOds();
      },
      error: err => console.error('Error guardando ODS', err)
    });
  }

  confirmarEliminar(ods: Ods): void {
    this.odsParaEliminar = ods;
  }

  cancelarEliminar(): void {
    this.odsParaEliminar = null;
  }

  eliminarOdsConfirmado(): void {
    if (!this.odsParaEliminar) return;
    const id = this.odsParaEliminar.idOds;
    this.odsRemoviendo = id;

    setTimeout(() => {
      this.odsService.deleteOds(id).subscribe({
        next: () => {
          this.odsParaEliminar = null;
          this.odsRemoviendo = null;
          this.cargarOds();
        },
        error: err => {
          console.error('Error eliminando ODS', err);
          this.odsRemoviendo = null;
        }
      });
    }, 300);
  }

  toggleExpandirMetas(id: number): void {
    this.odsExpandido = this.odsExpandido === id ? null : id;
    this.metaEditando = null;
  }

  crearMeta(ods: Ods): void {
    this.mensajeError = '';
    const id = (this.nuevaMetaId[ods.idOds] || '').trim();
    const desc = (this.nuevaMetaDesc[ods.idOds] || '').trim();

    if (!id || id.length > 4 || !desc) {
      this.mensajeError = 'ID (máx 4 caracteres) y descripción son obligatorios';
      return;
    }

    const existe = ods.metas.some(m => m.idMeta === id);
    if (existe) {
      this.mensajeError = 'Ya existe una meta con ese ID';
      return;
    }

    const nueva: Meta = { idMeta: id, descripcion: desc };
    this.odsService.postMeta(ods.idOds, nueva).subscribe({
      next: () => {
        this.nuevaMetaId[ods.idOds] = '';
        this.nuevaMetaDesc[ods.idOds] = '';
        this.cargarOds();
        this.odsExpandido = ods.idOds;
      },
      error: err => {
        console.error('Error creando meta', err);
        this.mensajeError = 'Error al crear la meta';
      }
    });
  }

  empezarEditarMeta(meta: Meta): void {
    this.metaEditando = { ...meta };
  }

  cancelarEditarMeta(): void {
    this.metaEditando = null;
  }

  guardarMeta(ods: Ods): void {
    if (!this.metaEditando) return;

    const nuevaDesc = this.metaEditando.descripcion.trim();
    if (!nuevaDesc) {
      this.mensajeError = 'La descripción no puede estar vacía';
      return;
    }

    this.odsService.putMeta(ods.idOds, this.metaEditando).subscribe({
      next: () => {
        this.metaEditando = null;
        this.cargarOds();
        this.odsExpandido = ods.idOds;
      },
      error: err => console.error('Error guardando meta', err)
    });
  }

  confirmarEliminarMeta(ods: Ods, meta: Meta): void {
    this.metaParaEliminar = { ods, meta };
  }

  cancelarEliminarMeta(): void {
    this.metaParaEliminar = null;
  }

  eliminarMetaConfirmado(): void {
    if (!this.metaParaEliminar) return;

    const { ods, meta } = this.metaParaEliminar;
    this.metaRemoviendo = meta.idMeta;

    setTimeout(() => {
      this.odsService.deleteMeta(ods.idOds, meta.idMeta).subscribe({
        next: () => {
          this.metaRemoviendo = null;
          this.metaParaEliminar = null;
          this.cargarOds();
          this.odsExpandido = ods.idOds;
        },
        error: err => {
          console.error('Error eliminando meta', err);
          this.metaRemoviendo = null;
        }
      });
    }, 300);
  }

  capturarArchivo(e: Event, enEdicion = false): void {
    const input = e.target as HTMLInputElement;
    const file = input?.files?.[0];
    if (!file) return;

    if (file.type !== 'image/png') {
      this.mensajeError = 'El archivo debe ser una imagen PNG';
      return;
    }

    enEdicion ? (this.archivoEdicion = file) : (this.archivoNuevo = file);
  }

  subirIcono(id: number, file: File): void {
    const formData = new FormData();
    formData.append('file', file);
    this.http.post(`/Entidades/ods/upload/${id}`, formData).subscribe({
      error: err => console.warn('Advertencia: el ícono no se subió', err)
    });
  }

  resetFormularioNuevo(): void {
    this.nuevoOdsId = undefined;
    this.nuevoOdsNombre = '';
    this.archivoNuevo = undefined;
  }

  normalizar(txt: string): string {
    return txt.trim().toUpperCase().replace(/\s+/g, ' ');
  }

  trackByOds(index: number, item: Ods): number {
    return item.idOds;
  }

  trackByMeta(index: number, item: Meta): string {
    return item.idMeta;
  }

  onCardClick(event: MouseEvent, ods: Ods): void {
    const target = event.target as HTMLElement;
    if (target.closest('.ods-actions')) return;
    this.toggleExpandirMetas(ods.idOds);
  }

  cerrar(): void {
    this.cerrarPopup.emit();
    this.odsActualizados.emit(this.ods);
  }
}
