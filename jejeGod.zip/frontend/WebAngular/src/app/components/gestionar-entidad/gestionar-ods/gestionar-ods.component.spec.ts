import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionarOdsComponent } from './gestionar-ods.component';

describe('GestionarOdsComponent', () => {
  let component: GestionarOdsComponent;
  let fixture: ComponentFixture<GestionarOdsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionarOdsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GestionarOdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
