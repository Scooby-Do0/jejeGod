import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProfesorService } from '../../../services/profesor.service';
import { Profesor } from '../../../modelos/profesor';

@Component({
  selector: 'app-gestionar-profesores',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './gestionar-profesores.component.html',
  styleUrls: ['./gestionar-profesores.component.scss']
})
export class GestionarProfesoresComponent implements OnInit {
  profesores: Profesor[] = [];
  profesoresFiltrados: Profesor[] = [];
  profesorEditando: Profesor | null = null;
  profesorParaEliminar: Profesor | null = null;

  nuevoNombre: string = '';
  busqueda: string = '';
  mensajeError: string = '';

  paginaActual: number = 1;
  profesoresPorPagina: number = 10;

  @Output() onCerrar = new EventEmitter<void>();
  @Output() onActualizarLista = new EventEmitter<Profesor[]>();

  constructor(private profesorService: ProfesorService) {}

  ngOnInit(): void {
    this.cargarProfesores();
  }

  cargarProfesores(): void {
    this.profesorService.getProfesores().subscribe({
      next: (res) => {
        this.profesores = res;
        this.profesoresFiltrados = [...res];
        this.paginaActual = 1;
      },
      error: (err) => console.error('Error cargando profesores', err),
    });
  }

  filtrarProfesores(): void {
    const filtro = this.busqueda.toLowerCase().trim();
    this.profesoresFiltrados = this.profesores.filter(p =>
      p.nombre.toLowerCase().includes(filtro)
    );
    this.paginaActual = 1;
  }

  profesoresPaginados(): Profesor[] {
    const start = (this.paginaActual - 1) * this.profesoresPorPagina;
    const end = start + this.profesoresPorPagina;
    return this.profesoresFiltrados.slice(start, end);
  }

  get paginasTotales(): number {
    return Math.ceil(this.profesoresFiltrados.length / this.profesoresPorPagina);
  }

  get paginasArray(): number[] {
    return Array.from({ length: this.paginasTotales }, (_, i) => i + 1);
  }

  comenzarEdicion(profesor: Profesor): void {
    this.profesorEditando = { ...profesor };
    this.mensajeError = '';
  }

  cancelarEdicion(): void {
    this.profesorEditando = null;
    this.mensajeError = '';
  }

  guardarEdicion(): void {
    if (!this.profesorEditando || this.profesorEditando.idProfesor === undefined) return;

    const nuevoNombre = this.profesorEditando.nombre.trim().toUpperCase();
    const yaExiste = this.profesores.some(p =>
      p.idProfesor !== this.profesorEditando!.idProfesor &&
      p.nombre.trim().toUpperCase() === nuevoNombre
    );

    if (yaExiste) {
      this.mensajeError = 'Ya existe un profesor con ese nombre.';
      return;
    }

    this.profesorService.putProfesor(this.profesorEditando).subscribe({
      next: () => {
        this.cargarProfesores();
        this.profesorEditando = null;
        this.mensajeError = '';
      },
      error: (err) => console.error('Error al guardar edición:', err),
    });
  }

  crearProfesor(): void {
    const nombre = this.nuevoNombre.trim();
    if (!nombre) return;

    const nombreUpper = nombre.toUpperCase();
    const yaExiste = this.profesores.some(p =>
      p.nombre.trim().toUpperCase() === nombreUpper
    );

    if (yaExiste) {
      this.mensajeError = 'Ya existe un profesor con ese nombre.';
      return;
    }

    const nuevo: Profesor = {
      idProfesor: 0,
      nombre: nombre
    };

    this.profesorService.postProfesor(nuevo).subscribe({
      next: () => {
        this.nuevoNombre = '';
        this.mensajeError = '';
        this.cargarProfesores();
      },
      error: (err) => console.error('Error al crear profesor', err),
    });
  }

  confirmarEliminar(profesor: Profesor): void {
    this.profesorParaEliminar = profesor;
  }

  cancelarEliminar(): void {
    this.profesorParaEliminar = null;
  }

  eliminarProfesorConfirmado(): void {
    if (!this.profesorParaEliminar) return;

    const id = this.profesorParaEliminar.idProfesor;
    this.profesorService.patchProfesor(id).subscribe({
      next: () => {
        this.profesorParaEliminar = null;
        this.cargarProfesores();
      },
      error: (err) => console.error('Error al eliminar profesor', err),
    });
  }

  cerrar(): void {
    this.onCerrar.emit();
    this.onActualizarLista.emit(this.profesores);
  }
}
