import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador6Component } from './indicador6.component';

describe('Indicador6Component', () => {
  let component: Indicador6Component;
  let fixture: ComponentFixture<Indicador6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador6Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
