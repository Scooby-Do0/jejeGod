import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { EChartsOption } from 'echarts';
import { NgxEchartsDirective } from 'ngx-echarts';

interface IniciativaEntidades {
  iniciativa: string;
  entidadesExternas: string[];
}

@Component({
  selector: 'app-indicador6',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador6.component.html',
  styleUrls: ['./indicador6.component.scss']
})
export class Indicador6Component implements OnChanges {
  @Input() curso: string = '';
  @Input() showLabels: boolean = false;

  chartOptions: EChartsOption = {};
  cargando = true;

  constructor(private http: HttpClient) {}

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }

  cargarDatos(): void {
    this.cargando = true;

    this.http.get<{ indicador6: IniciativaEntidades[] }>(
      `https://localhost:7217/Indicadores/6/${this.curso}`
    ).subscribe({
      next: (response) => {
        const data = response.indicador6;

        const iniciativasSet = new Set<string>();
        const entidadesSet = new Set<string>();

        data.forEach(item => {
          iniciativasSet.add(item.iniciativa);
          item.entidadesExternas.forEach(entidad => entidadesSet.add(entidad));
        });

        const nodes = [
          ...Array.from(iniciativasSet).map(name => ({ name, itemStyle: { color: '#3dd5f3' } })),
          ...Array.from(entidadesSet).map(name => ({ name, itemStyle: { color: '#f55' } }))
        ];

        const links = data.flatMap(item =>
          item.entidadesExternas.map(entidad => ({
            source: item.iniciativa,
            target: entidad,
            value: 1
          }))
        );

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            backgroundColor: 'rgba(30,30,30,0.9)',
            borderColor: '#555',
            borderWidth: 1,
            textStyle: {
              color: '#fff',
              fontSize: 11
            },
            formatter: (params: any) => {
              if (params.data?.source && params.data?.target) {
                return `<strong>${params.data.source}</strong><br/>↳ <em>${params.data.target}</em>`;
              } else {
                return `<strong>${params.name}</strong>`;
              }
            }
          },
          series: [
            {
              type: 'sankey',
              orient: 'vertical',
              nodeWidth: 24,
              nodeGap: 16,
              emphasis: { focus: 'adjacency' },
              data: nodes,
              links: links,
              label: {
                show: this.showLabels,
                position: 'top',
                fontSize: 11,
                color: '#fff',
                overflow: 'truncate',
                formatter: (params: any) => {
                  const name = params.name || '';
                  return name.length > 22 ? name.slice(0, 22) + '…' : name;
                }
              },
              lineStyle: {
                color: 'source',
                curveness: 0.45,
                opacity: 0.6
              }
            }
          ]
        };

        this.cargando = false;
      },
      error: (err) => {
        console.error('Error al cargar indicador 6:', err);
        this.cargando = false;
      }
    });
  }
}
