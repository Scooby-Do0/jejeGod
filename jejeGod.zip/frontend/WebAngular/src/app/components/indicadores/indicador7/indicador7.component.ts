import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgxEchartsDirective } from 'ngx-echarts';
import type { EChartsOption } from 'echarts';

interface Difusion {
  tipo: string;
  enlace: string;
}

interface IniciativaDifusion {
  iniciativa: string;
  difusiones: Difusion[];
}

@Component({
  selector: 'app-indicador7',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador7.component.html',
  styleUrls: ['./indicador7.component.scss']
})
export class Indicador7Component implements OnChanges {
  @Input() curso: string = '';
  cargando = true;
  chartOptions: EChartsOption = {};

  private redStyles: Record<string, { icon: string; color: string }> = {
    instagram: { icon: 'instagram.png', color: '#E1306C' },
    twitter: { icon: 'twitter.png', color: '#000000' },
    linkedin: { icon: 'linkedin.png', color: '#0A66C2' },
    youtube: { icon: 'youtube.png', color: '#FF0000' },
    facebook: { icon: 'facebook.png', color: '#1877F2' },
    otro: { icon: 'web.png', color: '#888888' }
  };

  constructor(private http: HttpClient) {}

  ngOnChanges(): void {
    if (this.curso) this.cargarDatos();
  }

  private normalizarRed(nombre: string): string {
    const normalized = nombre.toLowerCase().trim();
    if (normalized.includes('twitter') || normalized === 'x') return 'twitter';
    if (normalized.includes('instagram')) return 'instagram';
    if (normalized.includes('linkedin')) return 'linkedin';
    if (normalized.includes('youtube')) return 'youtube';
    if (normalized.includes('facebook')) return 'facebook';
    return 'otro';
  }

  cargarDatos(): void {
    this.cargando = true;

    this.http.get<{ indicador7: IniciativaDifusion[] }>(`https://localhost:7217/Indicadores/7/${this.curso}`).subscribe({
      next: ({ indicador7 }) => {
        const contador: Record<string, number> = {};

        for (const item of indicador7) {
          const redesUsadas = new Set<string>();
          for (const dif of item.difusiones) {
            const red = this.normalizarRed(dif.tipo);
            redesUsadas.add(red);
          }
          redesUsadas.forEach(red => {
            contador[red] = (contador[red] || 0) + 1;
          });
        }

        // Configuración rich (uno por red)
        const richStyles: Record<string, any> = {};
        const yAxisData: string[] = [];

        const seriesData = Object.entries(contador)
          .sort((a, b) => b[1] - a[1])
          .map(([red, value]) => {
            const key = `img${red}`;
            const name = `${key}| ${red[0].toUpperCase()}${red.slice(1)}`;
            const iconPath = `/img/${this.redStyles[red]?.icon ?? 'web.png'}`;

            // Guardamos el estilo rich para esa red
            richStyles[key] = {
              height: 20,
              width: 20,
              align: 'center',
              backgroundColor: { image: iconPath }
            };

            yAxisData.push(name);

            return {
              value,
              itemStyle: { color: this.redStyles[red]?.color ?? '#999' },
              name
            };
          });

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => `${params.name.split('| ')[1]}: ${params.value} iniciativas`
          },
          grid: {
            left: '5%',
            right: '5%',
            bottom: '5%',
            containLabel: true
          },
          xAxis: {
            type: 'value',
            axisLabel: { color: '#fff' },
            splitLine: { lineStyle: { color: '#444' } }
          },
          yAxis: {
            type: 'category',
            data: yAxisData,
            axisLabel: {
              color: '#fff',
              formatter: (value: string) => `{${value.split('|')[0]}|} ${value.split('|')[1]}`,
              rich: richStyles
            }
          },
          series: [
            {
              type: 'bar',
              data: seriesData,
              label: {
                show: true,
                position: 'right',
                color: '#fff',
                fontWeight: 600
              },
              itemStyle: {
                borderRadius: [0, 6, 6, 0]
              }
            }
          ]
        };

        this.cargando = false;
      },
      error: err => {
        console.error('Error cargando indicador 7:', err);
        this.cargando = false;
      }
    });
  }
}
