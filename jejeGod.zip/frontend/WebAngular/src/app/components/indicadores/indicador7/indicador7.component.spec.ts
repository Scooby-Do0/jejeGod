import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador7Component } from './indicador7.component';

describe('Indicador7Component', () => {
  let component: Indicador7Component;
  let fixture: ComponentFixture<Indicador7Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador7Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
