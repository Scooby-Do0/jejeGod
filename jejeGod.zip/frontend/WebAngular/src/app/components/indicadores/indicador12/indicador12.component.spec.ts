import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador12Component } from './indicador12.component';

describe('Indicador12Component', () => {
  let component: Indicador12Component;
  let fixture: ComponentFixture<Indicador12Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador12Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador12Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
