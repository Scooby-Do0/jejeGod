import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgxEchartsDirective } from 'ngx-echarts';
import type { EChartsOption } from 'echarts';

@Component({
  selector: 'app-indicador12',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador12.component.html',
  styleUrls: ['./indicador12.component.scss']
})
export class Indicador12Component implements OnChanges {
  @Input() curso: string = '';
  cargando = true;
  chartOptions: EChartsOption = {};

  constructor(private http: HttpClient) {}

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }

  cargarDatos(): void {
    this.cargando = true;

    this.http.get<any>(`https://localhost:7217/Indicadores/12/${this.curso}`).subscribe({
      next: (res) => {
        const iniciativas = res.indicador12.horasDeIniciativas ?? [];

        const yData = iniciativas.map((i: any) => i.iniciativa);
        const barData = iniciativas.map((i: any) => i.horas);

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            formatter: (params: any) => {
              const item = params[0];
              return `<strong>${item.name}</strong><br/>Horas dedicadas: <b>${item.value}</b>`;
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis: {
            type: 'value',
            axisLabel: { color: '#ccc' },
            splitLine: { lineStyle: { color: '#333' } }
          },
          yAxis: {
            type: 'category',
            data: yData,
            axisLabel: {
              color: '#fff',
              formatter: (val: string) => val.length > 24 ? val.slice(0, 24) + '…' : val
            },
            axisLine: { lineStyle: { color: '#ccc' } }
          },
          series: [
            {
              type: 'bar',
              data: barData,
              barWidth: 18,
              itemStyle: {
                color: '#3b82f6',
                borderRadius: [4, 4, 4, 4]
              },
              label: {
                show: true,
                position: 'right',
                color: '#fff',
                fontSize: 12,
                fontWeight: 500
              }
            }
          ]
        };

        this.cargando = false;
      },
      error: (err) => {
        console.error('Error al cargar indicador 12:', err);
        this.cargando = false;
      }
    });
  }
}
