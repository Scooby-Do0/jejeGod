import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxEchartsModule } from 'ngx-echarts';
import * as echarts from 'echarts';
import { IndicadorService } from '../../../services/indicadores.service';

type EChartsOption = echarts.EChartsOption;

@Component({
  selector: 'app-indicador2',
  standalone: true,
  imports: [CommonModule, NgxEchartsModule],
  templateUrl: './indicador2.component.html',
  styleUrls: ['./indicador2.component.scss']
})
export class Indicador2Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: EChartsOption = {};
  cargando = true;
  total = 0;

  constructor(private indicadorService: IndicadorService) {}

  ngOnChanges(): void {
    if (this.curso) this.cargarDatos();
  }

  cargarDatos(): void {
    this.cargando = true;
    this.chartOptions = {};
    this.total = 0;

    this.indicadorService.getIndicador(2, this.curso).subscribe({
      next: response => {
        const datos = response?.indicador2?.[this.curso] ?? {};
        const dataEntries = Object.entries(datos)
          .filter(([_, val]) => (val as number) > 0);

        this.total = dataEntries.reduce((acc, [, val]) => acc + (val as number), 0);

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            formatter: '{b}: {c} ({d}%)'
          },
          legend: {
            show: dataEntries.length > 0,
            orient: 'horizontal',
            top: '5%',
            left: 'center',
            textStyle: { color: '#ccc' },
            itemWidth: 14,
            itemHeight: 10,
            icon: 'roundRect',
            data: dataEntries.map(([tipo]) => tipo)
          },
          series: [
            {
              name: 'Tipos de iniciativa',
              type: 'pie',
              radius: ['55%', '80%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              itemStyle: {
                borderRadius: 12,
                borderColor: 'transparent',
                borderWidth: 2
              },
              label: {
                show: true,
                position: 'inside',
                fontSize: 13,
                fontWeight: 600,
                color: '#fff',
                formatter: '{c}'
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: 20,
                  fontWeight: 'bold',
                  color: '#fff'
                }
              },
              labelLine: { show: false },
              data: dataEntries.map(([tipo, valor]) => ({
                name: tipo,
                value: valor as number
              }))
            },
            // CENTRO DEL DONUT: Total
            {
              type: 'pie',
              radius: ['0%', '45%'],
              center: ['50%', '60%'],
              label: {
                position: 'center',
                formatter: `{a|${this.total}}\n{b|Iniciativas}`,
                rich: {
                  a: {
                    fontSize: 24,
                    fontWeight: 'bold',
                    color: '#fff'
                  },
                  b: {
                    fontSize: 12,
                    color: '#ccc'
                  }
                },
                show: true
              },
              data: [{ value: this.total, name: 'Iniciativas' }],
              itemStyle: {
                color: 'transparent'
              },
              tooltip: { show: false }
            }
          ]
        };
        

        this.cargando = false;
      },
      error: err => {
        console.error('Error al cargar indicador 2:', err);
        this.cargando = false;
      }
    });
  }
}
