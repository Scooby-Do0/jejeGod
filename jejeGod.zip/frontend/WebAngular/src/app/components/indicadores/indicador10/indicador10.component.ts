import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndicadorService } from '../../../services/indicadores.service';
import { NgxEchartsModule } from 'ngx-echarts';

@Component({
  selector: 'app-indicador10',
  standalone: true,
  imports: [CommonModule, NgxEchartsModule],
  templateUrl: './indicador10.component.html',
  styleUrls: ['./indicador10.component.scss']
})
export class Indicador10Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: any = {};
  loading: boolean = false;

  constructor(private indicadorService: IndicadorService) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['curso'] && this.curso) {
      this.fetchData();
    }
  }

  fetchData(): void {
    this.loading = true;

    this.indicadorService.getIndicador(10, this.curso).subscribe(
      (data) => {
        const profesorMap: { [profesor: string]: { iniciativas: string[]; count: number } } = {};

        data.indicador10.forEach((item: any) => {
          item.profesores.forEach((profesor: string) => {
            if (!profesorMap[profesor]) {
              profesorMap[profesor] = { iniciativas: [], count: 0 };
            }
            profesorMap[profesor].iniciativas.push(item.iniciativa);
            profesorMap[profesor].count++;
          });
        });

        const profesores = Object.keys(profesorMap);
        const numeroIniciativas = profesores.map((profesor) => profesorMap[profesor].count);
        const iniciativasPorProfesor = profesores.map((profesor) => profesorMap[profesor].iniciativas.join(', '));

        this.chartOptions = {
          backgroundColor: 'transparent', // opcional, por si quieres fondo transparente
          title: {
            text: '',
            left: 'center',
            textStyle: {
              color: '#ffffff'
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => {
              return `
                ${params.name}<br/>
                
                <span style="color: #000000;">
                  ${iniciativasPorProfesor[params.dataIndex]}
                </span>
              `;
            },
            textStyle: {
              color: '#333333'
            }
          },
          xAxis: {
            type: 'category',
            data: profesores,
            axisLabel: {
              rotate: 30,
              color: '#ffffff',
              margin: 20
            },
            axisLine: {
              lineStyle: {
                color: '#ffffff'
              }
            }
          },
          yAxis: {
            type: 'value',
            name: '',
            nameTextStyle: {
              color: '#ffffff'
            },
            axisLabel: {
              color: '#ffffff',
              formatter: '{value}',
              interval: 1
            },
            minInterval: 1,
            axisLine: {
              lineStyle: {
                color: '#ffffff'
              }
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(255,255,255,0.2)'
              }
            }
          },
          series: [
            {
              name: 'Iniciativas',
              type: 'bar',
              data: numeroIniciativas,
              label: {
                show: false,
              },
              itemStyle: {
                color: '#3398DB'
              }
            }
          ]
        };

        this.loading = false;
      },
      (error) => {
        console.error('Error al cargar Indicador 10:', error);
        this.loading = false;
      }
    );
  }
}  
