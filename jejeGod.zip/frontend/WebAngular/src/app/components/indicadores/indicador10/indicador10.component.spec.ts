import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador10Component } from './indicador10.component';

describe('Indicador10Component', () => {
  let component: Indicador10Component;
  let fixture: ComponentFixture<Indicador10Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador10Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador10Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
