import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador5Component } from './indicador5.component';

describe('Indicador5Component', () => {
  let component: Indicador5Component;
  let fixture: ComponentFixture<Indicador5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador5Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
