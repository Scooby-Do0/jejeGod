import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import type { EChartsOption } from 'echarts';
import type { SunburstSeriesOption } from 'echarts/charts';
import { NgxEchartsDirective } from 'ngx-echarts';

interface ODSItem {
  ods: string;
  metas: string[];
  iniciativas: string[];
}

@Component({
  selector: 'app-indicador5',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador5.component.html',
  styleUrls: ['./indicador5.component.scss']
})
export class Indicador5Component implements OnChanges {
  @Input() curso: string = '';

  @Input() showLabels: boolean = false;
  @Input() nodeClick: 'rootToNode' | 'link' | false = false;

  chartOptions: EChartsOption & { series: SunburstSeriesOption[] } = { series: [] };
  cargando = true;

  constructor(private http: HttpClient) { }

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }

  cargarDatos(): void {
    this.cargando = true;

    this.http.get<{ indicador5: ODSItem[] }>(`https://localhost:7217/Indicadores/5/${this.curso}`)
      .subscribe({
        next: (response) => {
          const data = response.indicador5 ?? [];

          const sunburstData = data.map(odsItem => {
            const match = odsItem.ods.match(/^(\d+)\.\s*(.*)$/);
            let idOds = 'X';
            if (match) {
              idOds = match[1];
            }

            const metas = odsItem.metas.map(meta => ({
              name: meta,
              children: odsItem.iniciativas.map(ini => ({
                name: ini,
                value: 1
              }))
            }));

            return {
              name: idOds,
              children: metas
            };
          });

          this.chartOptions = {
            backgroundColor: 'transparent',
            tooltip: {
              trigger: 'item',
              backgroundColor: '#222',
              borderColor: '#555',
              borderWidth: 1,
              textStyle: { color: '#eee', fontSize: 12 },
              formatter: (params: any) => this.getTooltipContent(params)
            },
            series: [
              {
                type: 'sunburst',
                radius: [30, '90%'],
                nodeClick: this.nodeClick,
                sort: undefined,
                animation: true,
                data: sunburstData,
                itemStyle: {
                  borderRadius: 4,
                  borderWidth: 1,
                  borderColor: '#fff1'
                },
                label: {
                  show: this.showLabels,
                  rotate: 'radial' as any,
                  overflow: 'truncate',
                  fontSize: 10,
                  formatter: (p: any) => {
                    if (p.name?.length > 16 && !this.showLabels) {
                      return p.name.slice(0, 16) + '…';
                    }
                    return p.name;
                  }
                },
                emphasis: {
                  focus: 'ancestor'
                },
                levels: [
                  {},
                  {
                    r0: '30%',
                    r: '50%',
                    label: { rotate: 'tangential', fontSize: 11 }
                  },
                  {
                    r0: '50%',
                    r: '70%',
                    label: { align: 'center', fontSize: 10 }
                  },
                  {
                    r0: '70%',
                    r: '90%',
                    label: { position: 'outside', fontSize: 10 }
                  }
                ]
              }
            ]
          };

          this.cargando = false;
        },
        error: (err) => {
          console.error('Error al cargar indicador 5:', err);
          this.cargando = false;
        }
      });
  }


  private getTooltipContent(params: any): string {
    const pathInfo = params.treePathInfo || [];
    const segs = pathInfo.slice(1).map((seg: any) => seg.name);
  
    if (segs.length === 0) return `<strong>${params.name}</strong>`;
  
    const first = segs[0];
    const others = segs.slice(1);
  
    let tooltipContent = '';
  
    if (/^\d+$/.test(first)) {
      // Tooltip completo en una sola línea, con todo alineado verticalmente
      tooltipContent = `
        <span style="display:inline-flex; align-items:center; gap:6px;">
          <img src="/img/${first}.png" style="width:18px; height:18px;" />
          <span>ODS ${first}${others.length ? ' → ' + others.join(' → ') : ''}</span>
        </span>
      `;
    } else {
      tooltipContent = segs.join(' → ');
    }
  
    return `<strong>${tooltipContent}</strong>`;
  }
  
}
