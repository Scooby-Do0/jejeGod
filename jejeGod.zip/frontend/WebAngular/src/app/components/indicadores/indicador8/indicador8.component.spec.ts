import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador8Component } from './indicador8.component';

describe('Indicador8Component', () => {
  let component: Indicador8Component;
  let fixture: ComponentFixture<Indicador8Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador8Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
