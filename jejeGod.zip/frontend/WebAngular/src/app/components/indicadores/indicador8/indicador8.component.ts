// indicador8.component.ts
import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import type { EChartsOption } from 'echarts';
import { NgxEchartsDirective } from 'ngx-echarts';

@Component({
  selector: 'app-indicador8',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador8.component.html',
  styleUrls: ['./indicador8.component.scss']
})
export class Indicador8Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: EChartsOption = {};
  cargando = true;

  constructor(private http: HttpClient) {}

  ngOnChanges(): void {
    if (this.curso) this.cargarDatos();
  }

  private cargarDatos(): void {
    this.cargando = true;

    this.http.get<any>(`https://localhost:7217/Indicadores/8/${this.curso}`).subscribe({
      next: (res) => {
        const data = res?.indicador8?.[this.curso];
        if (!data) return;

        const tipos = ['valor', 'charla', 'taller', 'visita', 'otro'];

        const chartData = tipos
          .map(tipo => {
            return {
              name: tipo.charAt(0).toUpperCase() + tipo.slice(1),
              value: data[tipo]?.cantidad || 0,
              titulos: data[tipo]?.titulos || []
            };
          })
          .filter(item => item.value > 0);

        this.chartOptions = {
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => {
              const titulos = params.data?.titulos ?? [];
              const lista = titulos.length > 0
                ? `<ul style="margin:0;padding-left:1em;">${titulos.map((t: string) => `<li>${t}</li>`).join('')}</ul>`
                : '<em>Sin títulos</em>';
              return `<strong>${params.name}:</strong> ${params.value}<br>${lista}`;
            }
          },
          legend: {
            top: '5%',
            left: 'center',
            textStyle: { color: '#fff' }
          },
          series: [
            {
              name: 'Tipo',
              type: 'pie',
              radius: ['40%', '70%'],
              avoidLabelOverlap: false,
              itemStyle: {
                borderRadius: 10,
                borderColor: '#fff',
                borderWidth: 2
              },
              label: {
                show: true,
                formatter: '{b}: {c}',
                color: '#fff'
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: 22,
                  fontWeight: 'bold'
                }
              },
              labelLine: {
                show: true
              },
              data: chartData
            }
          ]
        };

        this.cargando = false;
      },
      error: (err) => {
        console.error('Error cargando indicador 8:', err);
        this.cargando = false;
      }
    });
  }
}
