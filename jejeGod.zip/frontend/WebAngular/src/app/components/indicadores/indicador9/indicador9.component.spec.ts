import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador9Component } from './indicador9.component';

describe('Indicador9Component', () => {
  let component: Indicador9Component;
  let fixture: ComponentFixture<Indicador9Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador9Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador9Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
