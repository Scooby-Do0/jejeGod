import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgxEchartsDirective } from 'ngx-echarts';
import type { EChartsOption } from 'echarts';

@Component({
  selector: 'app-indicador9',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador9.component.html',
  styleUrls: ['./indicador9.component.scss']
})
export class Indicador9Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: EChartsOption = {};
  cargando = true;

  private colorPorDimension: Record<string, string> = {
    'Dimensión Social': '#FF445E',
    'Dimensión Económica': '#4F82FF',
    'Dimensión Medioambiental': '#3FA85E'
  };

  constructor(private http: HttpClient) {}

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }

  private cargarDatos(): void {
    this.cargando = true;

    this.http.get<any>(`https://localhost:7217/Indicadores/9/${this.curso}`).subscribe({
      next: (response) => {
        const dataRaw = response?.indicador9?.[this.curso];
        if (!dataRaw) return;

        const dimensiones: {
          name: string;
          value: number;
          titulos: string[];
          itemStyle: { color: string };
        }[] = [];

        if (Array.isArray(dataRaw.social) && dataRaw.social.length) {
          dimensiones.push({
            name: 'Dimensión Social',
            value: dataRaw.social.length,
            titulos: dataRaw.social.map((d: any) => d.titulo),
            itemStyle: { color: this.colorPorDimension['Dimensión Social'] }
          });
        }

        if (Array.isArray(dataRaw['económica']) && dataRaw['económica'].length) {
          dimensiones.push({
            name: 'Dimensión Económica',
            value: dataRaw['económica'].length,
            titulos: dataRaw['económica'].map((d: any) => d.titulo),
            itemStyle: { color: this.colorPorDimension['Dimensión Económica'] }
          });
        }

        if (Array.isArray(dataRaw.medioambiental) && dataRaw.medioambiental.length) {
          dimensiones.push({
            name: 'Dimensión Medioambiental',
            value: dataRaw.medioambiental.length,
            titulos: dataRaw.medioambiental.map((d: any) => d.titulo),
            itemStyle: { color: this.colorPorDimension['Dimensión Medioambiental'] }
          });
        }

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            backgroundColor: '#1f1f1f',
            borderColor: '#444',
            textStyle: { color: '#fff' },
            extraCssText: 'max-width: 260px; white-space: normal; word-wrap: break-word;',
            formatter: (params: any) => {
              const dim = dimensiones.find(d => d.name === params.name);
              if (!dim) return '';
              const lista = dim.titulos.length > 0
                ? `<ul style="margin:0;padding-left:1.2em;">${
                    dim.titulos
                      .map(t => `<li style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:220px;">${t}</li>`)
                      .join('')
                  }</ul>`
                : '<em>Sin iniciativas</em>';

              return `<strong>${params.name}</strong><br>${dim.value} iniciativas<br>${lista}`;
            }
          },
          legend: {
            top: '5%',
            left: 'center',
            textStyle: { color: '#fff' }
          },
          series: [
            {
              name: 'Dimensiones',
              type: 'pie',
              radius: ['50%', '75%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              selectedMode: false,
              itemStyle: {
                borderRadius: 10,
                borderColor: '#fff',
                borderWidth: 2
              },
              label: {
                show: true,
                position: 'inside',
                formatter: '{c}',
                color: '#fff',
                fontSize: 14,
                fontWeight: 600
              },
              emphasis: {
                label: {
                  show: true,
                  formatter: '{b}',
                  fontSize: 24,
                  fontWeight: 'bold',
                  color: '#fff'
                }
              },
              labelLine: { show: false },
              data: dimensiones
            }
          ]
        };

        this.cargando = false;
      },
      error: (err) => {
        console.error('Error al cargar indicador 9:', err);
        this.cargando = false;
      }
    });
  }
}
