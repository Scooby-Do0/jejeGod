import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import type { EChartsOption } from 'echarts';
import type { SunburstSeriesOption } from 'echarts/charts';
import { NgxEchartsDirective } from 'ngx-echarts';

interface Ciclo {
  ciclo: string;
  modulos: string[];
  iniciativas: string[];
}

@Component({
  selector: 'app-indicador3',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador3.component.html',
  styleUrls: ['./indicador3.component.scss']
})
export class Indicador3Component implements OnChanges {
  @Input() curso: string = '';
  @Input() showLabels: boolean = false;
  @Input() nodeClick: 'rootToNode' | 'link' | false = false;


  chartOptions: EChartsOption & { series: SunburstSeriesOption[] } = { series: [] };

  cargando = true;

  constructor(private http: HttpClient) { }

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }
  

  private generarColoresJerarquicos(data: Ciclo[]): any[] {
    return data.map((ciclo) => {
      const modulos = ciclo.modulos.map((modulo, index) => {
        const iniciativa = ciclo.iniciativas[index] || `Iniciativa ${index + 1}`;
  
        return {
          name: modulo,
          value: 1,
          children: [
            {
              name: iniciativa,
              value: 1
            }
          ]
        };
      });
  
      return {
        name: ciclo.ciclo,
        children: modulos
      };
    });
  }
  

  private getTooltipContent(params: any): string {
    const pathArray = params?.treePathInfo || [];
    const names = pathArray.slice(1).map((d: any) => d.name);

    const lastName = names[names.length - 1] || params.name;

    if (/^\d+$/.test(lastName)) {
      return `
        <div style="display:flex; align-items:center; gap:6px;">
          <img src="/img/${lastName}.png" style="width:24px; height:24px;" />
          <span style="font-weight:600;">ODS ${lastName}</span>
        </div>
      `;
    } else {
      const pathStr = names.join(' → ') || lastName;
      return `<strong>${pathStr}</strong>`;
    }
  }

  private getContrastColor(bgColor: string): string {
    const rgb = this.hexToRgb(bgColor) || { r: 128, g: 128, b: 128 };
    const luminance = (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
    return luminance > 0.6 ? '#000' : '#fff';
  }

  private hexToRgb(color: string): { r: number, g: number, b: number } | null {
    const hex = color.replace('#', '');
    if (hex.length === 3) {
      const [r, g, b] = hex.split('');
      color = `#${r}${r}${g}${g}${b}${b}`;
    }
    if (/^[0-9A-Fa-f]{6}$/.test(hex)) {
      const bigint = parseInt(hex, 16);
      return {
        r: (bigint >> 16) & 255,
        g: (bigint >> 8) & 255,
        b: bigint & 255
      };
    }
    return null;
  }

  cargarDatos(): void {
    this.cargando = true;

    this.http.get<any>(`https://localhost:7217/Indicadores/3/${this.curso}`).subscribe({
      next: (response) => {
        const data = this.generarColoresJerarquicos(response.indicador3);

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => this.getTooltipContent(params),
            textStyle: { color: '#eee', fontSize: 12 },
            backgroundColor: '#222',
            borderColor: '#555',
            borderWidth: 1
          },
          series: [
            {
              type: 'sunburst',
              radius: [10, '90%'],


              nodeClick: this.nodeClick,


              data: data,
              animation: true,
              animationDuration: 800,
              animationEasing: 'cubicOut',
              emphasis: {
                focus: 'ancestor'
              },
              sort: undefined,

              itemStyle: {
                borderRadius: 6,
                borderWidth: 1,
                borderColor: '#fff1'
              },
              label: {
                show: this.showLabels,
                overflow: 'truncate',
                rotate: 'radial' as any,
                fontSize: 11,

                color: ((param: any) => {
                  return this.getContrastColor(param.color);
                }) as any,

                formatter: (p: any) => {
                  if (p.name?.length > 16 && !this.showLabels) {
                    return p.name.slice(0, 15) + '…';
                  }
                  return p.name;
                }
              },
              levels: [
                {},
                {
                  r0: '10%',
                  r: '30%',
                  itemStyle: { borderWidth: 2 },
                  label: {
                    rotate: 'tangential',
                    fontSize: 12,
                    color: '#000'
                  }
                },
                {
                  r0: '30%',
                  r: '60%',
                  label: {
                    align: 'right',
                    fontSize: 11,
                    color: '#000'
                  }
                },
                {
                  r0: '60%',
                  r: '90%',
                  label: {
                    position: 'outside',
                    fontSize: 10,
                    padding: 3,
                    silent: false,
                    color: '#fff'
                  }
                }
              ]

            }
          ]
        };

        this.cargando = false;
      },
      error: (err) => {
        console.error('Error cargando indicador 3:', err);
        this.cargando = false;
      }
    });
  }
}
