import {
  Component, Input, Output, EventEmitter, OnInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgxEchartsDirective } from 'ngx-echarts';


import { Indicador1Component } from '../indicador1/indicador1.component';
import { Indicador2Component } from '../indicador2/indicador2.component';
import { Indicador3Component } from '../indicador3/indicador3.component';
import { Indicador4Component } from '../indicador4/indicador4.component';
import { Indicador5Component } from '../indicador5/indicador5.component';
import { Indicador6Component } from '../indicador6/indicador6.component';
import { Indicador7Component } from '../indicador7/indicador7.component';
import { Indicador8Component } from '../indicador8/indicador8.component';
import { Indicador9Component } from '../indicador9/indicador9.component';
import { Indicador10Component } from '../indicador10/indicador10.component';
import { Indicador11Component } from '../indicador11/indicador11.component';
import { Indicador12Component } from '../indicador12/indicador12.component';

import { Indicador13Component } from '../indicador13/indicador13.component';

const compMap: Record<string, any> = {
  indicador1: Indicador1Component,
  indicador2: Indicador2Component,
  indicador3: Indicador3Component,
  indicador4: Indicador4Component,
  indicador5: Indicador5Component,
  indicador6: Indicador6Component,
  indicador7: Indicador7Component,
  indicador8: Indicador8Component,
  indicador9: Indicador9Component,
  indicador10: Indicador10Component,
  indicador11: Indicador11Component,
  indicador12: Indicador12Component,
  indicador13: Indicador13Component
};

@Component({
  selector: 'app-indicador-modal',
  standalone: true,
  imports: [
    CommonModule, FormsModule
  ],
  templateUrl: './indicador-modal.component.html',
  styleUrls: ['./indicador-modal.component.scss']
})
export class IndicadorModalComponent implements OnInit {

  @Input() title = '';
  @Input() indicadorTipo = '';
  @Input() cursoBase = '';
  @Input() cursosDisponibles: string[] = [];
  @Input() isOpen = false;

  @Output() close = new EventEmitter<void>();

  comparar = false;
  cursoComparado = '';

  get compActual() { return compMap[this.indicadorTipo]; }
  get compComparado() { return this.comparar ? compMap[this.indicadorTipo] : null; }

  ngOnInit(): void {
    this.cursoComparado =
      this.cursosDisponibles.find(c => c !== this.cursoBase) ?? '';
  }

  onToggleComparar(): void {
    if (!this.comparar) return;
    if (!this.cursoComparado || this.cursoComparado === this.cursoBase) {
      this.cursoComparado =
        this.cursosDisponibles.find(c => c !== this.cursoBase) ?? '';
    }
  }

  onClose() { this.close.emit(); }
}
