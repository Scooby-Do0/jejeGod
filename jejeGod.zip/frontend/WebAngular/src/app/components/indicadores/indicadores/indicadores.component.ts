import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Indicador1Component } from '../indicador1/indicador1.component';
import { Indicador2Component } from '../indicador2/indicador2.component';
import { Indicador3Component } from '../indicador3/indicador3.component';
import { Indicador4Component } from '../indicador4/indicador4.component';
import { Indicador5Component } from '../indicador5/indicador5.component';
import { Indicador6Component } from '../indicador6/indicador6.component';
import { Indicador7Component } from '../indicador7/indicador7.component';
import { Indicador8Component } from '../indicador8/indicador8.component';
import { Indicador9Component } from '../indicador9/indicador9.component';
import { Indicador10Component } from '../indicador10/indicador10.component';
import { Indicador11Component } from '../indicador11/indicador11.component';
import { Indicador12Component } from '../indicador12/indicador12.component';

import { Indicador13Component } from '../indicador13/indicador13.component';
import { IndicadorModalComponent } from '../indicador-modal/indicador-modal.component';
import { IndicadorService } from '../../../services/indicadores.service';

@Component({
  selector: 'app-indicadores',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    Indicador1Component,
    Indicador2Component,
    Indicador3Component,
    Indicador4Component,
    Indicador5Component,
    Indicador6Component,
    Indicador7Component,
    Indicador8Component,
    Indicador9Component,
    Indicador10Component,
    Indicador11Component,
    Indicador12Component,
    Indicador13Component,
    IndicadorModalComponent
  ],
  templateUrl: './indicadores.component.html',
  styleUrls: ['./indicadores.component.scss']
})
export class IndicadoresComponent implements OnInit {
  cursosDisponibles: string[] = [];
  cursoSeleccionado: string = '';

  modalOpen: boolean = false;
  modalTitle: string = '';
  modalChartOptions: any = {};
  modalTipo: string = '';
  modalCursoBase: string = '';


  @ViewChild(Indicador1Component) indicador1Ref!: Indicador1Component;
  @ViewChild(Indicador2Component) indicador2Ref!: Indicador2Component;
  @ViewChild(Indicador3Component) indicador3Ref!: Indicador3Component;
  @ViewChild(Indicador4Component) indicador4Ref!: Indicador4Component;
  @ViewChild(Indicador5Component) indicador5Ref!: Indicador5Component;
  @ViewChild(Indicador6Component) indicador6Ref!: Indicador6Component;
  @ViewChild(Indicador7Component) indicador7Ref!: Indicador7Component;
  @ViewChild(Indicador8Component) indicador8Ref!: Indicador8Component;
  @ViewChild(Indicador9Component) indicador9Ref!: Indicador9Component;
  @ViewChild(Indicador10Component) indicador10Ref!: Indicador10Component;
  @ViewChild(Indicador11Component) indicador11Ref!: Indicador11Component;
  @ViewChild(Indicador12Component) indicador12Ref!: Indicador12Component;
  @ViewChild(Indicador13Component) indicador13Ref!: Indicador11Component;

  constructor(private indicadorService: IndicadorService) { }


  ngOnInit(): void {
    this.indicadorService.getCursos().subscribe({
      next: (data: string[]) => {
        this.cursosDisponibles = data;
        if (data.length > 0) {
          this.cursoSeleccionado = data[0];
        }
      },
      error: (err) => console.error('Error cargando cursos:', err)
    });
  }

  openModal(tipo: string): void {
    this.modalOpen = true;

    switch (tipo) {
      case 'indicador1':
        this.modalTitle = 'Indicador 1 ampliado';
        this.modalChartOptions = this.indicador1Ref?.chartOptions ?? {};
        break;

      case 'indicador2':
        this.modalTitle = 'Indicador 2 ampliado';
        this.modalChartOptions = this.indicador2Ref?.chartOptions ?? {};
        break;

      case 'indicador3': {
        this.modalTitle = 'Ciclos y módulos implicados';

        const chart3 = this.indicador3Ref?.chartOptions ?? {};

        const series = Array.isArray(chart3.series)
          ? chart3.series.map((serie: any) => ({
            ...serie,
            nodeClick: 'rootToNode',
            label: {
              ...(serie.label || {}),
              show: true
            }
          }))
          : [];

        this.modalChartOptions = {
          ...chart3,
          series
        };

        break;
      }


      case 'indicador4':
        this.modalTitle = 'Indicador 4 ampliado';
        this.modalChartOptions = this.indicador4Ref?.chartOptions ?? {};
        break;

      case 'indicador5': {
        this.modalTitle = 'Indicador 5 ampliado';
        const chart5 = this.indicador5Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart5,
          series: (chart5.series ?? []).map((serie: any) => ({
            ...serie,
            nodeClick: 'rootToNode',
            label: {
              ...(serie.label || {}),
              show: true
            }
          }))
        };
        break;
      }

      case 'indicador6': {
        this.modalTitle = 'Indicador 6 ampliado';
        const chart6 = this.indicador6Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart6,
          series: Array.isArray(chart6.series)
            ? chart6.series.map((serie: any) => ({
              ...serie,
              label: {
                ...(serie.label || {}),
                show: true
              }
            }))
            : []
        };
        break;
      }
      case 'indicador7':
        this.modalTitle = 'Indicador 7 - Difusión en RRSS y Web';
        const chart7 = (this as any).indicador7Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart7,
          series: chart7.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;

      case 'indicador8':
        this.modalTitle = 'Indicador 8 - Tipología de acciones';
        const chart8 = (this as any).indicador8Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart8,
          series: chart8.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;

      case 'indicador9':
        this.modalTitle = 'Indicador 9 - Dimensiones asociadas a las iniciativas';
        const chart9 = (this as any).indicador9Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart9,
          series: chart9.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;
      case 'indicador10':
        this.modalTitle = 'Indicador 10 - Profesores por Iniciativa';
        const chart10 = this.indicador10Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart10,
          series: chart10.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;
      case 'indicador11':
        this.modalTitle = 'Indicador 11 - Iniciativas innovadoras';
        const chart11 = this.indicador11Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart11,
          series: chart11.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;
      case 'indicador12':
        this.modalTitle = 'Indicador 12 - Horas dedicadas a cada acción';
        const chart12 = this.indicador12Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart12,
          series: Array.isArray(chart12.series)
            ? chart12.series.map((serie: any) => ({
              ...serie,
              label: { ...(serie.label || {}), show: true }
            }))
            : []
        };
        break;

      case 'indicador13':
        this.modalTitle = 'Indicador 13 - Acciones y eventos';
        const chart13 = this.indicador13Ref?.chartOptions ?? {};
        this.modalChartOptions = {
          ...chart13,
          series: chart13.series?.map((serie: any) => ({
            ...serie,
            label: { ...(serie.label || {}), show: true }
          }))
        };
        break;


      default:
        this.modalTitle = `Vista detallada: ${tipo}`;
        this.modalChartOptions = {};

    }
    this.modalTipo = tipo;
    this.modalCursoBase = this.cursoSeleccionado;

  }

  onModalClose(): void {
    this.modalOpen = false;
  }

  toggleMenu(): void {
    console.log('Mostrar/ocultar menú lateral...');
  }
}
