import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { EChartsOption } from 'echarts';
import { NgxEchartsDirective } from 'ngx-echarts';

@Component({
  selector: 'app-indicador4',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador4.component.html',
  styleUrls: ['./indicador4.component.scss']
})
export class Indicador4Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: EChartsOption = {};
  cargando = true;

  constructor(private http: HttpClient) { }

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarDatos();
    }
  }

  cargarDatos(): void {
    this.cargando = true;
    const url = `https://localhost:7217/Indicadores/4/${this.curso}`;

    this.http.get<any[]>(url).subscribe({
      next: data => {
        const total = data.length;

        const centralNode = {
          id: 'central',
          name: `${total}`, 
          descripcion: `Total de iniciativas: ${total}`,
          symbolSize: 70,
          itemStyle: {
            color: '#f55'
          }
        };

        const initiativeNodes = data.map((item, index) => ({
          id: `ini-${index}`,
          name: item.nombre,
          descripcion: item.descripcion,
          symbolSize: 50,
          itemStyle: {
            color: '#5ec2c3'
          }
        }));

        const edges = initiativeNodes.map(ini => ({
          source: 'central',
          target: ini.id,
          lineStyle: {
            color: '#aaa',
            width: 1
          }
        }));

        const nodes = [centralNode, ...initiativeNodes];

        this.chartOptions = {
          tooltip: {
            trigger: 'item',
            backgroundColor: 'rgba(30, 30, 30, 0.9)',
            borderColor: '#666',
            borderWidth: 1,
            textStyle: {
              color: '#fff',
              fontSize: 12
            },
            formatter: (params: any) => {
              const node = params.data;
              if (!node.descripcion) return `<strong>${node.name}</strong>`;
              return `
                <strong>${node.name}</strong><br/>
                <div style="max-width:320px; white-space:normal; font-weight:400; font-size:12px;">
                  ${node.descripcion}
                </div>
              `;
            }
          },
          series: [
            {
              type: 'graph',
              layout: 'force',
              data: nodes,
              edges: edges,
              draggable: true,
              roam: true,
              edgeSymbol: ['none', 'arrow'],
              edgeSymbolSize: 6,
              lineStyle: {
                opacity: 0.6,
                curveness: 0.3
              },
              label: {
                show: true,
                position: 'inside',
                color: '#fff',
                fontSize: 10,
                formatter: (params: any) => {
                  const maxLen = 14;
                  const name = params.data.name || '';
                  return name.length > maxLen ? name.slice(0, maxLen) + '…' : name;
                }
              },
              force: {
                repulsion: 250,
                edgeLength: [80, 120]
              },
              emphasis: {
                focus: 'adjacency',
                lineStyle: {
                  width: 2,
                  color: '#f55'
                },
                itemStyle: {
                  borderColor: '#f55',
                  borderWidth: 2
                }
              },
              itemStyle: {
                borderColor: '#fff',
                borderWidth: 1
              }
            }
          ]
        };

        this.cargando = false;
      },
      error: err => {
        console.error('Error cargando indicador 4:', err);
        this.cargando = false;
      }
    });
  }
}
