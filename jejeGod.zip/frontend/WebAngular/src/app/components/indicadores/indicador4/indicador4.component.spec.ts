import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador4Component } from './indicador4.component';

describe('Indicador4Component', () => {
  let component: Indicador4Component;
  let fixture: ComponentFixture<Indicador4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador4Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
