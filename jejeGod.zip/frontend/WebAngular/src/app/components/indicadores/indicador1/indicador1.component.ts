import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { EChartsOption } from 'echarts';
import { NgxEchartsDirective } from 'ngx-echarts';
import { OdsService } from '../../../services/ods.service';

@Component({
  selector: 'app-indicador1',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective],
  templateUrl: './indicador1.component.html',
  styleUrls: ['./indicador1.component.scss']
})
export class Indicador1Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: EChartsOption = {};
  cargando = false;

  odsList: any[] = [];
  iniciativasPorOds: { [key: number]: string[] } = {};

  constructor(private http: HttpClient, private odsService: OdsService) {}

  ngOnChanges(): void {
    if (this.curso) {
      this.cargarODS();
    }
  }

  cargarODS() {
    this.cargando = true;
    this.odsService.getOds().subscribe({
      next: (odsData) => {
        this.odsList = odsData;
        this.cargarDatos();
      },
      error: err => {
        console.error('Error cargando ODS:', err);
        this.cargando = false;
      }
    });
  }

  cargarDatos() {
    this.http.get<any>(`https://localhost:7217/Indicadores/1/${this.curso}`).subscribe({
      next: response => {
        const datos = response.indicador1 ?? [];

        this.iniciativasPorOds = {};
        datos.forEach((d: any) => {
          const idODS = this.odsList.find(o => o.nombre.trim().toLowerCase() === d.ods.trim().toLowerCase())?.idOds;
          if (idODS) {
            this.iniciativasPorOds[idODS] = d.iniciativas;
          }
        });

        const yLabels = this.odsList.map(o => o.idOds.toString());
        const seriesData = this.odsList.map(ods => ({
          value: this.iniciativasPorOds[ods.idOds]?.length || 0,
          itemStyle: {
            color: this.getOdsColor(ods.idOds),
            borderRadius: [6, 6, 6, 6]
          }
        }));

        this.chartOptions = {
          tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            backgroundColor: 'rgba(0,0,0,0.85)',
            borderColor: '#333',
            textStyle: { color: '#fff' },
            formatter: (params: any) => {
              const id = params[0].dataIndex;
              const ods = this.odsList[id];
              const iniciativas = this.iniciativasPorOds[ods.idOds] ?? [];
              return `
                <div style="font-weight:600; margin-bottom:5px;">${ods.nombre}</div>
                ${iniciativas.length > 0
                  ? iniciativas.map((i: string) => `• ${i}`).join('<br/>')
                  : '<span style="opacity: 0.6;">Sin iniciativas</span>'
                }
              `;
            }
          },
          grid: {
            left: 50,
            right: 20,
            bottom: 20,
            top: 10,
            containLabel: true
          },
          xAxis: {
            type: 'value',
            axisLine: { show: false },
            axisTick: { show: false },
            splitLine: { show: false },
            axisLabel: { color: '#aaa', fontSize: 11 }
          },
          yAxis: {
            type: 'category',
            data: yLabels,
            axisLabel: {
              formatter: (value: string) => `{img${value}| }`,
              rich: this.generarRich()
            },
            axisLine: { show: false },
            axisTick: { show: false }
          },
          series: [
            {
              type: 'bar',
              label: {
                show: true,
                position: 'right',
                color: '#fff',
                fontWeight: 500,
                fontSize: 13,
                formatter: '{c}'
              },
              barWidth: 18,
              data: seriesData,
              emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowColor: 'rgba(255,255,255,0.15)'
                }
              }
            }
          ]
        };

        this.cargando = false;
      },
      error: err => {
        console.error('Error cargando datos:', err);
        this.cargando = false;
      }
    });
  }

  getOdsColor(id: number): string {
    const colores: { [key: number]: string } = {
      1: '#E5243B', 2: '#DDA63A', 3: '#4C9F38', 4: '#C5192D', 5: '#FF3A21',
      6: '#26BDE2', 7: '#FCC30B', 8: '#A21942', 9: '#FD6925', 10: '#DD1367',
      11: '#FD9D24', 12: '#BF8B2E', 13: '#3F7E44', 14: '#0A97D9',
      15: '#56C02B', 16: '#00689D', 17: '#19486A'
    };
    return colores[id] || '#999';
  }

  generarRich() {
    const rich: any = {};
    this.odsList.forEach(ods => {
      rich[`img${ods.idOds}`] = {
        height: 20,
        width: 20,
        align: 'center',
        backgroundColor: {
          image: `/img/${ods.idOds}.png`
        }
      };
    });
    return rich;
  }
}
