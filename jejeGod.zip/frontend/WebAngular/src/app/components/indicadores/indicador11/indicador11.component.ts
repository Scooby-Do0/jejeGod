import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { IndicadorService } from '../../../services/indicadores.service';
import { CommonModule } from '@angular/common';
import { NgxEchartsModule } from 'ngx-echarts';

@Component({
  selector: 'app-indicador11',
  standalone: true,
  imports: [CommonModule, NgxEchartsModule],
  templateUrl: './indicador11.component.html',
  styleUrls: ['./indicador11.component.scss']
})
export class Indicador11Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: any = {};
  loading: boolean = false;
  totalIniciativas: number = 0;

  constructor(private indicadorService: IndicadorService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['curso'] && this.curso) {
      this.fetchData();
    }
  }

  fetchData(): void {
    this.loading = true;

    this.indicadorService.getIndicador(11, this.curso).subscribe(
      (data) => {
        const todas = data?.indicador11?.todas?.filter((i: any) => i.cursoAcademico === this.curso) || [];
        const innovadoras = data?.indicador11?.innovadoras?.filter((i: any) => i.cursoAcademico === this.curso) || [];
    
        this.totalIniciativas = todas.length;
    
        const innovadorasNombres = innovadoras.map((i: any) => i.nombre);
    
        // Calcular no innovadoras comparando por idiniciativa
        const noInnovadoras = todas.filter(
          (t: any) => !innovadoras.some((i: any) => i.idiniciativa === t.idiniciativa)
        );
        const noInnovadorasNombres = noInnovadoras.map((i: any) => i.nombre);
    
        const chartData = [
          {
            value: innovadoras.length,
            name: '✨ Innovadoras',
            iniciativas: innovadorasNombres
          },
          {
            value: noInnovadoras.length,
            name: '📄 No Innovadoras',
            iniciativas: noInnovadorasNombres.length ? noInnovadorasNombres : ['Sin iniciativas registradas']
          }
        ];
    
        this.chartOptions = {
          backgroundColor: 'transparent',
          color: ['#9333ea', '#fde047'],
          title: {
            left: 'center',
            textStyle: {
              color: '#ffffff',
              fontSize: 18,
              padding: [10, 0, 10, 0]
            }
          },
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => {
              const iniciativas = params.data.iniciativas.length
                ? params.data.iniciativas.join('<br/>• ')
                : 'Sin iniciativas registradas';
              return `
                <strong>${params.name}</strong><br/>
                • ${iniciativas}
              `;
            },
            textStyle: {
              color: '#333333'
            },
            backgroundColor: '#ffffff'
          },
          legend: {
            orient: 'vertical',
            left: 'left',
            bottom: 0,
            textStyle: {
              color: '#ffffff',
              padding: [10, 0, 0, 0]
            }
          },
          series: [
            {
              name: 'Iniciativas',
              type: 'pie',
              radius: ['50%', '70%'],
              avoidLabelOverlap: false,
              label: {
                show: true,
                position: 'outside',
                color: '#ffffff',
                formatter: '{b}: {c}'
              },
              labelLine: {
                show: true
              },
              data: chartData,
              emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              }
            }
          ]
        };
    
        this.loading = false;
      },
      (error) => {
        console.error('Error al cargar Indicador 11:', error);
        this.loading = false;
      }
    );
    
  }
}
