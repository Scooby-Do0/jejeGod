import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador11Component } from './indicador11.component';

describe('Indicador11Component', () => {
  let component: Indicador11Component;
  let fixture: ComponentFixture<Indicador11Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador11Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
