import { Component, Input, OnChanges } from '@angular/core';
import { IndicadorService } from '../../../services/indicadores.service';
import { CommonModule } from '@angular/common';
import { NgxEchartsModule } from 'ngx-echarts';

import * as echarts from 'echarts/core';
import { FunnelChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

echarts.use([
  FunnelChart,
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  CanvasRenderer
]);

@Component({
  selector: 'app-indicador13',
  standalone: true,
  imports: [CommonModule, NgxEchartsModule],
  templateUrl: './indicador13.component.html',
  styleUrls: ['./indicador13.component.scss']
})
export class Indicador13Component implements OnChanges {
  @Input() curso: string = '';
  chartOptions: any = {};
  loading: boolean = false;

  constructor(private indicadorService: IndicadorService) {}

  ngOnChanges(): void {
    if (this.curso) this.fetchData();
  }

  fetchData(): void {
    this.loading = true;

    this.indicadorService.getIndicador(13, this.curso).subscribe({
      next: (response) => {
        const iniciativas = response?.indicador13?.[this.curso] ?? [];
        const contador: Record<string, { count: number; titulos: string[] }> = {};
        let total = 0;

        for (const item of iniciativas) {
          const tipo = item.requeridos?.trim().toLowerCase();
          if (!tipo) continue;
          if (!contador[tipo]) contador[tipo] = { count: 0, titulos: [] };

          contador[tipo].count++;
          contador[tipo].titulos.push(item.nombre);
          total++;
        }

        const chartData = Object.entries(contador).map(([tipo, { count, titulos }]) => {
          const porcentaje = parseFloat(((count / total) * 100).toFixed(1));
          const plural = tipo.endsWith('a') ? tipo + 's' : tipo + 'es';
          const capitalizado = plural.charAt(0).toUpperCase() + plural.slice(1);
          return {
            name: capitalizado,
            value: porcentaje,
            titulos
          };
        });

        this.chartOptions = {
          backgroundColor: 'transparent',
          tooltip: {
            trigger: 'item',
            formatter: (params: any) => {
              const data = chartData.find(d => d.name === params.name);
              if (!data) return '';

              const lista = data.titulos.length > 0
                ? `<ul style="margin:0;padding-left:1.2em;max-width:260px;">
                    ${data.titulos.map(t => {
                      const trunc = t.length > 40 ? t.slice(0, 40) + '…' : t;
                      return `<li title="${t}">${trunc}</li>`;
                    }).join('')}
                   </ul>`
                : '<em>Sin iniciativas</em>';

              return `<strong>${params.name}</strong><br>${data.value}% del total<br>${lista}`;
            }
          },
          legend: {
            orient: 'vertical',
            left: 'left',
            textStyle: {
              color: '#fff',
              fontSize: 14
            }
          },
          series: [
            {
              name: 'Acciones requeridas',
              type: 'funnel',
              left: '10%',
              top: 60,
              bottom: 60,
              width: '80%',
              sort: 'descending',
              gap: 8,
              label: {
                show: true,
                position: 'inside',
                color: '#ffffff',
                fontSize: 14,
                fontWeight: 'bold',
                formatter: '{c}%'
              },
              labelLine: {
                length: 10,
                lineStyle: {
                  width: 1,
                  type: 'solid',
                  color: '#aaa'
                }
              },
              itemStyle: {
                borderColor: '#fff',
                borderWidth: 1,
                shadowBlur: 10,
                shadowColor: 'rgba(0, 0, 0, 0.3)'
              },
              emphasis: {
                label: {
                  fontSize: 18,
                  color: '#ffffff'
                }
              },
              data: chartData
            }
          ]
        };

        this.loading = false;
      },
      error: (err) => {
        console.error('Error al cargar Indicador 13:', err);
        this.loading = false;
      }
    });
  }
}
