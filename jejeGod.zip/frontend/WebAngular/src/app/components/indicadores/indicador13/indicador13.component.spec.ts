import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Indicador13Component } from './indicador13.component';

describe('Indicador13Component', () => {
  let component: Indicador13Component;
  let fixture: ComponentFixture<Indicador13Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Indicador13Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Indicador13Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
