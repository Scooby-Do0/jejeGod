import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { getAuth, signOut, User } from 'firebase/auth';
import { firebaseAuth } from '../../../guards/firebase-init';
@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.scss'
})
export class MenuComponent {
  links = [
    { path: '/iniciativa', label: 'Inicio' },
    { path: '/indicadores', label: 'Indicadores' }
  ];

  usuario: User | null = null;
  dropdownOpen: boolean = false;

  constructor(private router: Router) {
    const stored = localStorage.getItem('usuario');
    if (stored) {
      const datos = JSON.parse(stored);
      this.usuario = {
        displayName: datos.nombre,
        email: datos.email,
        photoURL: datos.photoURL ?? '/img/default-user.png',
      } as User;
    }

  }

  toggleDropdown(): void {
    this.dropdownOpen = !this.dropdownOpen;
  }

  logout(): void {
    signOut(firebaseAuth).then(() => {
      localStorage.removeItem('usuario');
      this.usuario = null;
      this.router.navigate(['/login']);
    }).catch(error => {
      console.error('Error al cerrar sesión:', error);
      alert('Error al cerrar sesión. Intenta de nuevo.');
    });
  }

}
