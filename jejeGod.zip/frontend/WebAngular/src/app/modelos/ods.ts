import { Meta } from "./meta";

export interface Ods {
    idOds: number;
    nombre: string;
    descripcion: string;
    metas: Meta[];
}
