export interface Meta {
    idMeta: string;
    descripcion: string;
}
