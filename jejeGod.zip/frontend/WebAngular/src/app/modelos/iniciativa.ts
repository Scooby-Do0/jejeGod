import { Ciclo } from "./ciclo";
import { DifusionIniciativa } from "./difusion-iniciativa";
import { EntidadExterna } from "./entidad-externa";
import { Ods } from "./ods";
import { Profesor } from "./profesor";

export interface Iniciativa {
    id: number;
    nombre: string;
    descripcion: string;
    curso: string;
    fecha_Inicio: Date;
    fecha_Fin: Date | null;
    tipo_Iniciativa: string;
    innovadora: boolean;
    horas: number;
    dimensiones: string[];
    difusionLista: DifusionIniciativa[];
    entidadesLista: EntidadExterna[];
    odsLista: Ods[];
    profesoresLista: Profesor[];
    ciclosLista: Ciclo[];
    _animState?: 'visible' | 'removing';

}
