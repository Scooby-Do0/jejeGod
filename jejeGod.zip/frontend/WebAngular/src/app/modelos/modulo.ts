export interface Modulo {
    idModulo: number;
    nombre: string;
}
