export interface Profesor {
    idProfesor: number;
    nombre: string;
}
