import { Modulo } from "./modulo";

export interface Ciclo {
    idCiclo: number;
    nombreCiclo: string;
    modulos: Modulo[];
}
