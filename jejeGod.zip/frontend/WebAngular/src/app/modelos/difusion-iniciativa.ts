export interface DifusionIniciativa {
    iddifusion: number;
    tipo: string;
    enlace: string;
}
