export interface EntidadExterna {
    identidad: number;
    nombre: string;
}
