import { Ionicons } from '@expo/vector-icons'
import { Text, TouchableOpacity, TouchableOpacityProps } from 'react-native'

interface Props extends TouchableOpacityProps {
    className?: string;
    children: string;
}

const MenuDropdown = ({ className, children, ...rest }: Props) => {
    return (
        <TouchableOpacity
            className={`p-3 mx-1 bg-blue-800 rounded-full flex-row justify-center items-center ${className}`}
            activeOpacity={0.7}
            {...rest}
        >
            <Text
                className='text-white font-bold'
            >
                {children}
            </Text>
            <Ionicons name='chevron-down-outline' size={20} color='white' />
        </TouchableOpacity>
    )
}

export default MenuDropdown