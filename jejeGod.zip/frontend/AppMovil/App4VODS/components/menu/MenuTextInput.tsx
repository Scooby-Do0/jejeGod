import { TextInputProps, TextInput, View } from 'react-native'
import { Ionicons } from '@expo/vector-icons';

interface Props extends TextInputProps {
    className?: string;
}

const MenuTextInput = ({ className, ...rest }: Props) => {
    return (
        <View className="pr-3 bg-indigo-400 rounded-full flex-row items-center justify-around">
            <TextInput
                className={`text-white text-2xl w-[280px] py-6 pl-6 ${className}`}
                placeholderTextColor="white"
                placeholder="Buscar iniciativas..."
                {...rest}
            />
            <Ionicons name='search-outline' size={24} color={'white'} />
        </View>
    )
}

export default MenuTextInput