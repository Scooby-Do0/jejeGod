import { Text, TextProps, View } from 'react-native'

interface Props extends TextProps {
    children: string;
    className?: string;
}

const DataHeader = ({ className, children, ...rest }: Props) => {
    return (
        <View className='py-2 mt-4 mb-1 bg-sky-400 rounded-full'>
            <Text className={`text-white font-bold text-center text-xl ${className}`} {...rest}>
                {children}
            </Text>
        </View>
    )
}

export default DataHeader