import { initializeApp } from 'firebase/app';
import { getAuth } from "firebase/auth";

// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyA2KIXWKfh_ZXXGD_UCEuWZks0HGhF_y6I",
    authDomain: "proyecto4vods-8679e.firebaseapp.com",
    projectId: "proyecto4vods-8679e",
    storageBucket: "proyecto4vods-8679e.firebasestorage.app",
    messagingSenderId: "769704058547",
    appId: "1:769704058547:web:b75bf09097b6e0670a9ac6"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
// For more information on how to access Firebase in your project,
// see the Firebase documentation: https://firebase.google.com/docs/web/setup#access-firebase
