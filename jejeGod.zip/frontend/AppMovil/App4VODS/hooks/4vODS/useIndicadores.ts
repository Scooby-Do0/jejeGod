import { getIndicador10Action } from "@/core/actions/get-indicador-10.action";
import { getIndicador11Action } from "@/core/actions/get-indicador-11.action";
import { getIndicador12Action } from "@/core/actions/get-indicador-12.action";
import { getIndicador13Action } from "@/core/actions/get-indicador-13.action";
import { getIndicador2Action } from "@/core/actions/get-indicador-2.action";
import { getIndicador3Action } from "@/core/actions/get-indicador-3.action";
import { getIndicador4Action } from "@/core/actions/get-indicador-4.action";
import { getIndicador5Action } from "@/core/actions/get-indicador-5.action";
import { getIndicador6Action } from "@/core/actions/get-indicador-6.action";
import { getIndicador7Action } from "@/core/actions/get-indicador-7.action";
import { getIndicador8Action } from "@/core/actions/get-indicador-8.action";
import { getIndicador9Action } from "@/core/actions/get-indicador-9.action";
import { useQuery } from "@tanstack/react-query";

export const indicador2Query = (curso: string) => useQuery({
    queryKey: ["indicador2", "getIndicador2"],
    queryFn: () => getIndicador2Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador3Query = (curso: string) => useQuery({
    queryKey: ["indicador3", "getIndicador3"],
    queryFn: () => getIndicador3Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador4Query = (curso: string) => useQuery({
    queryKey: ["indicador4", "getIndicador4"],
    queryFn: () => getIndicador4Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador5Query = (curso: string) => useQuery({
    queryKey: ["indicador5", "getIndicador5"],
    queryFn: () => getIndicador5Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador6Query = (curso: string) => useQuery({
    queryKey: ["indicador6", "getIndicador6"],
    queryFn: () => getIndicador6Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador7Query = (curso: string) => useQuery({
    queryKey: ["indicador7", "getIndicador7"],
    queryFn: () => getIndicador7Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador8Query = (curso: string) => useQuery({
    queryKey: ["indicador8", "getIndicador8"],
    queryFn: () => getIndicador8Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador9Query = (curso: string) => useQuery({
    queryKey: ["indicador9", "getIndicador9"],
    queryFn: () => getIndicador9Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador10Query = (curso: string) => useQuery({
    queryKey: ["indicador10", "getIndicador10"],
    queryFn: () => getIndicador10Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador11Query = (curso: string) => useQuery({
    queryKey: ["indicador11", "getIndicador11"],
    queryFn: () => getIndicador11Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador12Query = (curso: string) => useQuery({
    queryKey: ["indicador12", "getIndicador12"],
    queryFn: () => getIndicador12Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});

export const indicador13Query = (curso: string) => useQuery({
    queryKey: ["indicador13", "getIndicador13"],
    queryFn: () => getIndicador13Action(curso),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
});