import { getIniciativasAction } from "@/core/actions/get-iniciativas.action";
import { useQuery } from "@tanstack/react-query";

export const useIniciativas = () => {
  const iniciativasQuery = useQuery({
    queryKey: ["iniciativas", "getIniciativas"],
    queryFn: () => getIniciativasAction(),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
  });

  return {
    iniciativasQuery,
  };
};
