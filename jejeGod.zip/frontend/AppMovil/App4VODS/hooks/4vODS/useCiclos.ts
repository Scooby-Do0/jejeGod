import { getCiclosAction } from "@/core/actions/get-ciclos.action";
import { useQuery } from "@tanstack/react-query";

export const useCiclos = () => {
  const ciclosQuery = useQuery({
    queryKey: ["ciclos", "getCiclos"],
    queryFn: () => getCiclosAction(),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
  });

  return {
    ciclosQuery,
  };
};
