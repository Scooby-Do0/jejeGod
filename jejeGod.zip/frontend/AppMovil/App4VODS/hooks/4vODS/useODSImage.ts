
const images: { [key: number]: any } = {
    1: require('../../assets/images/imagesForODSs/1.png'),
    2: require('../../assets/images/imagesForODSs/2.png'),
    3: require('../../assets/images/imagesForODSs/3.png'),
    4: require('../../assets/images/imagesForODSs/4.png'),
    5: require('../../assets/images/imagesForODSs/5.png'),
    6: require('../../assets/images/imagesForODSs/6.png'),
    7: require('../../assets/images/imagesForODSs/7.png'),
    8: require('../../assets/images/imagesForODSs/8.png'),
    9: require('../../assets/images/imagesForODSs/9.png'),
    10: require('../../assets/images/imagesForODSs/10.png'),
    11: require('../../assets/images/imagesForODSs/11.png'),
    12: require('../../assets/images/imagesForODSs/12.png'),
    13: require('../../assets/images/imagesForODSs/13.png'),
    14: require('../../assets/images/imagesForODSs/14.png'),
    15: require('../../assets/images/imagesForODSs/15.png'),
    16: require('../../assets/images/imagesForODSs/16.png'),
    17: require('../../assets/images/imagesForODSs/17.png'),
};

export const useODSImage = (idODS: number) => {
    return images[idODS];
}