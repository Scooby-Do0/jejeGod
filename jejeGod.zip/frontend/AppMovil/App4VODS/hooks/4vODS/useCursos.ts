import { getCursosAction } from "@/core/actions/get-cursos.action";
import { useQuery } from "@tanstack/react-query";

export const useCursos = () => {
    const cursosQuery = useQuery({
        queryKey: ["cursos", "getCursos"],
        queryFn: () => getCursosAction(),
        staleTime: 1000 * 60 * 60 * 24, // 24 horas
    });

    return {
        cursosQuery,
    };
};
