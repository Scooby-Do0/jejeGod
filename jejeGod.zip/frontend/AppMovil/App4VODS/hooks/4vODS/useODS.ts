import { getODSAction } from "@/core/actions/get-ODS.action";
import { useQuery } from "@tanstack/react-query";

export const useODS = () => {
  const ODSQuery = useQuery({
    queryKey: ["ODS", "getODS"],
    queryFn: () => getODSAction(),
    staleTime: 1000 * 60 * 60 * 24, // 24 horas
  });

  return {
    ODSQuery,
  };
};
