# APP MÓVIL – ODSALos4Vientos

Esta aplicación representa la versión móvil de la plataforma ODSALos4Vientos, desarrollada con **React Native y Expo**. Permite visualizar y gestionar las iniciativas desde dispositivos Android, ya sea en emulador o físico.

---


## UTILIZAR APK YA CREADA POR NOSOTROS

1. Desde el dispositivo Android, accede al siguiente enlace: [Descargar APK](https://drive.google.com/drive/folders/14U_VStyoL8pbfnEjqz0RpoEsTgdH4dEO?usp=drive_link)

2. Descarga el archivo `.apk`.

3. Ábrelo desde el explorador de archivos y procede a instalar la app.

4. Una vez instalada, busca el icono en tu dispositivo y ejecútala.

---

## MATERIALES NECESARIOS PARA INICIAR LA APLICACIÓN

1. Android Studio con un **dispositivo emulado funcional**
   
> [!WARNING]
> Antes de ejecutar la aplicación móvil, **es imprescindible que el backend esté en funcionamiento**.  
> Asegúrate de seguir estos pasos del README principal para activar correctamente el backend:  
> [Pasos para activar el backend](https://github.com/JulenMO/ODSALos4Vientos#Requisitos-para-ejecutar-la-API)

---

## MATERIALES RECOMENDADOS

1. Editor de código, preferiblemente **Visual Studio Code**
2. Extensiones útiles:
   - *Paste JSON as Code*
   - *VS Code ES7+ React/Redux/React-Native/JS snippets*
   - *Tailwind CSS Intellisense*
   - *Simple React Snippets*

---

## INICIAR LA APP EN EMULADOR

1. Abre una terminal y entra en la carpeta de la app móvil:

```
ODSALos4Vientos/frontend/AppMovil/App4VODS
```

2. Instala las dependencias:

```bash
bun i    # npm install
```

3. Asegúrate de que la base de datos esté creada correctamente y el Backend este en funcionamiento: [Pasos para ejecutar la API](https://github.com/JulenMO/ODSALos4Vientos#Requisitos-para-ejecutar-la-API)

> [!NOTE]
> Es recomendable encender manualmente el dispositivo emulado en Android Studio para evitar problemas o lentitud en los siguientes pasos, pero no es necesario.

4. Ejecuta el comando de inicio con tu package manager:

```bash
bun start -c     # npx expo start -c
```

> [!NOTE]
> La opción `-c` limpia el caché y puede evitar errores de carga.

5. Cuando se abra el servidor de desarrollo de Expo en la terminal, presiona la tecla `a`  
   Esto ejecutará la app en el emulador (si está apagado, intentará encenderlo automáticamente).

> [!NOTE]
> Si es la primera vez que usas Expo en ese emulador, se instalará **Expo Go** automáticamente. Puede tardar unos minutos.

> [!TIP]
> Si la app no carga correctamente, puedes:
>   - Pulsar la tecla `r` para recargar la app.
>   - Cerrar la app en el dispositivo/emulador y volver a lanzarla con `a`.

---

## INICIAR LA APP EN DISPOSITIVO FÍSICO

Sigue los pasos del `1` al `4` de la sección anterior, luego:

1. Abre el archivo `core/api/cuatrovientos-api.ts`  
   Sustituye la URL por la correspondiente a la IP local del backend (comentado dentro del archivo).

2. Instala **Expo Go** desde la Play Store.

3. Asegúrate de que el dispositivo esté conectado a la misma red que el PC.

4. En Expo Go, selecciona **"Scan QR code"** y escanea el **código QR** mostrado en la terminal.

---

## CREAR APK (CON LA VERSIÓN DEL CÓDIGO QUE TENGAS ACTUALMENTE)

1. Crea la prebuild del proyecto:

```bash
bun expo prebuild     # npx expo prebuild
```

2. Regístrate en [expo.dev](https://expo.dev) y recuerda el usuario y contraseña para siguientes pasos.

3. Instala **EAS CLI**:

```bash
bun install --global eas-cli     # npm install --global eas-cli
```

4. Inicia sesión con tu usuario y contraseña:

```bash
eas login
```

> Introduce tu usuario y contraseña cuando lo solicite.

5. Lanza la build para Android:

```bash
bun run eas:android     # npm run eas:android
```

> [!NOTE]
> La terminal hará dos preguntas. Responde `y` (sí) a ambas.

6. Cuando la build finalice, ve a [expo.dev > Dashboard > Recent Activity](https://expo.dev/accounts)  
   Ahí podrás descargar el `.apk` desde los tres puntos verticales (no uses el botón azul "Install").

Ya puedes instalarlo y utilizarlo en cualquier dispositivo android

---


## TECNOLOGÍAS UTILIZADAS

- **React**
- **React Native**
- **Expo**
- **TypeScript**
- **Tailwind CSS**
- **Axios**
- **TanStack Query**
