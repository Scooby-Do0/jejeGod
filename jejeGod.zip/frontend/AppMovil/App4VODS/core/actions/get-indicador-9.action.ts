import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador9Response } from "../interfaces/indicador9/indicador9.response";

export const getIndicador9Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador9Response>(
            `/Indicadores/9/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 9.";
    }
};
