import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { CicloResponse } from "../interfaces/ciclos/ciclo.response";
import { fromDBToCiclo } from "../mappers/ciclo.mapper";

export const getCiclosAction = async () => {
  try {
    const { data } = await cuatrovientosApi.get<CicloResponse[]>(
      "/Entidades/ciclos"
    );
    return data.map(ciclo => fromDBToCiclo(ciclo));
  } catch (error) {
    console.log(error);
    throw "No se han podido cargar los ciclos.";
  }
};
