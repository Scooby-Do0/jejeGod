import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador7Response } from "../interfaces/indicador7/indicador7.response";

export const getIndicador7Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador7Response>(
            `/Indicadores/7/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 7.";
    }
};
