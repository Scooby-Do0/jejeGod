import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador13Response } from "../interfaces/indicador13/indicador13.response";

export const getIndicador13Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador13Response>(
            `/Indicadores/13/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 13.";
    }
};
