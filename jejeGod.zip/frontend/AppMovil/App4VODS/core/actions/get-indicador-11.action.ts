import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador11Response } from "../interfaces/indicador11/indicador11.response";

export const getIndicador11Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador11Response>(
            `/Indicadores/11/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 11.";
    }
};
