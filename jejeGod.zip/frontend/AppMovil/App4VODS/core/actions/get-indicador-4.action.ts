import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador4Response } from "../interfaces/indicador4/indicador4.response";

export const getIndicador4Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador4Response[]>(
            `/Indicadores/4/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 4.";
    }
};
