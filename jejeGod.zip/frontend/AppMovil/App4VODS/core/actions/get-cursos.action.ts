import { cuatrovientosApi } from "../api/cuatrovientos-api";

export const getCursosAction = async () => {
    try {
        const { data } = await cuatrovientosApi.get<string[]>(
            "/cursos"
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se han podido cargar los cursos.";
    }
};
