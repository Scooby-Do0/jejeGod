import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador1Response } from "../interfaces/indicador1/indicador1.response";

export const getIndicador1Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador1Response>(
            `/Indicadores/1/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 1.";
    }
};
