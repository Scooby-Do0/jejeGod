import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { ODSResponse } from "../interfaces/ODS/ODS.response";
import { fromDBToODS } from "../mappers/ODS.mapper";

export const getODSAction = async () => {
  try {
    const { data } = await cuatrovientosApi.get<ODSResponse[]>("/Entidades/ods");
    return data.map(ods => fromDBToODS(ods));
  } catch (error) {
    console.log(error);
    throw "No se han podido cargar los ODSs.";
  }
};
