import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { IniciativaResponse } from "../interfaces/iniciativas/iniciativa.response";
import { fromDBToIniciativa } from "../mappers/iniciativa.mapper";

export const getIniciativasAction = async () => {
  try {
    const { data } = await cuatrovientosApi.get<IniciativaResponse[]>(
      "/Cuatrovientos/iniciativas"
    );
    return data.map(iniciativa => fromDBToIniciativa(iniciativa));
  } catch (error) {
    console.log(error);
    throw "No se han podido cargar las iniciativas.";
  }
};
