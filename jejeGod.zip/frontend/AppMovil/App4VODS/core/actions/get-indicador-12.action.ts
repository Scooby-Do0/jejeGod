import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador12Response } from "../interfaces/indicador12/indicador12.response";

export const getIndicador12Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador12Response>(
            `/Indicadores/12/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 12.";
    }
};
