import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador6Response } from "../interfaces/indicador6/indicador6.response";

export const getIndicador6Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador6Response>(
            `/Indicadores/6/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 6.";
    }
};
