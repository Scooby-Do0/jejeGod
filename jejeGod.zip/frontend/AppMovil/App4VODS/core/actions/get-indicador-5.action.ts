import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador5Response } from "../interfaces/indicador5/indicador5.response";

export const getIndicador5Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador5Response>(
            `/Indicadores/5/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 5.";
    }
};
