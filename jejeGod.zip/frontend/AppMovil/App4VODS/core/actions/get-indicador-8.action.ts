import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador8Response } from "../interfaces/indicador8/indicador8.response";

export const getIndicador8Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador8Response>(
            `/Indicadores/8/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 8.";
    }
};
