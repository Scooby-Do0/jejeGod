import { cuatrovientosApi } from "../api/cuatrovientos-api";
import { Indicador10Response } from "../interfaces/indicador10/indicador10.response";

export const getIndicador10Action = async (curso: string) => {
    try {
        if (!curso || curso === "") return null;
        const { data } = await cuatrovientosApi.get<Indicador10Response>(
            `/Indicadores/10/${curso}`
        );
        return data;
    } catch (error) {
        console.log(error);
        throw "No se ha podido cargar la información del indicador 10.";
    }
};
