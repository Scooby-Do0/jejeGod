import { Iniciativa } from "../interfaces/iniciativas/iniciativa.interface";
import { IniciativaResponse } from "../interfaces/iniciativas/iniciativa.response";
import { fromDBToCiclo } from "./ciclo.mapper";
import { fromDBToODS } from "./ODS.mapper";

export function fromDBToIniciativa(iniciativa: IniciativaResponse): Iniciativa {
    return {
        idiniciativa: iniciativa.id,
        titulo: iniciativa.nombre,
        descripcion: iniciativa.descripcion,
        tipoIniciativa: iniciativa.tipo_Iniciativa,
        ciclosLista: iniciativa.ciclosLista.map(ciclo => fromDBToCiclo(ciclo)),
        odsLista: iniciativa.odsLista.map(ods => fromDBToODS(ods)),
    };
}