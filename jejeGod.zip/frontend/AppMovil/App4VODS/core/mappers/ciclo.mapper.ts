import { Ciclo } from "../interfaces/ciclos/ciclo.interface";
import { CicloResponse } from "../interfaces/ciclos/ciclo.response";

export function fromDBToCiclo(ciclo: CicloResponse): Ciclo {
  return {
    idCiclo: ciclo.idCiclo,
    nombre: ciclo.nombreCiclo,
  };
}
