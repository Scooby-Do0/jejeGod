import { ODS } from "../interfaces/ODS/ODS.interface";
import { ODSResponse } from "../interfaces/ODS/ODS.response";

export function fromDBToODS(ods: ODSResponse): ODS {
  return {
    idODS: ods.idOds,
    nombre: ods.nombre,
  };
}
