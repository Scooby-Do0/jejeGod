import axios from "axios";
import * as Device from "expo-device";

let apiURL = 'http://192.168.1.139:5236'; // URL de la API por defecto, cambiar en caso de llamar a otra API

// Detecta si el dispositivo es un emulador y ajusta la URL
if (!Device.isDevice) {
    apiURL = 'http://10.0.2.2:5236'; // URL para emuladores
}

// Crea la instancia de Axios con la URL
export const cuatrovientosApi = axios.create({
    baseURL: apiURL,
});