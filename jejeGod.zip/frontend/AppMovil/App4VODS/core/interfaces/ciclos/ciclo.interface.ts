export interface Ciclo {
  idCiclo: number;
  nombre: string;
}
