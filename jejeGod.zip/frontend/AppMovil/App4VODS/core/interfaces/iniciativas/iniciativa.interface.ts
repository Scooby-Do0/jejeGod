import { Ciclo } from "../ciclos/ciclo.interface";
import { ODS } from "../ODS/ODS.interface";

export interface Iniciativa {
    idiniciativa: number;
    titulo: string;
    descripcion: string;
    tipoIniciativa: string;
    ciclosLista: Ciclo[];
    odsLista: ODS[];
}