export interface ODS {
  idODS: number;
  nombre: string;
}
