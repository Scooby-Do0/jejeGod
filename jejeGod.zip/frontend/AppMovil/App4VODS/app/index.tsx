import { useEffect, useState } from "react";
import { GoogleSignin, GoogleSigninButton, SignInResponse } from '@react-native-google-signin/google-signin';
import { StatusBar, Text, TouchableOpacity, View } from "react-native";

export default function LoginScreen() {
    const [error, setError] = useState<unknown>();
    const [userInfo, setUserInfo] = useState<SignInResponse | undefined>();

    useEffect(() => {
        GoogleSignin.configure({
            webClientId: '441664604534-aj3028jq4p6j53u8acrdf8r8op2590re.apps.googleusercontent.com',
        });
    }, [])

    const signin = async () => {
        try {
            await GoogleSignin.hasPlayServices();
            const user = await GoogleSignin.signIn();
            setUserInfo(user);
        } catch (e) {
            setError(e);
        }
    }

    const logout = () => {
        setUserInfo(undefined);
        GoogleSignin.revokeAccess();
        GoogleSignin.signOut();
    }

    return (
        <View className="flex-1 items-center justify-center bg-white">
            <Text>{JSON.stringify(error)}</Text>
            {userInfo && <Text>{JSON.stringify(userInfo.data)}</Text>}
            {userInfo ? <TouchableOpacity onPress={logout}>Logout</TouchableOpacity> : <GoogleSigninButton size={GoogleSigninButton.Size.Standard} color={GoogleSigninButton.Color.Dark} onPress={signin} />}
            <StatusBar barStyle="default" />
        </View>
    );
}