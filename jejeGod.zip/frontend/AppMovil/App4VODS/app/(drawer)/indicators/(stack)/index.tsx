import { useCursos } from '@/hooks/4vODS/useCursos';
import { getIndicador1Action } from '@/core/actions/get-indicador-1.action';
import { Picker } from '@react-native-picker/picker';
import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { Indicador1Response } from '@/core/interfaces/indicador1/indicador1.response';
import { indicador10Query, indicador11Query, indicador12Query, indicador13Query, indicador2Query, indicador3Query, indicador4Query, indicador5Query, indicador6Query, indicador7Query, indicador8Query, indicador9Query } from '@/hooks/4vODS/useIndicadores';

const IndicatorScreen = () => {
    const { cursosQuery } = useCursos();

    const [showIndicador1, setShowIndicador1] = useState(false);
    const [showIndicador1Info, setShowIndicador1Info] = useState(false);
    const [filtroIndicador1, setFiltroIndicador1] = useState('');
    const [indicador1Data, setIndicador1Data] = useState<Indicador1Response | null>(null);

    const [showIndicador2, setShowIndicador2] = useState(false);
    const indicador2 = indicador2Query('2024-2025').data;

    const [showIndicador3, setShowIndicador3] = useState(false);
    const indicador3 = indicador3Query('2024-2025').data;

    const [showIndicador4, setShowIndicador4] = useState(false);
    const indicador4 = indicador4Query('2024-2025').data;

    const [showIndicador5, setShowIndicador5] = useState(false);
    const indicador5 = indicador5Query('2024-2025').data;

    const [showIndicador6, setShowIndicador6] = useState(false);
    const indicador6 = indicador6Query('2024-2025').data;

    const [showIndicador7, setShowIndicador7] = useState(false);
    const indicador7 = indicador7Query('2024-2025').data;

    const [showIndicador8, setShowIndicador8] = useState(false);
    const indicador8 = indicador8Query('2024-2025').data?.indicador8;

    const [showIndicador9, setShowIndicador9] = useState(false);
    const indicador9 = indicador9Query('2024-2025').data?.indicador9;

    const [showIndicador10, setShowIndicador10] = useState(false);
    const indicador10 = indicador10Query('2024-2025').data;

    const [showIndicador11, setShowIndicador11] = useState(false);
    const indicador11 = indicador11Query('2024-2025').data?.indicador11;

    const [showIndicador12, setShowIndicador12] = useState(false);
    const indicador12 = indicador12Query('2024-2025').data?.indicador12;

    const [showIndicador13, setShowIndicador13] = useState(false);
    const indicador13 = indicador13Query('2024-2025').data;

    const fetchIndicador1Data = async () => {
        if (!filtroIndicador1) {
            setIndicador1Data(null);
            return;
        }

        try {
            const data = await getIndicador1Action(filtroIndicador1);
            setIndicador1Data(data);
        } catch (error) {
            setIndicador1Data(null);
        }
    };

    useEffect(() => {
        setShowIndicador1Info(false);
    }, [filtroIndicador1]);

    return (
        <ScrollView className='flex-1 p-2 mb-1'>
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    1. Iniciativas se han realizado dirigidas a los ODS por curso académico
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador1(!showIndicador1);
                        if (!showIndicador1) {
                            setShowIndicador1Info(false);
                            setIndicador1Data(null);
                        }
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador1 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador1 && (
                    <View className="mx-1">
                        <View className='flex-row justify-around items-center mb-2'>
                            <View>
                                <Text className="text-center text-white text-xl font-semibold">
                                    Seleccionar curso
                                </Text>
                                <View className="bg-indigo-700 rounded-full">
                                    <Picker
                                        style={{ color: 'white' }}
                                        dropdownIconColor={'white'}
                                        selectedValue={filtroIndicador1}
                                        onValueChange={(itemValue) => setFiltroIndicador1(itemValue)}
                                        prompt="Seleccionar curso"
                                    >
                                        <Picker.Item label='Ninguno' value='' key='Ninguno' />
                                        {cursosQuery.data &&
                                            cursosQuery.data.map((item) => (
                                                <Picker.Item label={item} value={item} key={item} />
                                            ))}
                                    </Picker>
                                </View>
                            </View>
                            <TouchableOpacity
                                className='bg-indigo-900 rounded-lg p-3'
                                activeOpacity={0.7}
                                onPress={async () => {
                                    setShowIndicador1Info(!showIndicador1Info);
                                    if (!showIndicador1Info) {
                                        await fetchIndicador1Data();
                                    } else {
                                        setIndicador1Data(null);
                                    }
                                }}
                            >
                                <Text className="text-white text-center font-semibold text-lg">
                                    {showIndicador1Info ? "OCULTAR INFORMACIÓN" : "VER INFORMACIÓN"}
                                </Text>
                            </TouchableOpacity>
                        </View>
                        {showIndicador1Info && indicador1Data && (
                            <View className="mt-3">
                                {indicador1Data.indicador1.map((item, index) => (
                                    <View
                                        key={index}
                                        className="bg-indigo-800 rounded-lg p-3 mb-2"
                                    >
                                        <Text className="text-white font-bold text-lg">
                                            ODS: {item.ods}
                                        </Text>
                                        <Text className="text-white mt-2">
                                            Iniciativas:
                                        </Text>
                                        {item.iniciativas.map((iniciativa, i) => (
                                            <Text key={i} className="text-white ml-2">
                                                - {iniciativa}
                                            </Text>
                                        ))}
                                    </View>
                                ))}
                            </View>
                        )}
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    2. Número actual de iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador2(!showIndicador2);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador2 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador2 && (
                    <View className="mx-1">
                        <View className='flex-row justify-around items-center mb-3'>
                            <Text className='text-white text-xl font-semibold'>
                                Número actual de iniciativas/acciones:
                            </Text>
                            <Text className='bg-indigo-700 rounded-full px-3 py-1 text-white text-2xl font-semibold'>
                                {indicador2 && indicador2.toString()}
                            </Text>
                        </View>
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    3. Cursos y módulos en los que se han realizado iniciativas
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador3(!showIndicador3);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador3 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador3 && indicador3 && (
                    <View className="mt-3">
                        {indicador3.indicador3.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Ciclo: {item.ciclo}
                                </Text>
                                <Text className="text-white mt-2">
                                    Módulos:
                                </Text>
                                {item.modulos.map((modulo, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {modulo}
                                    </Text>
                                ))}
                                <Text className="text-white mt-2">
                                    Iniciativas:
                                </Text>
                                {item.iniciativas.map((iniciativa, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {iniciativa}
                                    </Text>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    4. Descripción de las iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador4(!showIndicador4);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador4 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador4 && indicador4 && (
                    <View className="mt-3">
                        {indicador4.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Nombre: {item.nombre}
                                </Text>
                                <Text className="text-white mt-2 text-justify">
                                    Descripción: {item.descripcion}
                                </Text>
                            </View>
                        ))}
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    5. ODS y metas a los que van dirigidas las iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador5(!showIndicador5);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador5 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador5 && indicador5 && (
                    <View className="mt-3">
                        {indicador5.indicador5.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    ODS: {item.ods}
                                </Text>
                                <Text className="text-white mt-2">
                                    Metas:
                                </Text>
                                {item.metas.map((meta, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {meta}
                                    </Text>
                                ))}
                                <Text className="text-white mt-2">
                                    Iniciativas:
                                </Text>
                                {item.iniciativas.map((iniciativa, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {iniciativa}
                                    </Text>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    6. Entidades externas involucradas en iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador6(!showIndicador6);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador6 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador6 && indicador6 && (
                    <View className="mt-3">
                        {indicador6.indicador6.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Iniciativa: {item.iniciativa}
                                </Text>
                                <Text className="text-white mt-2">
                                    Entidades Externas:
                                </Text>
                                {item.entidadesExternas.map((entidad, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {entidad}
                                    </Text>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </View>

            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    7. Iniciativas/acciones que se han difundido
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador7(!showIndicador7);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador7 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador7 && indicador7 && (
                    <View className="mt-3">
                        {indicador7.indicador7.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Iniciativa: {item.iniciativa}
                                </Text>
                                <Text className="text-white mt-2">
                                    Difusiones:
                                </Text>
                                {item.difusiones.map((difusion, i) => (
                                    <Text key={i} className="text-white ml-2">
                                        - {difusion.tipo}: {difusion.enlace}
                                    </Text>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </View>
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    8. Proyectos y charlas/talleres realizados
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador8(!showIndicador8);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador8 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador8 && indicador8 && (
                    <View className="mt-3">
                        <View className="bg-indigo-800 rounded-lg p-3 mb-2">
                            <Text className="text-white font-bold text-lg">
                                Proyectos: {indicador8.proyectos.cantidad}
                            </Text>
                            <Text className="text-white font-bold text-lg">
                                Charlas/Talleres: {indicador8.charlaTaller.cantidad}
                            </Text>
                        </View>
                    </View>
                )}
            </View>

            {/* Indicador 9 */}
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    9. Cantidad de ODS a los que se contribuye por cada dimensión
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador9(!showIndicador9);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador9 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador9 && indicador9 && (
                    <View className="mt-3">
                        <View className="bg-indigo-800 rounded-lg p-3 mb-2">
                            <Text className="text-white font-bold text-lg">
                                Dimensión Social: {indicador9.social.length}
                            </Text>
                            <Text className="text-white font-bold text-lg">
                                Dimensión Económica: {indicador9.economica.length}
                            </Text>
                            <Text className="text-white font-bold text-lg">
                                Dimensión Medioambiental: {indicador9.medioambiental.length}
                            </Text>
                        </View>
                    </View>
                )}
            </View>

            {/* Indicador 10 */}
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    10. Personal involucrado en iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador10(!showIndicador10);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador10 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador10 && indicador10 && (
                    <View className="mt-3">
                        {indicador10.indicador10.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Iniciativa: {item.iniciativa}
                                </Text>
                                <Text className="text-white mt-2">
                                    Profesores/trabajadores: {item.numeroProfesores}
                                </Text>
                            </View>
                        ))}
                    </View>
                )}
            </View>

            {/* Indicador 11 */}
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    11. Innovación en iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador11(!showIndicador11);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador11 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador11 && indicador11 && (
                    <View className="mt-3">
                        <View className="bg-indigo-800 rounded-lg p-3 mb-2">
                            <Text className="text-white font-bold text-lg">
                                Modificación Importante: {indicador11.modificacionImportante}
                            </Text>
                        </View>
                    </View>
                )}
            </View>

            {/* Indicador 12 */}
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    12. Tiempo dedicado a iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador12(!showIndicador12);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador12 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador12 && indicador12 && (
                    <View className="mt-3">
                        {indicador12.horasDeIniciativas.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Iniciativa: {item.iniciativa}
                                </Text>
                                <Text className="text-white mt-2">
                                    Horas: {item.horas}
                                </Text>
                            </View>
                        ))}
                    </View>
                )}
            </View>

            {/* Indicador 13 */}
            <View className="bg-blue-400 rounded-lg p-2 mb-2">
                <Text className='px-3 text-white font-bold text-justify text-xl'>
                    13. Requerimientos adicionales de las iniciativas/acciones
                </Text>
                <TouchableOpacity
                    className='bg-indigo-700 rounded-lg py-3 mt-3 mb-2'
                    onPress={() => {
                        setShowIndicador13(!showIndicador13);
                    }}
                    activeOpacity={0.7}
                >
                    <Text className="text-white text-center">
                        {showIndicador13 ? "OCULTAR INDICADOR" : "MOSTRAR INDICADOR"}
                    </Text>
                </TouchableOpacity>
                {showIndicador13 && indicador13 && (
                    <View className="mt-3">
                        {indicador13.indicador13.map((item, index) => (
                            <View
                                key={index}
                                className="bg-indigo-800 rounded-lg p-3 mb-2"
                            >
                                <Text className="text-white font-bold text-lg">
                                    Nombre: {item.nombre}
                                </Text>
                                <Text className="text-white mt-2">
                                    Requeridos: {item.requeridos.join(', ')}
                                </Text>
                            </View>
                        ))}
                    </View>
                )}
            </View>
        </ScrollView>
    );
};

export default IndicatorScreen;