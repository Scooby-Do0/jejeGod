import DataHeader from "@/components/menu/DataHeader";
import "@/global.css";
import { useIniciativas } from "@/hooks/4vODS/useIniciativas";
import { useODSImage } from "@/hooks/4vODS/useODSImage";
import { Redirect, useLocalSearchParams, useNavigation } from "expo-router";
import { useEffect } from "react";
import { View, Text, ScrollView, Image } from 'react-native';

const IniciativaScreen = () => {
    const { idiniciativa } = useLocalSearchParams();

    const navigation = useNavigation();

    const { iniciativasQuery } = useIniciativas();

    const iniciativa = iniciativasQuery.data?.find(i => `${i.idiniciativa}` === idiniciativa);

    useEffect(() => {
        navigation.setOptions({
            title: iniciativa?.titulo ?? 'Iniciativa',
        });
    }, [iniciativa]);

    if (!iniciativa) {
        return <Redirect href="/" />;
    }

    return (
        <View className="flex-1 items-center justify-center px-7">
            <ScrollView
                showsVerticalScrollIndicator={false}
                className="w-full"
            >
                <DataHeader>Título</DataHeader>
                <Text className="text-xl text-justify">
                    {iniciativa.titulo}
                </Text>
                <DataHeader>Tipo</DataHeader>
                <Text className="text-xl text-justify">
                    {iniciativa.tipoIniciativa}
                </Text>
                <DataHeader>Descripción</DataHeader>
                <Text className="text-xl text-justify">
                    {iniciativa.descripcion}
                </Text>
                <DataHeader>Cursos que participan</DataHeader>
                <View className="flex-row flex-wrap">
                    {iniciativa.ciclosLista.map((curso, index) => (
                        <View
                            key={index}
                            className="bg-green-200 rounded-full px-4 py-2 m-1"
                        >
                            <Text className="text-green-800 text-xl">
                                {curso.nombre}
                            </Text>
                        </View>
                    ))}
                </View>
                <DataHeader>ODSs a los que contribuye</DataHeader>
                <View className="flex-row flex-wrap justify-center">
                    {iniciativa.odsLista.map((ods, index) => (
                        <Image
                            className="size-20 m-2"
                            key={index}
                            source={useODSImage(ods.idODS)}
                        />
                    ))}
                </View>
            </ScrollView>
        </View>
    );
};

export default IniciativaScreen;