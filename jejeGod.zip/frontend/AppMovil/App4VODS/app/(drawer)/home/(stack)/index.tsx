import "@/global.css"
import MenuTextInput from '@/components/menu/MenuTextInput'
import { FlatList, Text, TouchableOpacity, View, Image } from "react-native"
import { useIniciativas } from "@/hooks/4vODS/useIniciativas"
import { useEffect, useState } from "react"
import { Picker } from '@react-native-picker/picker'
import { useODS } from "@/hooks/4vODS/useODS"
import { useCiclos } from "@/hooks/4vODS/useCiclos"
import { router } from "expo-router"
import { useODSImage } from "@/hooks/4vODS/useODSImage"

const App = () => {
    const { iniciativasQuery } = useIniciativas();
    const { ciclosQuery } = useCiclos();
    const { ODSQuery } = useODS();
    const tipos = ['Proyecto', 'Charla', 'Taller', 'Otro'];

    const [listData, setListData] = useState(iniciativasQuery.data || []);
    const [textoInput, setTextoInput] = useState('');
    const [filtroCiclo, setFiltroCiclo] = useState('');
    const [filtroTipo, setFiltroTipo] = useState('');
    const [filtroODS, setFiltroODS] = useState('');
    const [showFilters, setShowFilters] = useState(false);

    useEffect(() => {
        let filteredData = iniciativasQuery.data || [];

        if (textoInput.trim().length > 0) {
            filteredData = filteredData.filter(item => item.titulo.trim().toLowerCase().includes(textoInput.trim().toLowerCase()));
        }

        if (filtroCiclo.trim().length > 0) {
            filteredData = filteredData.filter(item =>
                item.ciclosLista.some(ciclo => ciclo.nombre.toLowerCase() === filtroCiclo.toLowerCase())
            );
        }

        if (filtroTipo.trim().length > 0) {
            filteredData = filteredData.filter(item => item.tipoIniciativa.toLowerCase() === filtroTipo.toLowerCase());
        }

        if (filtroODS.trim().length > 0) {
            filteredData = filteredData.filter(item =>
                item.odsLista.some(ODS => ODS.nombre.toLowerCase() === filtroODS.toLowerCase())
            );
        }

        setListData(filteredData);
    }, [textoInput, filtroCiclo, filtroTipo, filtroODS, iniciativasQuery.data]);

    return (
        <View>
            <View className="bg-indigo-800">
                <View className="p-2">
                    <TouchableOpacity
                        className={`bg-indigo-400 rounded-lg py-3 ${showFilters ? 'my-3' : ''}`}
                        onPress={() => setShowFilters(!showFilters)}
                        activeOpacity={0.7}
                    >
                        <Text className="text-white text-center">
                            {showFilters ? "OCULTAR FILTROS" : "MOSTRAR FILTROS"}
                        </Text>
                    </TouchableOpacity>
                    {showFilters && (
                        <View className="pt-2">
                            <MenuTextInput onChangeText={texto => setTextoInput(texto)} />
                            <View className="flex-row justify-around mt-1">
                                <View className="w-5/12">
                                    <Text className="text-center text-white">
                                        Filtro por ciclo
                                    </Text>
                                    <View
                                        className="bg-indigo-400 rounded-full"
                                    >
                                        <Picker
                                            style={{ color: 'white' }}
                                            dropdownIconColor={'white'}
                                            selectedValue={filtroCiclo}
                                            onValueChange={(itemValue) => setFiltroCiclo(itemValue)}
                                            prompt="Filtro por ciclo"
                                            className="text-white"
                                        >
                                            <Picker.Item label='Sin filtro' value='' key='Sin filtro' />
                                            {
                                                ciclosQuery.data && ciclosQuery.data.map(item => (
                                                    <Picker.Item label={item.nombre} value={item.nombre} key={item.nombre} />
                                                ))
                                            }
                                        </Picker>
                                    </View>
                                </View>
                                <View className="w-5/12">
                                    <Text className="text-center text-white">
                                        Filtro por tipo
                                    </Text>
                                    <View
                                        className="bg-indigo-400 rounded-full"
                                    >
                                        <Picker
                                            style={{ color: 'white' }}
                                            dropdownIconColor={'white'}
                                            selectedValue={filtroTipo}
                                            onValueChange={(itemValue) => setFiltroTipo(itemValue)}
                                            prompt="Filtro por tipo"
                                        >
                                            <Picker.Item label='Sin filtro' value='' key='Sin filtro' />
                                            {
                                                tipos && tipos.map(item => (
                                                    <Picker.Item label={item} value={item} key={item} />
                                                ))
                                            }
                                        </Picker>
                                    </View>
                                </View>
                            </View>
                            <View className="mx-5 pb-3">
                                <Text className="text-center text-white">
                                    Filtro por ODS
                                </Text>
                                <View
                                    className="bg-indigo-400 rounded-full"
                                >
                                    <Picker
                                        style={{ color: 'white' }}
                                        dropdownIconColor={'white'}
                                        selectedValue={filtroODS}
                                        onValueChange={(itemValue) => setFiltroODS(itemValue)}
                                        prompt="Filtro por ODS"
                                    >
                                        <Picker.Item label='Sin filtro' value='' key='Sin filtro' />
                                        {
                                            ODSQuery.data && ODSQuery.data.map(item => (
                                                <Picker.Item label={item.nombre} value={item.nombre} key={item.nombre} />
                                            ))
                                        }
                                    </Picker>
                                </View>
                            </View>
                        </View>
                    )}
                </View>
            </View>
            <View className="p-2">
                <View className='pb-28 mb-1'>
                    <FlatList
                        data={listData}
                        keyExtractor={(item, i) => `${item.idiniciativa}-${i}`}
                        renderItem={({ item }) => (
                            <TouchableOpacity
                                className="bg-blue-400 rounded-lg mb-2 p-3"
                                activeOpacity={0.7}
                                onPress={() => router.push(`./iniciativas/${item.idiniciativa}`)}
                            >
                                <Text className="text-xl font-bold">
                                    {item.titulo}
                                </Text>
                                <Text className="text-lg">
                                    Ciclos: {item.ciclosLista.map(ciclo => ciclo.nombre).join(', ')}
                                </Text>
                                <View className="flex-row flex-wrap">
                                    {item.odsLista.map((ods, index) => (
                                        <Image
                                            className="size-14 m-1"
                                            key={index}
                                            source={useODSImage(ods.idODS)}
                                        />
                                    ))}
                                </View>
                            </TouchableOpacity>
                        )}
                        showsVerticalScrollIndicator={false}
                    />
                </View>
            </View>
        </View>
    )
}

export default App