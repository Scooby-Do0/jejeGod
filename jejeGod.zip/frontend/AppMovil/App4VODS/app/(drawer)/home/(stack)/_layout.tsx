import { Stack } from 'expo-router';

export default function StackLayout() {
  return (
    <Stack
      screenOptions={{
        statusBarBackgroundColor: 'midnightblue',
        navigationBarColor: 'midnightblue',
        headerStyle: {
          backgroundColor: 'midnightblue',
        },
        headerTintColor: 'white',
      }}
    >
      <Stack.Screen
        name="index"
        options={{
          headerShown: false,
        }}
      />
    </Stack>
  );
}
