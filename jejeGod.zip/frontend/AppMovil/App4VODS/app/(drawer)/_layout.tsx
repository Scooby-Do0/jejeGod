import { Ionicons } from '@expo/vector-icons';
import { Drawer } from 'expo-router/drawer';
import React from 'react';
import CustomDrawer from '@/components/drawer/CustomDrawer';
const DrawerLayout = () => {
    return (
        <Drawer
            drawerContent={CustomDrawer}
            screenOptions={{
                headerStyle: {
                    backgroundColor: 'midnightblue',
                },
                headerTintColor: 'white',
                overlayColor: 'rgba(0,0,0,0.4)',
                drawerActiveTintColor: 'white',
                drawerInactiveTintColor: 'skyblue',
                headerShadowVisible: false,
                drawerStyle: {
                    backgroundColor: 'midnightblue',
                }
            }}
        >
            <Drawer.Screen
                name="home/(stack)" // This is the name of the page and must match the url from root
                options={{
                    drawerLabel: 'LISTA DE INICIATIVAS',
                    title: 'LISTA DE INICIATIVAS',
                    drawerIcon: ({ color, size }) => (
                        <Ionicons name='list-sharp' size={size} color={color} />
                    ),
                }}
            />
            <Drawer.Screen
                name="indicators/(stack)" // This is the name of the page and must match the url from root
                options={{
                    drawerLabel: 'INDICADORES',
                    title: 'INDICADORES',
                    drawerIcon: ({ color, size }) => (
                        <Ionicons name='analytics-sharp' size={size} color={color} />
                    ),
                }}
            />
        </Drawer>
    );
}

export default DrawerLayout